import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class Services extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Services.class.getName());
        private Connection conn;
        private PreparedStatement pst;
        private ResultSet rs;
        private TableRowSorter<DefaultTableModel> sorter;
        private int editingServiceId = -1;

        private java.awt.Image originalServicesBackground;

    /**
     * Creates new form Services
     */
    public Services() {

    initComponents();
    
    setupServiceActions();
    

    designSearchBar();
    designServicesTable();
    designServiceDetailsPanel();

    connectDatabase();
    loadServices();

    DefaultTableModel model =
            (DefaultTableModel) ServiceTable.getModel();

    sorter = new TableRowSorter<>(model);
    ServiceTable.setRowSorter(sorter);
    
    
jTextField1.getDocument().addDocumentListener(
        new javax.swing.event.DocumentListener() {

                @Override
                public void insertUpdate(
                        javax.swing.event.DocumentEvent e) {
                        searchServices();
                }

                @Override
                public void removeUpdate(
                        javax.swing.event.DocumentEvent e) {
                        searchServices();
                }

                @Override
                public void changedUpdate(
                        javax.swing.event.DocumentEvent e) {
                        searchServices();
                }
        }
);


    jButton5.addActionListener(
            e -> clearServiceFields()
    );

    jButton6.addActionListener(
            e -> saveService()
    );

    // Prevent the search bar from receiving initial focus
    getContentPane().setFocusable(true);

    addWindowListener(new java.awt.event.WindowAdapter() {
        @Override
        public void windowOpened(java.awt.event.WindowEvent evt) {
            getContentPane().requestFocusInWindow();
        }
        
    });
    // Correct the Services filter and sorting options
Filter.setModel(
        new javax.swing.DefaultComboBoxModel<>(
                new String[]{
                        "FILTER BY: ALL",
                        "Available",
                        "Unavailable"
                }
        )
);

Sort.setModel(new javax.swing.DefaultComboBoxModel<>(
        new String[]{
            "SORT BY: DEFAULT",
            "Service ID",
            "Service Name",
            "Service Fee"
        }
));

// Maximize like the Patients page
setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);

// Apply responsive layout
java.awt.EventQueue.invokeLater(() -> {
    getContentPane().setLayout(null);
    scaleServices();
    getContentPane().requestFocusInWindow();
});

// Update positions when the window is resized
addComponentListener(new java.awt.event.ComponentAdapter() {
    @Override
    public void componentResized(java.awt.event.ComponentEvent evt) {
        scaleServices();
    }
});
}
    private void scaleServicesBackground() {

    int width = getContentPane().getWidth();
    int height = getContentPane().getHeight();

    // Keep the original image to prevent quality loss
    if (originalServicesBackground == null
            && jLabel1.getIcon() instanceof javax.swing.ImageIcon) {

        originalServicesBackground =
                ((javax.swing.ImageIcon) jLabel1.getIcon())
                        .getImage();
    }

    if (originalServicesBackground != null) {

        java.awt.Image scaledImage =
                originalServicesBackground.getScaledInstance(
                        width,
                        height,
                        java.awt.Image.SCALE_SMOOTH
                );

        jLabel1.setIcon(
                new javax.swing.ImageIcon(scaledImage)
        );
    }

    jLabel1.setBounds(
            0,
            0,
            width,
            height
    );

    // Keep background behind all other components
    getContentPane().setComponentZOrder(
            jLabel1,
            getContentPane().getComponentCount() - 1
    );
}
    
    private void scaleServices() {

    int width = getContentPane().getWidth();
    int height = getContentPane().getHeight();

    if (width <= 0 || height <= 0) {
        return;
    }

    // ==========================================
    // 2. MAIN CONTENT
    // Match Patients page horizontal alignment
    // ==========================================

    int contentX = (int) (width * 400.0 / 1920.0);
    int contentWidth = width - contentX - 18;

    if (contentWidth <= 0) {
        return;
    }

    // Page title
    jButton11.setBounds(
            contentX,
            Math.max(30, (int) (height * 0.045)),
            Math.min(360, contentWidth),
            60
    );

    jButton11.setFont(new java.awt.Font(
            "Segoe UI",
            java.awt.Font.BOLD,
            width < 1400 ? 32 : 40
    ));

    // ==========================================
    // 3. SEARCH BAR AND CONTROLS
    // ==========================================
int searchY = (int) (height * 160.0 / 1080.0);
int searchHeight = 42;
int gap = 8;

int iconWidth = 42;
int filterWidth = 160;
int sortWidth = 145;
int orderWidth = 125;

// Reference width: 720px at 1920 resolution
int searchWidth = (int) (720 * width / 1920.0);

// Prevent controls from extending outside the content area
int controlsWidth = iconWidth + filterWidth
        + sortWidth + orderWidth + gap * 4;

searchWidth = Math.max(
        100,
        Math.min(searchWidth, contentWidth - controlsWidth)
);

// Search field
jTextField1.setBounds(
        contentX,
        searchY,
        searchWidth,
        searchHeight
);

int nextX = contentX + searchWidth + gap;

// Search icon
jButton3.setBounds(
        nextX,
        searchY,
        iconWidth,
        searchHeight
);

nextX += iconWidth + gap;

// Filter
Filter.setBounds(
        nextX,
        searchY,
        filterWidth,
        searchHeight
);

nextX += filterWidth + gap;

// Sort
Sort.setBounds(
        nextX,
        searchY,
        sortWidth,
        searchHeight
);

nextX += sortWidth + gap;

// Order
Order.setBounds(
        nextX,
        searchY,
        orderWidth,
        searchHeight
);
    // ==========================================
    // 4. TABLE AND DETAILS PANEL
    // Same bottom-reservation approach as Patients
    // ==========================================

    int tableY = searchY + searchHeight + 16;

    int detailsHeight = Math.min(
            300,
            Math.max(270, height / 3)
    );

    int detailsY = height - detailsHeight - 12;

    int tableHeight = Math.max(
            150,
            detailsY - tableY - 10
    );

    jPanel2.setBounds(
            contentX,
            tableY,
            contentWidth,
            tableHeight
    );

    jPanel1.setBounds(
            contentX,
            detailsY,
            contentWidth,
            detailsHeight
    );

    // ==========================================
    // 5. APPLY RESPONSIVE FIXES
    // ==========================================

    fixServicesTable();
    fixServiceDetailsPanel();
    scaleServiceSearchIcon();
    scaleServicesBackground();

    
// Match the Dashboard sidebar
fixServicesSidebar();
    getContentPane().revalidate();
    getContentPane().repaint();
}
    private void fixServicesTable() {

    jPanel2.setLayout(null);

    jScrollPane1.setBounds(
            0,
            0,
            jPanel2.getWidth(),
            jPanel2.getHeight()
    );

    ServiceTable.setAutoResizeMode(
            javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS
    );

    // Reserve enough space for Edit and Remove
    int actionIndex = ServiceTable.getColumnCount() - 1;

    javax.swing.table.TableColumn actionColumn =
            ServiceTable.getColumnModel().getColumn(actionIndex);

    actionColumn.setMinWidth(165);
    actionColumn.setPreferredWidth(175);

    jPanel2.revalidate();
    jPanel2.repaint();
}
    private void fixServiceDetailsPanel() {

    int panelWidth = jPanel1.getWidth();
    int panelHeight = jPanel1.getHeight();

    jPanel1.setLayout(null);
    jPanel1.setVisible(true);
    jPanel1.setOpaque(true);

    jPanel1.setBackground(
            new java.awt.Color(245, 252, 248)
    );

    jPanel1.setBorder(
            javax.swing.BorderFactory.createLineBorder(
                    new java.awt.Color(0, 102, 51),
                    2
            )
    );

    // =====================================
    // DETAILS TITLE
    // =====================================

    jLabel2.setText("Service Details");

    jLabel2.setFont(new java.awt.Font(
            "Segoe UI",
            java.awt.Font.BOLD,
            18
    ));

    jLabel2.setForeground(
            new java.awt.Color(0, 102, 51)
    );

    jLabel2.setBounds(25, 12, 250, 35);

    // =====================================
    // LEFT COLUMN
    // =====================================

    int leftLabelX = 30;
    int leftFieldX = 160;

    int fieldWidth = Math.min(
            300,
            Math.max(160, panelWidth / 2 - leftFieldX - 30)
    );

    int fieldHeight = 35;

    int row1 = 65;
    int row2 = 125;
    int row3 = 180;

jLabel11.setBounds(
        leftLabelX, row3, 120, fieldHeight
);

jComboBox1.setBounds(
        leftFieldX, row3, fieldWidth, fieldHeight
);

    // Service Name
    jLabel3.setBounds(
            leftLabelX, row1, 120, fieldHeight
    );

    jTextField7.setBounds(
            leftFieldX, row1, fieldWidth, fieldHeight
    );

    // Service Fee
    jLabel10.setBounds(
            leftLabelX, row2, 120, fieldHeight
    );

    jTextField2.setBounds(
            leftFieldX, row2, fieldWidth, fieldHeight
    );

    // =====================================
    // RIGHT COLUMN
    // =====================================

  // Position Description closer to Service Name
int rightLabelX = leftFieldX + fieldWidth + 45;
int descriptionX = rightLabelX + 105;
int descriptionWidth = Math.min(
        550,
        Math.max(150, panelWidth - descriptionX - 30)
);

    // Description label
    jLabel4.setBounds(
            rightLabelX, row1, 100, fieldHeight
    );

    // Description text area
    jScrollPane2.setBounds(
            descriptionX,
            row1,
            descriptionWidth,
            125
    );

    jTextArea1.setLineWrap(true);
    jTextArea1.setWrapStyleWord(true);

    // =====================================
    // CLEAR AND SAVE BUTTONS
    // =====================================

    int buttonWidth = 110;
    int buttonHeight = 36;
    int buttonGap = 15;

    int buttonY = panelHeight - 52;

    int saveX = panelWidth - buttonWidth - 30;
    int clearX = saveX - buttonWidth - buttonGap;

    jButton5.setBounds(
            clearX, buttonY, buttonWidth, buttonHeight
    );

    jButton6.setBounds(
            saveX, buttonY, buttonWidth, buttonHeight
    );

    jPanel1.revalidate();
    jPanel1.repaint();
}
    
private void fixServicesSidebar() {

        int width = getContentPane().getWidth();
        int height = getContentPane().getHeight();

        if (width <= 0 || height <= 0) {
                return;
        }

        double scaleX = width / 1920.0;
        double scaleY = height / 1080.0;

        javax.swing.JButton[] buttons = {
                Dashboard,
                Patients,
                Doctors,
                Appointments,
                MedicalRecords,
                Services,
                Payments,
                Staff,
                UserAccounts,
                UserAccounts1,
                jButton1
        };

        int[] positionsY = {
                390, 445, 500, 555, 610,
                665, 720, 775, 830, 885, 955
        };

        int buttonX = (int) (60 * scaleX);
        int buttonWidth = (int) (260 * scaleX);
        int buttonHeight = (int) (60 * scaleY);

        int fontSize = Math.max(
                18,
                (int) (24 * Math.min(scaleX, scaleY))
        );

        for (int i = 0; i < buttons.length; i++) {

                javax.swing.JButton button = buttons[i];

                button.setBounds(
                        buttonX,
                        (int) (positionsY[i] * scaleY),
                        buttonWidth,
                        buttonHeight
                );

                button.setFont(
                        new java.awt.Font(
                                "Segoe UI",
                                java.awt.Font.BOLD,
                                fontSize
                        )
                );

                button.setHorizontalAlignment(
                        javax.swing.SwingConstants.LEFT
                );

                button.setFocusPainted(false);
        }
}

    private void scaleServiceSearchIcon() {

    java.net.URL iconURL =
            getClass().getResource(
                    "/images/icons8-search-47.png"
            );

    if (iconURL == null) {
        return;
    }

    int size = Math.max(
            16,
            (int) (Math.min(
                    jButton3.getWidth(),
                    jButton3.getHeight()
            ) * 0.60)
    );

    java.awt.Image image =
            new javax.swing.ImageIcon(iconURL)
                    .getImage()
                    .getScaledInstance(
                            size,
                            size,
                            java.awt.Image.SCALE_SMOOTH
                    );

    jButton3.setIcon(
            new javax.swing.ImageIcon(image)
    );

    jButton3.setHorizontalAlignment(
            javax.swing.SwingConstants.CENTER
    );

    jButton3.setVerticalAlignment(
            javax.swing.SwingConstants.CENTER
    );
}
private void styleServiceButton(
        javax.swing.JButton button, java.awt.Color color) {

        button.setBackground(color);
        button.setForeground(java.awt.Color.WHITE);
        button.setFont(new java.awt.Font(
                "Segoe UI", java.awt.Font.BOLD, 11));

        button.setFocusPainted(false);

        button.setPreferredSize(
                new java.awt.Dimension(
                        button.getText().equals("Edit") ? 58 : 78,
                        26
                )
        );
}

    
private class ServiceActionRenderer extends javax.swing.JPanel
        implements javax.swing.table.TableCellRenderer {

        private final javax.swing.JButton edit =
                new javax.swing.JButton("Edit");
        private final javax.swing.JButton remove =
                new javax.swing.JButton("Remove");

        ServiceActionRenderer() {
                setLayout(new java.awt.FlowLayout(
                        java.awt.FlowLayout.CENTER, 8, 3));

styleServiceButton(edit, new java.awt.Color(0, 102, 51));
styleServiceButton(remove, new java.awt.Color(190, 40, 40));

                add(edit);
                add(remove);
        }

        @Override
        public java.awt.Component getTableCellRendererComponent(
                javax.swing.JTable table, Object value,
                boolean isSelected, boolean hasFocus,
                int row, int column) {

                setBackground(isSelected
                        ? table.getSelectionBackground()
                        : table.getBackground());

                return this;
        }
}

private class ServiceActionEditor
        extends javax.swing.AbstractCellEditor
        implements javax.swing.table.TableCellEditor {

        private final javax.swing.JPanel panel =
                new javax.swing.JPanel(
                        new java.awt.FlowLayout(
                                java.awt.FlowLayout.CENTER, 8, 3));

        private final javax.swing.JButton edit =
                new javax.swing.JButton("Edit");
        private final javax.swing.JButton remove =
                new javax.swing.JButton("Remove");

        private int selectedRow;

        ServiceActionEditor() {

            styleServiceButton(edit, new java.awt.Color(0, 102, 51));
styleServiceButton(remove, new java.awt.Color(190, 40, 40));

                panel.add(edit);
                panel.add(remove);

                edit.addActionListener(e -> {
                        int row = selectedRow;
                        fireEditingStopped();
                        editService(row);
                });

                remove.addActionListener(e -> {
                        int row = selectedRow;
                        fireEditingStopped();
                        removeService(row);
                });
        }

        @Override
        public java.awt.Component getTableCellEditorComponent(
                javax.swing.JTable table, Object value,
                boolean isSelected, int row, int column) {

                selectedRow = row;
                panel.setBackground(table.getSelectionBackground());
                return panel;
        }

        @Override
        public Object getCellEditorValue() {
                return "";
        }
}

private void setupServiceActions() {

        DefaultTableModel model = new DefaultTableModel(
                new Object[][]{},
                new String[]{
                        "Service ID",
                        "Service Name",
                        "Description",
                        "Service Fee",
                        "Status",
                        "Action"
                }
        ) {
                @Override
                public boolean isCellEditable(int row, int column) {
                        return column == 5;
                }
        };

        ServiceTable.setModel(model);

        ServiceTable.getColumnModel().getColumn(5)
                .setCellRenderer(new ServiceActionRenderer());

        ServiceTable.getColumnModel().getColumn(5)
                .setCellEditor(new ServiceActionEditor());

        ServiceTable.getColumnModel().getColumn(5)
                .setPreferredWidth(170);
}
private void editService(int row) {

        int modelRow = ServiceTable.convertRowIndexToModel(row);

        editingServiceId = Integer.parseInt(
                ServiceTable.getModel()
                        .getValueAt(modelRow, 0).toString()
        );

        jTextField7.setText(
                ServiceTable.getModel()
                        .getValueAt(modelRow, 1).toString()
        );

        Object description = ServiceTable.getModel()
                .getValueAt(modelRow, 2);

        jTextArea1.setText(
                description == null ? "" : description.toString()
        );

        jTextField2.setText(
                ServiceTable.getModel()
                        .getValueAt(modelRow, 3).toString()
        );

        jButton6.setText("Update");
        jComboBox1.setSelectedItem(
        ServiceTable.getModel()
                .getValueAt(modelRow, 4).toString()
);
}


private void removeService(int row) {

        int modelRow = ServiceTable.convertRowIndexToModel(row);

        int serviceId = Integer.parseInt(
                ServiceTable.getModel()
                        .getValueAt(modelRow, 0).toString()
        );

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Remove this service?",
                "Confirm Remove",
                JOptionPane.YES_NO_OPTION
        );

        if (confirm != JOptionPane.YES_OPTION) {
                return;
        }

        String sql = "UPDATE Services SET status = 'Archived' "
                + "WHERE service_id = ?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setInt(1, serviceId);

                int updated = ps.executeUpdate();

                if (updated > 0) {
                        JOptionPane.showMessageDialog(
                                this,
                                "Service moved to Archive!"
                        );

                        clearServiceFields();
                        loadServices();
                }

        } catch (SQLException e) {
                JOptionPane.showMessageDialog(
                        this,
                        "Failed to remove service!\n" + e.getMessage()
                );
        }
}


private void searchServices() {

        if (sorter == null) {
                return;
        }

        String searchText = jTextField1.getText().trim();

        if (searchText.equalsIgnoreCase("Search service...")) {
                searchText = "";
        }

        String selectedFilter =
                Filter.getSelectedItem() == null
                ? "FILTER BY: ALL"
                : Filter.getSelectedItem().toString().trim();

        java.util.List<
                javax.swing.RowFilter<DefaultTableModel, Integer>>
                filters = new java.util.ArrayList<>();

        // FILTER BY SERVICE STATUS
        if (selectedFilter.equalsIgnoreCase("Available")
                || selectedFilter.equalsIgnoreCase("Unavailable")) {

                filters.add(
                        javax.swing.RowFilter.regexFilter(
                                "(?i)^"
                                + java.util.regex.Pattern.quote(selectedFilter)
                                + "$",
                                4
                        )
                );
        }

        // SEARCH BY SERVICE INFORMATION
        if (!searchText.isEmpty()) {

                String pattern = "(?i)"
                        + java.util.regex.Pattern.quote(searchText);

                filters.add(
                        javax.swing.RowFilter.regexFilter(
                                pattern,
                                0, 1, 2, 3
                        )
                );
        }

        // APPLY BOTH SEARCH AND FILTER
        if (filters.isEmpty()) {

                sorter.setRowFilter(null);

        } else {

                sorter.setRowFilter(
                        javax.swing.RowFilter.andFilter(filters)
                );
        }
}

private void sortServices() {
    if (sorter == null) {
        return;
    }

    String selectedSort = Sort.getSelectedItem().toString();
    String selectedOrder = Order.getSelectedItem().toString();

    int column;

    switch (selectedSort) {
        case "Service ID":
            column = 0;
            break;
        case "Service Name":
            column = 1;
            break;
        case "Service Fee":
            column = 3;
            break;
        default:
            sorter.setSortKeys(null);
            return;
    }

    javax.swing.SortOrder direction =
            "DESCENDING".equals(selectedOrder)
            ? javax.swing.SortOrder.DESCENDING
            : javax.swing.SortOrder.ASCENDING;

    sorter.setSortKeys(
            java.util.Collections.singletonList(
                    new javax.swing.RowSorter.SortKey(column, direction)
            )
    );
}


private void saveService() {

        String serviceName =
                jTextField7.getText().trim();

        String description =
                jTextArea1.getText().trim();

        String feeText =
                jTextField2.getText().trim();
        String serviceStatus =
        jComboBox1.getSelectedItem().toString();


        if (serviceName.isEmpty()
                || feeText.isEmpty()) {

                JOptionPane.showMessageDialog(
                        this,
                        "Please enter the Service Name "
                        + "and Service Fee."
                );

                return;
        }


        double serviceFee;

        try {

                serviceFee =
                        Double.parseDouble(feeText);

                if (serviceFee < 0) {

                        JOptionPane.showMessageDialog(
                                this,
                                "Service Fee cannot be negative."
                        );

                        return;
                }

        } catch (NumberFormatException e) {

                JOptionPane.showMessageDialog(
                        this,
                        "Service Fee must be a number."
                );

                return;
        }


String sql;

if (editingServiceId == -1) {

        sql = "INSERT INTO Services "
                + "(service_name, description, service_fee, status) "
                + "VALUES (?, ?, ?, ?)";

} else {

        sql = "UPDATE Services SET "
                + "service_name = ?, "
                + "description = ?, "
                + "service_fee = ?, "
                + "status = ? "
                + "WHERE service_id = ?";
}
        try {

                pst = conn.prepareStatement(sql);

                pst.setString(
                        1,
                        serviceName
                );

                pst.setString(
                        2,
                        description
                );

pst.setDouble(3, serviceFee);

// Get status from your existing ComboBox
pst.setString(
        4,
        jComboBox1.getSelectedItem().toString()
);

// Set Service ID only when updating
if (editingServiceId != -1) {
        pst.setInt(5, editingServiceId);
}

                pst.executeUpdate();


                JOptionPane.showMessageDialog(
                        this,
                        "Service added successfully!"
                );


                clearServiceFields();
                loadServices();


        } catch (SQLException e) {

                JOptionPane.showMessageDialog(
                        this,
                        "Failed to add service!\n"
                        + e.getMessage()
                );
        }
}
private void clearServiceFields() {
jComboBox1.setSelectedItem("Available");
        jTextField7.setText("");
        jTextArea1.setText("");
        jTextField2.setText("");

        ServiceTable.clearSelection();

        jTextField7.requestFocusInWindow();
        editingServiceId = -1;
jButton6.setText("Save");
}
private void connectDatabase() {

        try {

                Class.forName(
                        "com.mysql.cj.jdbc.Driver"
                );

                conn = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/ClinicManagementSystem",
                        "root",
                        ""
                );

                System.out.println(
                        "Services Database Connected!"
                );

        } catch (ClassNotFoundException | SQLException e) {

                JOptionPane.showMessageDialog(
                        this,
                        "Database Connection Failed!\n"
                        + e.getMessage()
                );
        }
}
private void loadServices() {

        if (conn == null) {
                return;
        }

        DefaultTableModel model =
                (DefaultTableModel) ServiceTable.getModel();

        model.setRowCount(0);

        String sql = "SELECT service_id, service_name, "
                + "description, service_fee, status "
                + "FROM Services "
                + "WHERE status IN ('Available', 'Unavailable') "
                + "ORDER BY service_id ASC";

        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet result = ps.executeQuery()) {

                while (result.next()) {

                        model.addRow(new Object[]{
                                result.getInt("service_id"),
                                result.getString("service_name"),
                                result.getString("description"),
                                result.getBigDecimal("service_fee"),
                                result.getString("status"),
                                ""
                        });
                }

        } catch (SQLException e) {

                JOptionPane.showMessageDialog(
                        this,
                        "Failed to load services!\n" + e.getMessage()
                );
        }
}
private void designSearchBar() {

    String placeholder = "Search service...";

    jTextField1.setFont(
            new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 16)
    );

    jTextField1.setForeground(
            new java.awt.Color(130, 130, 130)
    );

    jTextField1.setText(placeholder);

    jTextField1.addFocusListener(
            new java.awt.event.FocusAdapter() {

                @Override
                public void focusGained(
                        java.awt.event.FocusEvent evt) {

                    if (jTextField1.getText().equals(placeholder)) {
                        jTextField1.setText("");
                        jTextField1.setForeground(
                                new java.awt.Color(40, 40, 40)
                        );
                    }
                }

                @Override
                public void focusLost(
                        java.awt.event.FocusEvent evt) {

                    if (jTextField1.getText().trim().isEmpty()) {
                        jTextField1.setText(placeholder);
                        jTextField1.setForeground(
                                new java.awt.Color(130, 130, 130)
                        );
                    }
                }
            }
    );
}

private void designServiceDetailsPanel() {

    jPanel1.setBackground(
            new java.awt.Color(222, 246, 236)
    );

    jPanel1.setBorder(
            javax.swing.BorderFactory.createLineBorder(
                    new java.awt.Color(0, 102, 51),
                    2
            )
    );

    jPanel1.revalidate();
    jPanel1.repaint();
}

private void designServicesTable() {

        // =========================
        // TABLE BODY
        // =========================
        ServiceTable.setFont(
                new java.awt.Font(
                        "Segoe UI",
                        java.awt.Font.PLAIN,
                        14
                )
        );

        ServiceTable.setRowHeight(38);

        ServiceTable.setBackground(
                java.awt.Color.WHITE
        );

        ServiceTable.setForeground(
                new java.awt.Color(40, 40, 40)
        );

        ServiceTable.setSelectionBackground(
                new java.awt.Color(222, 246, 236)
        );

        ServiceTable.setSelectionForeground(
                new java.awt.Color(0, 102, 51)
        );

        ServiceTable.setGridColor(
                new java.awt.Color(220, 235, 228)
        );

        ServiceTable.setShowHorizontalLines(true);
        ServiceTable.setShowVerticalLines(false);

        ServiceTable.setIntercellSpacing(
                new java.awt.Dimension(0, 1)
        );


        // =========================
        // GREEN HEADER
        // =========================
        javax.swing.table.JTableHeader header =
                ServiceTable.getTableHeader();

        header.setPreferredSize(
                new java.awt.Dimension(
                        header.getPreferredSize().width,
                        38
                )
        );

        header.setReorderingAllowed(false);


        javax.swing.table.DefaultTableCellRenderer headerRenderer =
                new javax.swing.table.DefaultTableCellRenderer();

        headerRenderer.setBackground(
                new java.awt.Color(0, 102, 51)
        );

        headerRenderer.setForeground(
                java.awt.Color.WHITE
        );

        headerRenderer.setFont(
                new java.awt.Font(
                        "Segoe UI",
                        java.awt.Font.BOLD,
                        14
                )
        );

        headerRenderer.setHorizontalAlignment(
                javax.swing.SwingConstants.CENTER
        );

        headerRenderer.setOpaque(true);


        for (int i = 0;
i < ServiceTable.getColumnCount();
i++) {

                ServiceTable.getColumnModel()
                        .getColumn(i)
                        .setHeaderRenderer(headerRenderer);
        }


        // =========================
        // CENTER TABLE CONTENT
        // =========================
     
        // CENTER TABLE CONTENT
        javax.swing.table.DefaultTableCellRenderer center =
                new javax.swing.table.DefaultTableCellRenderer();

        center.setHorizontalAlignment(
                javax.swing.SwingConstants.CENTER
        );

        // Center all columns except Action
        for (int i = 0;
                i < ServiceTable.getColumnCount() - 1;
                i++) {

                ServiceTable.getColumnModel()
                        .getColumn(i)
                        .setCellRenderer(center);
        }

        // Preserve Edit and Remove buttons
  javax.swing.table.TableColumn action =
        ServiceTable.getColumnModel().getColumn(5);

        action.setCellRenderer(new ServiceActionRenderer());
        action.setCellEditor(new ServiceActionEditor());
        action.setPreferredWidth(170);

      

        // White empty area
        jScrollPane1.getViewport().setBackground(
                java.awt.Color.WHITE
        );

        ServiceTable.getTableHeader().repaint();
        ServiceTable.repaint();
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        Patients = new javax.swing.JButton();
        Appointments = new javax.swing.JButton();
        MedicalRecords = new javax.swing.JButton();
        Payments = new javax.swing.JButton();
        Staff = new javax.swing.JButton();
        Dashboard = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        UserAccounts = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        ServiceTable = new javax.swing.JTable();
        Doctors = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        Services = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jTextField7 = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        Sort = new javax.swing.JComboBox<>();
        Order = new javax.swing.JComboBox<>();
        Filter = new javax.swing.JComboBox<>();
        UserAccounts1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton1.setForeground(new java.awt.Color(204, 0, 0));
        jButton1.setText("Log Out");
        jButton1.setBorderPainted(false);
        jButton1.setContentAreaFilled(false);
        jButton1.setDefaultCapable(false);
        jButton1.setFocusPainted(false);
        jButton1.setFocusable(false);
        jButton1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton1.addActionListener(this::jButton1ActionPerformed);
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 990, 260, 60));

        Patients.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Patients.setForeground(new java.awt.Color(255, 255, 255));
        Patients.setText("Patients");
        Patients.setBorderPainted(false);
        Patients.setContentAreaFilled(false);
        Patients.setDefaultCapable(false);
        Patients.setFocusPainted(false);
        Patients.setFocusable(false);
        Patients.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Patients.addActionListener(this::PatientsActionPerformed);
        getContentPane().add(Patients, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 450, 260, 60));

        Appointments.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Appointments.setForeground(new java.awt.Color(255, 255, 255));
        Appointments.setText("Appointments");
        Appointments.setBorderPainted(false);
        Appointments.setContentAreaFilled(false);
        Appointments.setDefaultCapable(false);
        Appointments.setFocusPainted(false);
        Appointments.setFocusable(false);
        Appointments.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Appointments.addActionListener(this::AppointmentsActionPerformed);
        getContentPane().add(Appointments, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 560, 260, 70));

        MedicalRecords.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        MedicalRecords.setForeground(new java.awt.Color(255, 255, 255));
        MedicalRecords.setText("Medical Records");
        MedicalRecords.setBorderPainted(false);
        MedicalRecords.setContentAreaFilled(false);
        MedicalRecords.setDefaultCapable(false);
        MedicalRecords.setFocusPainted(false);
        MedicalRecords.setFocusable(false);
        MedicalRecords.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        MedicalRecords.addActionListener(this::MedicalRecordsActionPerformed);
        getContentPane().add(MedicalRecords, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 620, 260, 70));

        Payments.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Payments.setForeground(new java.awt.Color(255, 255, 255));
        Payments.setText("Payments");
        Payments.setBorderPainted(false);
        Payments.setContentAreaFilled(false);
        Payments.setDefaultCapable(false);
        Payments.setFocusPainted(false);
        Payments.setFocusable(false);
        Payments.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Payments.addActionListener(this::PaymentsActionPerformed);
        getContentPane().add(Payments, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 730, 260, 80));

        Staff.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Staff.setForeground(new java.awt.Color(255, 255, 255));
        Staff.setText("Staff");
        Staff.setBorderPainted(false);
        Staff.setContentAreaFilled(false);
        Staff.setDefaultCapable(false);
        Staff.setFocusPainted(false);
        Staff.setFocusable(false);
        Staff.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Staff.addActionListener(this::StaffActionPerformed);
        getContentPane().add(Staff, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 780, 260, 80));

        Dashboard.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Dashboard.setForeground(new java.awt.Color(255, 255, 255));
        Dashboard.setText("Dashboard");
        Dashboard.setBorderPainted(false);
        Dashboard.setContentAreaFilled(false);
        Dashboard.setDefaultCapable(false);
        Dashboard.setFocusPainted(false);
        Dashboard.setFocusable(false);
        Dashboard.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Dashboard.addActionListener(this::DashboardActionPerformed);
        getContentPane().add(Dashboard, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 380, 260, 80));

        jButton11.setFont(new java.awt.Font("Segoe UI", 1, 40)); // NOI18N
        jButton11.setText("Services");
        jButton11.setBorderPainted(false);
        jButton11.setContentAreaFilled(false);
        jButton11.setDefaultCapable(false);
        jButton11.setFocusPainted(false);
        jButton11.setFocusable(false);
        jButton11.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton11.addActionListener(this::jButton11ActionPerformed);
        getContentPane().add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 40, 360, -1));

        UserAccounts.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        UserAccounts.setForeground(new java.awt.Color(255, 255, 255));
        UserAccounts.setText("User Accounts");
        UserAccounts.setBorderPainted(false);
        UserAccounts.setContentAreaFilled(false);
        UserAccounts.setDefaultCapable(false);
        UserAccounts.setFocusPainted(false);
        UserAccounts.setFocusable(false);
        UserAccounts.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        UserAccounts.addActionListener(this::UserAccountsActionPerformed);
        getContentPane().add(UserAccounts, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 830, 260, 80));

        jPanel2.setBackground(new java.awt.Color(222, 246, 236));

        ServiceTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Service ID", "Service Name", "Description", "Service Fee", "Status"
            }
        ));
        ServiceTable.setFocusCycleRoot(true);
        ServiceTable.setGridColor(new java.awt.Color(231, 250, 250));
        ServiceTable.setShowGrid(true);
        ServiceTable.setSurrendersFocusOnKeystroke(true);
        jScrollPane1.setViewportView(ServiceTable);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1474, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 524, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 230, 1480, 530));

        Doctors.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Doctors.setForeground(new java.awt.Color(255, 255, 255));
        Doctors.setText("Doctors");
        Doctors.setBorderPainted(false);
        Doctors.setContentAreaFilled(false);
        Doctors.setDefaultCapable(false);
        Doctors.setFocusPainted(false);
        Doctors.setFocusable(false);
        Doctors.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Doctors.addActionListener(this::DoctorsActionPerformed);
        getContentPane().add(Doctors, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 500, 260, 70));

        jTextField1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jTextField1.setText("Search service");
        jTextField1.addActionListener(this::jTextField1ActionPerformed);
        getContentPane().add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 160, 720, 50));

        Services.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Services.setForeground(new java.awt.Color(0, 102, 51));
        Services.setText("Services");
        Services.setDefaultCapable(false);
        Services.setFocusPainted(false);
        Services.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Services.addActionListener(this::ServicesActionPerformed);
        getContentPane().add(Services, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 690, 260, 50));

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-search-47.png"))); // NOI18N
        jButton3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 51)));
        jButton3.setBorderPainted(false);
        jButton3.addActionListener(this::jButton3ActionPerformed);
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 160, -1, -1));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 102, 51));
        jLabel2.setText("Service Details");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Service Name");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Description");

        jButton5.setBackground(new java.awt.Color(240, 250, 244));
        jButton5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton5.setForeground(new java.awt.Color(0, 102, 51));
        jButton5.setText("Clear");

        jButton6.setBackground(new java.awt.Color(0, 102, 51));
        jButton6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.setText("Save");

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel10.setText("Service Fee");

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane2.setViewportView(jTextArea1);

        jLabel11.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel11.setText("Status");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Available", "Unavailable", " " }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jLabel2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel11)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTextField7)
                            .addComponent(jTextField2, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
                            .addComponent(jComboBox1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(50, 50, 50)
                        .addComponent(jLabel4)))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButton5)
                        .addGap(18, 18, 18)
                        .addComponent(jButton6)))
                .addGap(660, 745, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel3)
                                .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel10)
                                .addComponent(jTextField2)))))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(23, 23, 23))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel11)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 770, 1480, 210));

        Sort.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Sort.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SORT BY: DEFAULT", "Record ID", "Record Date" }));
        Sort.addActionListener(this::SortActionPerformed);
        getContentPane().add(Sort, new org.netbeans.lib.awtextra.AbsoluteConstraints(1310, 160, 100, 50));

        Order.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Order.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ORDER", "ASCENDING", "DESCENDING" }));
        Order.addActionListener(this::OrderActionPerformed);
        getContentPane().add(Order, new org.netbeans.lib.awtextra.AbsoluteConstraints(1420, 160, 100, 50));

        Filter.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Filter.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "FILTER BY: ALL", "Available", "Unavailable" }));
        Filter.addActionListener(this::FilterActionPerformed);
        getContentPane().add(Filter, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 160, 120, 50));

        UserAccounts1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        UserAccounts1.setForeground(new java.awt.Color(255, 255, 255));
        UserAccounts1.setText("Archive");
        UserAccounts1.setBorderPainted(false);
        UserAccounts1.setContentAreaFilled(false);
        UserAccounts1.setDefaultCapable(false);
        UserAccounts1.setFocusPainted(false);
        UserAccounts1.setFocusable(false);
        UserAccounts1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        UserAccounts1.addActionListener(this::UserAccounts1ActionPerformed);
        getContentPane().add(UserAccounts1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 890, 260, 80));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Dashgh.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -10, 1930, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void PatientsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PatientsActionPerformed
    Patients patients = new Patients();
    patients.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_PatientsActionPerformed

    private void AppointmentsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AppointmentsActionPerformed
    Appointments appointments = new Appointments();
    appointments.setVisible(true);
    this.dispose();          // TODO add your handling code here:
    }//GEN-LAST:event_AppointmentsActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton11ActionPerformed

    private void DoctorsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DoctorsActionPerformed
    Doctors doctors = new Doctors();
    doctors.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_DoctorsActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
            searchServices();
// TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
            searchServices();
// TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void DashboardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DashboardActionPerformed
    Dashboard dashboard = new Dashboard();
    dashboard.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_DashboardActionPerformed

    private void MedicalRecordsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MedicalRecordsActionPerformed
    MedicalRecords records = new MedicalRecords();
    records.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_MedicalRecordsActionPerformed

    private void ServicesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ServicesActionPerformed
    Services services = new Services();
    services.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_ServicesActionPerformed

    private void PaymentsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PaymentsActionPerformed
    Payments payments = new Payments();
    payments.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_PaymentsActionPerformed

    private void StaffActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StaffActionPerformed
    Staff staff = new Staff();
    staff.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_StaffActionPerformed

    private void UserAccountsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UserAccountsActionPerformed
    UserAccounts accounts = new UserAccounts();
    accounts.setVisible(true);
    this.dispose();
        // TODO add your handling code here:
    }//GEN-LAST:event_UserAccountsActionPerformed

    private void FilterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FilterActionPerformed
        searchServices();

        // TODO add your handling code here:
    }//GEN-LAST:event_FilterActionPerformed

    private void SortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SortActionPerformed
        sortServices();

        // TODO add your handling code here:
    }//GEN-LAST:event_SortActionPerformed

    private void OrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OrderActionPerformed
        sortServices();
        // TODO add your handling code here:
    }//GEN-LAST:event_OrderActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    UserSession.logout();
    SignIn logout = new SignIn();
    logout.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void UserAccounts1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UserAccounts1ActionPerformed
        Archive archive = new Archive();
        archive.setVisible(true);
        this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_UserAccounts1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Services().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Appointments;
    private javax.swing.JButton Dashboard;
    private javax.swing.JButton Doctors;
    private javax.swing.JComboBox<String> Filter;
    private javax.swing.JButton MedicalRecords;
    private javax.swing.JComboBox<String> Order;
    private javax.swing.JButton Patients;
    private javax.swing.JButton Payments;
    private javax.swing.JTable ServiceTable;
    private javax.swing.JButton Services;
    private javax.swing.JComboBox<String> Sort;
    private javax.swing.JButton Staff;
    private javax.swing.JButton UserAccounts;
    private javax.swing.JButton UserAccounts1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField7;
    // End of variables declaration//GEN-END:variables
}
