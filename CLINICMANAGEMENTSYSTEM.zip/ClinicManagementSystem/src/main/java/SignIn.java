
import java.awt.Container;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author NCGC
 */
public class SignIn extends javax.swing.JFrame {

 

    class RoundedPanel extends javax.swing.JPanel {

    private int radius = 40;

    public RoundedPanel() {
        setOpaque(false);
    }

    @Override
    protected void paintComponent(java.awt.Graphics g) {

        java.awt.Graphics2D g2 =
                (java.awt.Graphics2D) g.create();

        g2.setRenderingHint(
                java.awt.RenderingHints.KEY_ANTIALIASING,
                java.awt.RenderingHints.VALUE_ANTIALIAS_ON
        );

        g2.setColor(getBackground());

        g2.fillRoundRect(
                0,
                0,
                getWidth(),
                getHeight(),
                radius,
                radius
        );

        g2.dispose();
    }
}
    private java.util.prefs.Preferences prefs =
            java.util.prefs.Preferences.userNodeForPackage(SignIn.class);    
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(SignIn.class.getName());

    /**
     * Creates new form SignIn
     */
    public SignIn() {
        initComponents();
// Remember username only
String savedUsername = prefs.get("username", "");

// Remove any previously saved plaintext password
prefs.remove("password");

if (!savedUsername.isEmpty()) {

        Username.setText(savedUsername);
        Username.setForeground(java.awt.Color.BLACK);
        RememberMe.setSelected(true);

} else {

        Username.setText("Username");
        Username.setForeground(
                new java.awt.Color(204, 204, 204));
        RememberMe.setSelected(false);
}

Password.setText("Password");
Password.setEchoChar((char) 0);
Password.setForeground(
        new java.awt.Color(204, 204, 204));
        java.awt.EventQueue.invokeLater(() -> {

            getContentPane().setLayout(null);
            SignInPanel.setLayout(null);

            scaleBackground();
            scaleLoginPanel();

            SignInPanel.setFocusable(true);
            SignInPanel.requestFocusInWindow();

            repaint();
        });
    
    }
        private void scaleBackground() {

        java.awt.Dimension screen =
            java.awt.Toolkit.getDefaultToolkit().getScreenSize();

        javax.swing.ImageIcon icon =
            new javax.swing.ImageIcon(
                getClass().getResource("/images/bgbg (1).png")
            );

        java.awt.Image image = icon.getImage();

        java.awt.Image scaledImage =
            image.getScaledInstance(
                screen.width,
                screen.height,
                java.awt.Image.SCALE_SMOOTH
            );

        jLabel6.setIcon(
            new javax.swing.ImageIcon(scaledImage)
        );

        jLabel6.setBounds(
            0,
            0,
            screen.width,
            screen.height
        );

        jLabel6.setText("");
    }


    private void scaleLoginPanel() {

        int screenWidth = getContentPane().getWidth();
        int screenHeight = getContentPane().getHeight();

        double scaleX = screenWidth / 1920.0;
        double scaleY = screenHeight / 1080.0;

        double scale = Math.min(scaleX, scaleY);

        int width = (int) (690 * scale);
        int height = (int) (680 * scale);

        int x = screenWidth - width - 200;
        int y = (screenHeight - height) / 2;

        SignInPanel.setBounds(x, y, width, height);

        scaleChildren(SignInPanel, scale);
        // Fix Sign label
        jLabel3.setSize(jLabel3.getPreferredSize());
        
        

        // Scale user icon
        javax.swing.ImageIcon userIcon =
            new javax.swing.ImageIcon(
                getClass().getResource("/images/icons8-user-60.png")
            );

        java.awt.Image userImage =
            userIcon.getImage().getScaledInstance(
                jPanel1.getWidth() - 8,
                jPanel1.getHeight() - 8,
                java.awt.Image.SCALE_SMOOTH
            );

        jLabel2.setIcon(new javax.swing.ImageIcon(userImage));


        // Scale password icon
        javax.swing.ImageIcon passIcon =
            new javax.swing.ImageIcon(
                getClass().getResource("/images/icons8-password-60.png")
            );

        java.awt.Image passImage =
            passIcon.getImage().getScaledInstance(
                jPanel5.getWidth() - 8,
                jPanel5.getHeight() - 8,
                java.awt.Image.SCALE_SMOOTH
            );

        jLabel7.setIcon(new javax.swing.ImageIcon(passImage));
    }


    private void scaleChildren(
            java.awt.Container container,
            double scale) {

        for (java.awt.Component component : container.getComponents()) {

            java.awt.Rectangle b = component.getBounds();

            component.setBounds(
                (int) (b.x * scale),
                (int) (b.y * scale),
                (int) (b.width * scale),
                (int) (b.height * scale)
            );

            java.awt.Font font = component.getFont();

            if (font != null) {
                component.setFont(
                    font.deriveFont(
                        (float) (font.getSize2D() * scale)
                    )
                );
            }

            // Prevent JLabel text from being cut off
            if (component instanceof javax.swing.JLabel) {
                javax.swing.JLabel label =
                    (javax.swing.JLabel) component;

                java.awt.Dimension preferred =
                    label.getPreferredSize();

                label.setSize(
                    preferred.width + 10,
                    Math.max(label.getHeight(), preferred.height)
                );
            }
        }
    }
        


  
            
            


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        SignInPanel = new RoundedPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        Username = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        RememberMe = new javax.swing.JCheckBox();
        jPanel5 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        Password = new javax.swing.JPasswordField();
        LOGIN = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        SignInPanel.setBackground(new java.awt.Color(255, 255, 255));
        SignInPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        SignInPanel.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 540, 250, 20));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 65)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 0, 0));
        jLabel1.setText("In");
        SignInPanel.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 70, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 65)); // NOI18N
        jLabel3.setText("Sign");
        SignInPanel.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 70, -1, -1));

        jLabel4.setBackground(new java.awt.Color(204, 204, 204));
        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(51, 51, 51));
        jLabel4.setText("Access the Clinic Management System");
        SignInPanel.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 170, -1, 40));

        Username.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        Username.setForeground(new java.awt.Color(204, 204, 204));
        Username.setText("Username");
        Username.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                UsernameFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                UsernameFocusLost(evt);
            }
        });
        Username.addActionListener(this::UsernameActionPerformed);
        SignInPanel.add(Username, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 250, 480, 70));

        jPanel1.setBackground(new java.awt.Color(0, 102, 0));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-user-60.png"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        SignInPanel.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 250, 70, 70));

        RememberMe.setFont(new java.awt.Font("Tahoma", 0, 22)); // NOI18N
        RememberMe.setForeground(new java.awt.Color(0, 102, 0));
        RememberMe.setText("Remember me");
        RememberMe.addActionListener(this::RememberMeActionPerformed);
        SignInPanel.add(RememberMe, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 420, 220, 30));

        jPanel5.setBackground(new java.awt.Color(0, 102, 0));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-password-60.png"))); // NOI18N

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        SignInPanel.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 330, 70, 70));

        Password.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        Password.setText("Password");
        Password.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                PasswordFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                PasswordFocusLost(evt);
            }
        });
        SignInPanel.add(Password, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 330, 480, 70));

        LOGIN.setBackground(new java.awt.Color(0, 102, 0));
        LOGIN.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        LOGIN.setForeground(new java.awt.Color(255, 255, 255));
        LOGIN.setText("LOGIN");
        LOGIN.addActionListener(this::LOGINActionPerformed);
        SignInPanel.add(LOGIN, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 470, 530, 60));

        jLabel11.setBackground(new java.awt.Color(0, 102, 0));
        jLabel11.setFont(new java.awt.Font("Georgia", 2, 24)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 102, 0));
        jLabel11.setText("\"Your Health, Our Priority\"");
        SignInPanel.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 570, 310, 50));

        getContentPane().add(SignInPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 180, 690, 680));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/bgbg (1).png"))); // NOI18N
        jLabel6.setText("jLabel6");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 500, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void UsernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UsernameActionPerformed
    if (Username.getText().equals("Username")) {
    Username.setText("");
    }
        // TODO add your handling code here:
    }//GEN-LAST:event_UsernameActionPerformed

    private void RememberMeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RememberMeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RememberMeActionPerformed

    private void UsernameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_UsernameFocusGained
        if (Username.getText().equals("Username")) {
        Username.setText("");
        Username.setForeground(new java.awt.Color(0, 0, 0));
    }    // TODO add your handling code here:
    }//GEN-LAST:event_UsernameFocusGained

    private void UsernameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_UsernameFocusLost
        if (Username.getText().trim().isEmpty()) {
        Username.setText("Username");
        Username.setForeground(new java.awt.Color(204, 204, 204));
    }            // TODO add your handling code here:
    }//GEN-LAST:event_UsernameFocusLost

    private void PasswordFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_PasswordFocusGained
    
        if (String.valueOf(Password.getPassword()).equals("Password")) {
        Password.setText("");
        Password.setEchoChar('•');
        Password.setForeground(new java.awt.Color(0, 0, 0));
    }
    // TODO add your handling code here:
    }//GEN-LAST:event_PasswordFocusGained

    private void PasswordFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_PasswordFocusLost
        if (Password.getPassword().length == 0) {

                Password.setText("Password");
                Password.setEchoChar((char) 0);

                Password.setForeground(
                        new java.awt.Color(204, 204, 204));
        }


    // TODO add your handling code here:
    }//GEN-LAST:event_PasswordFocusLost

    private void LOGINActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LOGINActionPerformed
        String username = Username.getText().trim();
        String password = String.valueOf(Password.getPassword());

        if (username.isEmpty()
                || password.isEmpty()
                || username.equals("Username")
                || password.equals("Password")) {

                javax.swing.JOptionPane.showMessageDialog(
                        this,
                        "Please enter your username and password.");
                return;
        }

        String sql =
                "SELECT user_id, username, role "
                + "FROM UserAccount "
                + "WHERE username = ? AND password = ? "
                + "AND status = 'Active'";

        try {

                Class.forName("com.mysql.cj.jdbc.Driver");

                try (java.sql.Connection conn =
                        java.sql.DriverManager.getConnection(
                                "jdbc:mysql://localhost:3306/ClinicManagementSystem",
                                "root",
                                "");

                     java.sql.PreparedStatement pst =
                             conn.prepareStatement(sql)) {

                        pst.setString(1, username);
                        pst.setString(2, password);

                        try (java.sql.ResultSet rs = pst.executeQuery()) {

                                if (rs.next()) {

                                        String role = rs.getString("role");

                                        if (!"Admin".equalsIgnoreCase(role)
                                                && !"Staff".equalsIgnoreCase(role)) {

                                                javax.swing.JOptionPane.showMessageDialog(
                                                        this,
                                                        "Unsupported account role.");
                                                return;
                                        }

                                        // SAVE THE LOGGED-IN USER SESSION
                                        UserSession.login(
                                                rs.getInt("user_id"),
                                                rs.getString("username"),
                                                role
                                        );

                                        System.out.println(
                                                "Logged in as: "
                                                + UserSession.getUsername()
                                                + " | Role: "
                                                + UserSession.getRole()
                                                + " | Is Admin: "
                                                + UserSession.isAdmin()
                                        );

                                        if (RememberMe.isSelected()) {
                                                prefs.put("username", username);
                                        } else {
                                                prefs.remove("username");
                                        }

                                        prefs.remove("password");

                                        Dashboard dashboard = new Dashboard();
                                        dashboard.setVisible(true);
                                        this.dispose();

                                } else {

                                        javax.swing.JOptionPane.showMessageDialog(
                                                this,
                                                "Incorrect credentials or inactive account.");
                                }
                        }
                }

        } catch (Exception e) {

                javax.swing.JOptionPane.showMessageDialog(
                        this,
                        "Login Error: " + e.getMessage());
        }

    }//GEN-LAST:event_LOGINActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info :
                     javax.swing.UIManager.getInstalledLookAndFeels()) {

                 if ("Nimbus".equals(info.getName())) {
                javax.swing.UIManager.setLookAndFeel(info.getClassName());
                break;
            }
        }

    } catch (ReflectiveOperationException |
             javax.swing.UnsupportedLookAndFeelException ex) {

             logger.log(java.util.logging.Level.SEVERE, null, ex);
        }

         java.awt.EventQueue.invokeLater(() -> {
             new SignIn().setVisible(true);
        });
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton LOGIN;
    private javax.swing.JPasswordField Password;
    private javax.swing.JCheckBox RememberMe;
    private javax.swing.JPanel SignInPanel;
    private javax.swing.JTextField Username;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    // End of variables declaration//GEN-END:variables

}