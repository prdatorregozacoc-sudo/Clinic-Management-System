import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class Doctors extends javax.swing.JFrame {
    
private final java.util.Map<java.awt.Component, java.awt.Rectangle>
        originalDoctorBounds = new java.util.IdentityHashMap<>();

private final java.util.Map<java.awt.Component, java.awt.Font>
        originalDoctorFonts = new java.util.IdentityHashMap<>();

    private Connection conn;
    private PreparedStatement pst;
    private ResultSet rs;    
    
    private int editingDoctorId = -1;
    private static final String SEARCH_HINT =
        "Search doctors by name or specialization..";
    
    private javax.swing.table.TableRowSorter<
    javax.swing.table.DefaultTableModel> sorter;
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Doctors.class.getName());

 



private void fixDoctorsSidebar() {

        int width = getContentPane().getWidth();
        int height = getContentPane().getHeight();

        if (width <= 0 || height <= 0) {
                return;
        }

        double scaleX = width / 1920.0;
        double scaleY = height / 1080.0;

        javax.swing.JButton[] buttons = {
                Dashboard,
                Patients,
                jButton15,
                Appointments,
                MedicalRecords,
                Services,
                Payments,
                Staff,
                UserAccounts,
                UserAccounts1,
                jButton1
        };

        int[] positionsY = {
                390, 445, 500, 555, 610,
                665, 720, 775, 830, 885, 955
        };

        int buttonX = (int) (60 * scaleX);
        int buttonWidth = (int) (260 * scaleX);
        int buttonHeight = (int) (50 * scaleY);

        for (int i = 0; i < buttons.length; i++) {

                buttons[i].setBounds(
                        buttonX,
                        (int) (positionsY[i] * scaleY),
                        buttonWidth,
                        buttonHeight
                );

                buttons[i].setHorizontalAlignment(
                        javax.swing.SwingConstants.LEFT
                );
        }
}

private void scaleDoctors() {

    int width = getContentPane().getWidth();
    int height = getContentPane().getHeight();

    if (width <= 0 || height <= 0) {
        return;
    }

    double scaleX = width / 1920.0;
    double scaleY = height / 1080.0;
    double fontScale = Math.min(scaleX, scaleY);

    // Scale sidebar components using their ORIGINAL positions
    for (java.util.Map.Entry<java.awt.Component,
            java.awt.Rectangle> entry
            : originalDoctorBounds.entrySet()) {

        java.awt.Component component = entry.getKey();

        // Main content will be positioned separately
        if (component == jLabel1
                || component == jButton11
                || component == jPanel1
                || component == jPanel2
                || component == jTextField1
                || component == jButton3
                || component == Filter
                || component == Sort
                || component == Order) {
            continue;
        }

        java.awt.Rectangle b = entry.getValue();

        component.setBounds(
                (int) (b.x * scaleX),
                (int) (b.y * scaleY),
                (int) (b.width * scaleX),
                (int) (b.height * scaleY)
        );

        java.awt.Font font = originalDoctorFonts.get(component);

        if (font != null) {
            component.setFont(
                    font.deriveFont(
                            Math.max(12f,
                                    (float) (font.getSize2D() * fontScale))
                    )
            );
        }
    }

    // SAME LEFT ALIGNMENT AS PATIENTS
    int contentX = Math.max(245, (int) (width * 0.205));
    int contentWidth = width - contentX - 15;

    // DOCTORS TITLE
    jButton11.setBounds(
            contentX,
            42,
            280,
            60
    );

 
        // SEARCH BAR AND FILTERS - PATIENTS REFERENCE

        int searchY = (int) (160 * scaleY);
        int controlHeight = (int) (50 * scaleY);

        jTextField1.setBounds(
                (int) (400 * scaleX),
                searchY,
                (int) (720 * scaleX),
                controlHeight
        );

        jButton3.setBounds(
                (int) (1120 * scaleX),
                searchY,
                (int) (50 * scaleX),
                controlHeight
        );

        Filter.setBounds(
                (int) (1180 * scaleX),
                searchY,
                (int) (130 * scaleX),
                controlHeight
        );

        Sort.setBounds(
                (int) (1320 * scaleX),
                searchY,
                (int) (150 * scaleX),
                controlHeight
        );

        Order.setBounds(
                (int) (1480 * scaleX),
                searchY,
                (int) (160 * scaleX),
                controlHeight
        );


    // TABLE POSITION - LIKE PATIENTS
    int tableY = searchY + controlHeight + 18;

    // DETAILS PANEL - ABOVE TASKBAR
    int detailsHeight = 285;
    int detailsY = height - detailsHeight - 12;

    int tableHeight = Math.max(
            120,
            detailsY - tableY - 12
    );

    jPanel2.setBounds(
            contentX,
            tableY,
            contentWidth,
            tableHeight
    );

    // DOCTOR DETAILS DIRECTLY BELOW TABLE
    jPanel1.setBounds(
            contentX,
            detailsY,
            contentWidth,
            detailsHeight
    );

    // Apply internal component positions
    fixDoctorsTable();
    fixDoctorDetailsPanel();
    scaleSearchIcon();
    scaleBackground();
        // Match Patients sidebar positioning and sizes
    fixDoctorsSidebar();
    

    getContentPane().revalidate();
    getContentPane().repaint();
}

private void fixDoctorsTable() {

    jPanel2.setLayout(null);

    jScrollPane1.setBounds(
            0,
            0,
            jPanel2.getWidth(),
            jPanel2.getHeight()
    );

    DoctorsTable.setAutoResizeMode(
            javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS
    );

    // Preserve space for Edit and Remove buttons
    int actionColumn = DoctorsTable.getColumnCount() - 1;

    if (actionColumn >= 0) {

        javax.swing.table.TableColumn column =
                DoctorsTable.getColumnModel()
                        .getColumn(actionColumn);

        column.setMinWidth(160);
        column.setPreferredWidth(170);
        column.setMaxWidth(180);
    }

    jPanel2.revalidate();
    jPanel2.repaint();
}


private void scaleSearchIcon() {

    java.net.URL url = getClass().getResource(
            "/images/icons8-search-47.png"
    );

    if (url == null) {
        return;
    }

    javax.swing.ImageIcon icon =
            new javax.swing.ImageIcon(url);

    int size = Math.min(
            jButton3.getWidth(),
            jButton3.getHeight()
    );

    size = Math.max(16, (int) (size * 0.60));

    java.awt.Image image =
            icon.getImage().getScaledInstance(
                    size,
                    size,
                    java.awt.Image.SCALE_SMOOTH
            );

    jButton3.setIcon(
            new javax.swing.ImageIcon(image)
    );

    jButton3.setHorizontalAlignment(
            javax.swing.SwingConstants.CENTER
    );

    jButton3.setVerticalAlignment(
            javax.swing.SwingConstants.CENTER
            
    );
}


private void scaleBackground() {

    int width = getContentPane().getWidth();
    int height = getContentPane().getHeight();

    java.net.URL url = getClass().getResource(
            "/images/Dashgh.png"
    );

    if (url == null) {
        return;
    }

    javax.swing.ImageIcon icon =
            new javax.swing.ImageIcon(url);

    java.awt.Image image =
            icon.getImage().getScaledInstance(
                    width,
                    height,
                    java.awt.Image.SCALE_SMOOTH
            );

    jLabel1.setIcon(
            new javax.swing.ImageIcon(image)
    );

    jLabel1.setBounds(
            0, 0, width, height
    );

    // Keep background behind everything
    getContentPane().setComponentZOrder(
            jLabel1,
            getContentPane().getComponentCount() - 1
    );
}

    public Doctors() {
    initComponents();
    getContentPane().setLayout(null);

// Save original positions for accurate scaling
for (java.awt.Component component
        : getContentPane().getComponents()) {

    originalDoctorBounds.put(
            component,
            new java.awt.Rectangle(component.getBounds())
    );

    originalDoctorFonts.put(
            component,
            component.getFont()
    );
}
    
    
    disableDoctorTableEditing();

    setupDoctorSearch();

addActionColumn();
designDoctorsTable();
configureActionColumn();

        // FILTER OPTIONS
        Filter.setModel(
                new javax.swing.DefaultComboBoxModel<>(
                        new String[] {
                                "FILTER BY: ALL",
                                "Available",
                                "Unavailable"
                        }
                )
        );

    // SORT OPTIONS
    Sort.setModel(
            new javax.swing.DefaultComboBoxModel<>(
                    new String[] {
                        "SORT BY: DEFAULT",
                        "First Name",
                        "Last Name",
                        "Doctor ID",
                        "Specialization",
                        "Date Added",
                        "Status"
                    }
            )
    );

    // ORDER OPTIONS
    Order.setModel(
            new javax.swing.DefaultComboBoxModel<>(
                    new String[] {
                        "ORDER",
                        "ASCENDING",
                        "DESCENDING"
                    }
            )
    );

    DefaultTableModel model =
            (DefaultTableModel) DoctorsTable.getModel();

    sorter =
            new javax.swing.table.TableRowSorter<>(model);

    DoctorsTable.setRowSorter(sorter);

    connectDatabase();
    loadDoctors();

jComboBox1.setSelectedItem("Available");

    Clear.addActionListener(
            e -> clearDoctorFields()
    );

    // Prevent search field from being automatically selected
    java.awt.EventQueue.invokeLater(() -> {
        getContentPane().setFocusable(true);
        getContentPane().requestFocusInWindow();
    });
    
    setExtendedState(
        javax.swing.JFrame.MAXIMIZED_BOTH
);
addComponentListener(new java.awt.event.ComponentAdapter() {
        @Override
        public void componentResized(java.awt.event.ComponentEvent evt) {
                scaleDoctors();
        }
});

java.awt.EventQueue.invokeLater(() -> {
        scaleDoctors();
});
}
private void setupDoctorSearch() {

    jTextField1.setText(SEARCH_HINT);

    jTextField1.setFont(
            new java.awt.Font(
                    "Segoe UI",
                    java.awt.Font.PLAIN,
                    16
            )
    );

    jTextField1.setForeground(
            new java.awt.Color(120, 120, 120)
    );

    jTextField1.addFocusListener(
            new java.awt.event.FocusAdapter() {

        @Override
        public void focusGained(
                java.awt.event.FocusEvent evt) {

            if (jTextField1.getText().equals(SEARCH_HINT)) {
                jTextField1.setText("");

                jTextField1.setForeground(
                        new java.awt.Color(40, 40, 40)
                );
            }
        }

        @Override
        public void focusLost(
                java.awt.event.FocusEvent evt) {

            if (jTextField1.getText().trim().isEmpty()) {
                jTextField1.setText(SEARCH_HINT);

                jTextField1.setForeground(
                        new java.awt.Color(120, 120, 120)
                );
            }
        }
    });
}

private void disableDoctorTableEditing() {

        DoctorsTable.setDefaultEditor(
                Object.class,
                null
        );

        // Prevent direct editing of table values
        DoctorsTable.setSurrendersFocusOnKeystroke(false);
}


private void searchDoctors() {

        if (sorter == null) {
                return;
        }

        String searchText = jTextField1.getText().trim();

        // Ignore search placeholder
        if (searchText.equals(SEARCH_HINT)) {
                searchText = "";
        }

        String selectedFilter = Filter.getSelectedItem() == null
                ? "FILTER BY: ALL"
                : Filter.getSelectedItem().toString().trim();

        java.util.List<javax.swing.RowFilter<Object, Object>> filters =
                new java.util.ArrayList<>();

        // Search by doctor ID, name, specialization,
        // contact number, or email
        if (!searchText.isEmpty()) {

                String pattern = "(?i)"
                        + java.util.regex.Pattern.quote(searchText);

                filters.add(
                        javax.swing.RowFilter.regexFilter(
                                pattern, 0, 1, 2, 3, 4, 5
                        )
                );
        }

        // Filter by doctor availability
        // Column 7 = Status
        if (selectedFilter.equalsIgnoreCase("Available")
                || selectedFilter.equalsIgnoreCase("Unavailable")) {

                String statusPattern = "(?i)^"
                        + java.util.regex.Pattern.quote(selectedFilter)
                        + "$";

                filters.add(
                        javax.swing.RowFilter.regexFilter(
                                statusPattern, 7
                        )
                );
        }

        // Apply search and filter together
        if (filters.isEmpty()) {
                sorter.setRowFilter(null);
        } else {
                sorter.setRowFilter(
                        javax.swing.RowFilter.andFilter(filters)
                );
        }
}
private void sortDoctors() {

        String selectedSort =
                Sort.getSelectedItem().toString();

        String selectedOrder =
                Order.getSelectedItem().toString();

        int column = -1;

        switch (selectedSort) {

                case "First Name":
                        column = 1;
                        break;

                case "Last Name":
                        column = 2;
                        break;

                case "Doctor ID":
                        column = 0;
                        break;

                case "Specialization":
                        column = 3;
                        break;

                case "Date Added":
                        column = 6;
                        break;

                case "Status":
                        column = 7;
                        break;
        }

        // SORT BY selected = reset sorting
        if (column == -1) {

                sorter.setSortKeys(null);
                return;
        }

        javax.swing.SortOrder sortOrder;

        if (selectedOrder.equals("DESCENDING")) {

                sortOrder =
                        javax.swing.SortOrder.DESCENDING;

        } else {

                sortOrder =
                        javax.swing.SortOrder.ASCENDING;
        }

        java.util.List<
                javax.swing.RowSorter.SortKey
        > sortKeys =
                new java.util.ArrayList<>();

        sortKeys.add(
                new javax.swing.RowSorter.SortKey(
                        column,
                        sortOrder
                )
        );

        sorter.setSortKeys(sortKeys);
        sorter.sort();
}
private void saveDoctor() {

        String firstName =
                jTextField2.getText().trim();

        String lastName =
                jTextField3.getText().trim();

        String specialization =
                jTextField4.getText().trim();

        String contactNumber =
                jTextField5.getText().trim();

        String email =
                jTextField6.getText().trim();

        String status =
jComboBox1.getSelectedItem().toString();

        // =========================
        // VALIDATION
        // =========================

        if (firstName.isEmpty()
                || lastName.isEmpty()
                || specialization.isEmpty()
                || status.isEmpty()) {

                JOptionPane.showMessageDialog(
                        this,
                        "Please complete the required doctor information."
                );

                return;
        }


        // =========================
        // ADD NEW DOCTOR
        // =========================

        if (editingDoctorId == -1) {

                String sql =
                        "INSERT INTO Doctors "
                        + "(first_name, last_name, specialization, "
                        + "contact_number, email, status) "
                        + "VALUES (?, ?, ?, ?, ?, ?)";

                try {

                        pst = conn.prepareStatement(sql);

                        pst.setString(1, firstName);
                        pst.setString(2, lastName);
                        pst.setString(3, specialization);
                        pst.setString(4, contactNumber);
                        pst.setString(5, email);
                        pst.setString(6, status);

                        pst.executeUpdate();

                        JOptionPane.showMessageDialog(
                                this,
                                "Doctor added successfully!"
                        );

                        clearDoctorFields();

                        loadDoctors();

                } catch (SQLException e) {

                        JOptionPane.showMessageDialog(
                                this,
                                "Failed to add doctor!\n"
                                + e.getMessage()
                        );
                }


        // =========================
        // UPDATE EXISTING DOCTOR
        // =========================

        } else {

                String sql =
                        "UPDATE Doctors SET "
                        + "first_name = ?, "
                        + "last_name = ?, "
                        + "specialization = ?, "
                        + "contact_number = ?, "
                        + "email = ?, "
                        + "status = ? "
                        + "WHERE doctor_id = ?";

                try {

                        pst = conn.prepareStatement(sql);

                        pst.setString(1, firstName);
                        pst.setString(2, lastName);
                        pst.setString(3, specialization);
                        pst.setString(4, contactNumber);
                        pst.setString(5, email);
                        pst.setString(6, status);

                        pst.setInt(
                                7,
                                editingDoctorId
                        );

                        pst.executeUpdate();

                        JOptionPane.showMessageDialog(
                                this,
                                "Doctor updated successfully!"
                        );

                        clearDoctorFields();

                        loadDoctors();

                } catch (SQLException e) {

                        JOptionPane.showMessageDialog(
                                this,
                                "Failed to update doctor!\n"
                                + e.getMessage()
                        );
                }
        }
}
private void addActionColumn() {

        javax.swing.table.DefaultTableModel model =
                (javax.swing.table.DefaultTableModel)
                DoctorsTable.getModel();

        model.addColumn("");
}
private void configureActionColumn() {

        int actionColumn =
                DoctorsTable.getColumnCount() - 1;

        DoctorsTable.setRowHeight(38);

        DoctorsTable.getColumnModel()
                .getColumn(actionColumn)
                .setMinWidth(160);

        DoctorsTable.getColumnModel()
                .getColumn(actionColumn)
                .setPreferredWidth(160);

        DoctorsTable.getColumnModel()
                .getColumn(actionColumn)
                .setMaxWidth(180);

        DoctorsTable.getColumnModel()
                .getColumn(actionColumn)
                .setCellRenderer(
                        new DoctorActionRenderer()
                );

        DoctorsTable.getColumnModel()
                .getColumn(actionColumn)
                .setCellEditor(
                        new DoctorActionEditor()
                );
}
private class DoctorActionRenderer
        extends javax.swing.JPanel
        implements javax.swing.table.TableCellRenderer {

        private final javax.swing.JButton editButton;
        private final javax.swing.JButton removeButton;

        public DoctorActionRenderer() {

                setLayout(
                        new java.awt.FlowLayout(
                                java.awt.FlowLayout.CENTER,
                                8,
                                3
                        )
                );

                editButton =
                        new javax.swing.JButton("Edit");

                removeButton =
                        new javax.swing.JButton("Remove");


                // EDIT - GREEN
                editButton.setBackground(
                        new java.awt.Color(0, 153, 76)
                );

                editButton.setForeground(
                        java.awt.Color.WHITE
                );


                // REMOVE - RED
                removeButton.setBackground(
                        new java.awt.Color(255, 0, 0)
                );

                removeButton.setForeground(
                        java.awt.Color.WHITE
                );

                editButton.setFocusable(false);
                removeButton.setFocusable(false);

                add(editButton);
                add(removeButton);
        }

        @Override
        public java.awt.Component getTableCellRendererComponent(
                javax.swing.JTable table,
                Object value,
                boolean isSelected,
                boolean hasFocus,
                int row,
                int column) {

                if (isSelected) {

                        setBackground(
                                table.getSelectionBackground()
                        );

                } else {

                        setBackground(
                                java.awt.Color.WHITE
                        );
                }

                return this;
        }
}
private class DoctorActionEditor
        extends javax.swing.AbstractCellEditor
        implements javax.swing.table.TableCellEditor {

        private final javax.swing.JPanel panel;

        private final javax.swing.JButton editButton;
        private final javax.swing.JButton removeButton;

        private int selectedRow;


        public DoctorActionEditor() {

                panel =
                        new javax.swing.JPanel(
                                new java.awt.FlowLayout(
                                        java.awt.FlowLayout.CENTER,
                                        8,
                                        3
                                )
                        );


                editButton =
                        new javax.swing.JButton("Edit");

                removeButton =
                        new javax.swing.JButton("Remove");


                // EDIT - GREEN
                editButton.setBackground(
                        new java.awt.Color(0, 153, 76)
                );

                editButton.setForeground(
                        java.awt.Color.WHITE
                );


                // REMOVE - RED
                removeButton.setBackground(
                        new java.awt.Color(255, 0, 0)
                );

                removeButton.setForeground(
                        java.awt.Color.WHITE
                );

                editButton.setFocusable(false);
                removeButton.setFocusable(false);


                editButton.addActionListener(e -> {

                        int row = selectedRow;

                        fireEditingStopped();

                        editDoctor(row);
                });


                removeButton.addActionListener(e -> {

                        int row = selectedRow;

                        fireEditingStopped();

                        removeDoctor(row);
                });


                panel.add(editButton);
                panel.add(removeButton);
        }


        @Override
        public java.awt.Component getTableCellEditorComponent(
                javax.swing.JTable table,
                Object value,
                boolean isSelected,
                int row,
                int column) {

                selectedRow =
                        table.convertRowIndexToModel(row);

                return panel;
        }


        @Override
        public Object getCellEditorValue() {

                return "";
        }
}
private void editDoctor(int row) {

        if (row < 0) {
                return;
        }

        javax.swing.table.DefaultTableModel model =
                (javax.swing.table.DefaultTableModel)
                DoctorsTable.getModel();


        editingDoctorId =
                Integer.parseInt(
                        model.getValueAt(row, 0)
                                .toString()
                );


        // First Name
        jTextField2.setText(
                getTableValue(model, row, 1)
        );


        // Last Name
        jTextField3.setText(
                getTableValue(model, row, 2)
        );


        // Specialization
        jTextField4.setText(
                getTableValue(model, row, 3)
        );


        // Contact Number
        jTextField5.setText(
                getTableValue(model, row, 4)
        );


        // Email
        jTextField6.setText(
                getTableValue(model, row, 5)
        );


        // Column 6 = Date Added
        // Column 7 = Status

jComboBox1.setSelectedItem(
                getTableValue(model, row, 7)
        );


        // Change Save button text while editing
        Save.setText("Update");
}

private void clearDoctorFields() {

        jTextField2.setText("");
        jTextField3.setText("");
        jTextField4.setText("");
        jTextField5.setText("");
        jTextField6.setText("");
jComboBox1.setSelectedItem("Available");
        // Exit edit mode
        editingDoctorId = -1;

        // Return Update button to Save
        Save.setText("Save");

        DoctorsTable.clearSelection();

        jTextField2.requestFocusInWindow();
}
private String getTableValue(
        javax.swing.table.DefaultTableModel model,
        int row,
        int column) {

        Object value =
                model.getValueAt(row, column);

        if (value == null) {
                return "";
        }

        return value.toString();
}
private void removeDoctor(int row) {

    if (row < 0) {
        return;
    }

    DefaultTableModel model =
            (DefaultTableModel) DoctorsTable.getModel();

    int doctorId =
            Integer.parseInt(
                    model.getValueAt(row, 0).toString()
            );

    String doctorName =
            model.getValueAt(row, 1).toString()
            + " "
            + model.getValueAt(row, 2).toString();

    int confirm =
            JOptionPane.showConfirmDialog(
                    this,
                    "Remove Dr. " + doctorName
                    + " and move to Archive?",
                    "Confirm Remove",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE
            );

    if (confirm != JOptionPane.YES_OPTION) {
        return;
    }

    String sql =
            "UPDATE Doctors "
            + "SET status = 'Archived' "
            + "WHERE doctor_id = ?";

    try {

        pst = conn.prepareStatement(sql);

        pst.setInt(1, doctorId);

        pst.executeUpdate();

        JOptionPane.showMessageDialog(
                this,
                "Doctor moved to Archive successfully!"
        );

        loadDoctors();
        clearDoctorFields();

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "Failed to remove doctor!\n"
                + e.getMessage()
        );
    }
}
private void loadDoctors() {

        if (conn == null) {
                return;
        }

        DefaultTableModel model =
                (DefaultTableModel)
                DoctorsTable.getModel();

        // Remove NetBeans sample/empty rows
        model.setRowCount(0);

String sql =
        "SELECT doctor_id, first_name, last_name, "
        + "specialization, contact_number, email, "
        + "date_added, status "
        + "FROM Doctors "
        + "WHERE status <> 'Archived'";
        try {

                pst = conn.prepareStatement(sql);
                rs = pst.executeQuery();

                while (rs.next()) {

                        Object[] row = {

                                rs.getInt("doctor_id"),
                                rs.getString("first_name"),
                                rs.getString("last_name"),
                                rs.getString("specialization"),
                                rs.getString("contact_number"),
                                rs.getString("email"),
                                rs.getTimestamp("date_added"),
                                rs.getString("status")
                        };

                        model.addRow(row);
                }

        } catch (SQLException e) {

                JOptionPane.showMessageDialog(
                        this,
                        "Failed to load doctors!\n"
                        + e.getMessage()
                );
        }
}
private void connectDatabase() {

        try {

                Class.forName("com.mysql.cj.jdbc.Driver");

                conn = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/ClinicManagementSystem",
                        "root",
                        ""
                );

                System.out.println("Doctors Database Connected!");

        } catch (ClassNotFoundException | SQLException e) {

                JOptionPane.showMessageDialog(
                        this,
                        "Database Connection Failed!\n"
                        + e.getMessage()
                );
        }
}

private void fixDoctorDetailsPanel() {

    int width = jPanel1.getWidth();

    jPanel1.setLayout(null);
    jPanel1.setVisible(true);
    jPanel1.setOpaque(true);

    jPanel1.setBackground(
            new java.awt.Color(245, 252, 248)
    );

    jPanel1.setBorder(
            javax.swing.BorderFactory.createLineBorder(
                    new java.awt.Color(0, 102, 51), 2
            )
    );

    jLabel2.setBounds(25, 10, 250, 35);

    int labelX = 25;
    int fieldX = 145;
    int fieldHeight = 34;

    if (width >= 720) {

        // Two-column layout
        int rightLabelX = width / 2;
        int rightFieldX = rightLabelX + 140;

        int fieldWidth = Math.max(
                100,
                Math.min(
                        320,
                        Math.min(
                                rightLabelX - fieldX - 20,
                                width - rightFieldX - 25
                        )
                )
        );

        int row1 = 55;
        int row2 = 103;
        int row3 = 151;

        jLabel3.setBounds(labelX, row1, 115, fieldHeight);
        jTextField2.setBounds(fieldX, row1, fieldWidth, fieldHeight);

        jLabel4.setBounds(labelX, row2, 115, fieldHeight);
        jTextField3.setBounds(fieldX, row2, fieldWidth, fieldHeight);

        jLabel5.setBounds(labelX, row3, 115, fieldHeight);
        jTextField4.setBounds(fieldX, row3, fieldWidth, fieldHeight);

        jLabel7.setBounds(rightLabelX, row1, 135, fieldHeight);
        jTextField5.setBounds(rightFieldX, row1, fieldWidth, fieldHeight);

        jLabel8.setBounds(rightLabelX, row2, 135, fieldHeight);
        jTextField6.setBounds(rightFieldX, row2, fieldWidth, fieldHeight);

        jLabel9.setBounds(rightLabelX, row3, 135, fieldHeight);
        jComboBox1.setBounds(rightFieldX, row3, fieldWidth, fieldHeight);

        int buttonY = 200;
        int saveX = rightFieldX + fieldWidth - 110;

        Clear.setBounds(saveX - 120, buttonY, 110, 34);
        Save.setBounds(saveX, buttonY, 110, 34);

    } else {

        // Single-column layout for narrow windows
        int fieldWidth = Math.max(100, width - fieldX - 25);

        int[] rows = {50, 95, 140, 185, 230, 275};

        jLabel3.setBounds(labelX, rows[0], 115, fieldHeight);
        jTextField2.setBounds(fieldX, rows[0], fieldWidth, fieldHeight);

        jLabel4.setBounds(labelX, rows[1], 115, fieldHeight);
        jTextField3.setBounds(fieldX, rows[1], fieldWidth, fieldHeight);

        jLabel5.setBounds(labelX, rows[2], 115, fieldHeight);
        jTextField4.setBounds(fieldX, rows[2], fieldWidth, fieldHeight);

        jLabel7.setBounds(labelX, rows[3], 115, fieldHeight);
        jTextField5.setBounds(fieldX, rows[3], fieldWidth, fieldHeight);

        jLabel8.setBounds(labelX, rows[4], 115, fieldHeight);
        jTextField6.setBounds(fieldX, rows[4], fieldWidth, fieldHeight);

        jLabel9.setBounds(labelX, rows[5], 115, fieldHeight);
        jComboBox1.setBounds(fieldX, rows[5], fieldWidth, fieldHeight);

        Save.setBounds(width - 135, 330, 110, 34);
        Clear.setBounds(width - 255, 330, 110, 34);
    }

    jPanel1.revalidate();
    jPanel1.repaint();
}

private void designDoctorsTable() {

        // =========================
        // TABLE BODY
        // =========================
        DoctorsTable.setFont(
                new java.awt.Font(
                        "Segoe UI",
                        java.awt.Font.PLAIN,
                        14
                )
        );

        DoctorsTable.setRowHeight(32);

        DoctorsTable.setBackground(
                java.awt.Color.WHITE
        );

        DoctorsTable.setForeground(
                new java.awt.Color(40, 40, 40)
        );

        DoctorsTable.setSelectionBackground(
                new java.awt.Color(222, 246, 236)
        );

        DoctorsTable.setSelectionForeground(
                new java.awt.Color(0, 102, 51)
        );

        DoctorsTable.setGridColor(
                new java.awt.Color(220, 235, 228)
        );

        DoctorsTable.setShowHorizontalLines(true);
        DoctorsTable.setShowVerticalLines(false);

        DoctorsTable.setIntercellSpacing(
                new java.awt.Dimension(0, 1)
        );


        // =========================
        // GREEN TABLE HEADER
        // =========================
        javax.swing.table.JTableHeader header =
                DoctorsTable.getTableHeader();

        header.setPreferredSize(
                new java.awt.Dimension(
                        header.getPreferredSize().width,
                        38
                )
        );

        header.setReorderingAllowed(false);


        // Same green as Patients
        javax.swing.table.DefaultTableCellRenderer headerRenderer =
                new javax.swing.table.DefaultTableCellRenderer();

        headerRenderer.setBackground(
                new java.awt.Color(0, 102, 51)
        );

        headerRenderer.setForeground(
                java.awt.Color.WHITE
        );

        headerRenderer.setFont(
                new java.awt.Font(
                        "Segoe UI",
                        java.awt.Font.BOLD,
                        14
                )
        );

        headerRenderer.setHorizontalAlignment(
                javax.swing.SwingConstants.CENTER
        );

        headerRenderer.setOpaque(true);


        // Apply green design to ALL headers
        for (int i = 0;
            i < DoctorsTable.getColumnCount();
            i++) {
            DoctorsTable.getColumnModel()
                    .getColumn(i)
                    .setHeaderRenderer(headerRenderer);
        }


        // =========================
        // CENTER TABLE DATA
        // =========================
        javax.swing.table.DefaultTableCellRenderer center =
                new javax.swing.table.DefaultTableCellRenderer();

        center.setHorizontalAlignment(
                javax.swing.SwingConstants.CENTER
        );

        for (int i = 0;
                i < DoctorsTable.getColumnCount();
                i++) {

            DoctorsTable.getColumnModel()
                    .getColumn(i)
                    .setCellRenderer(center);
        }


        // White background below rows
        jScrollPane1.getViewport().setBackground(
                java.awt.Color.WHITE
        );

        DoctorsTable.getTableHeader().repaint();
        DoctorsTable.repaint();
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        Patients = new javax.swing.JButton();
        MedicalRecords = new javax.swing.JButton();
        Services = new javax.swing.JButton();
        Payments = new javax.swing.JButton();
        Staff = new javax.swing.JButton();
        Dashboard = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        UserAccounts = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        DoctorsTable = new javax.swing.JTable();
        Appointments = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jButton15 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        Clear = new javax.swing.JButton();
        Save = new javax.swing.JButton();
        jTextField6 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        Filter = new javax.swing.JComboBox<>();
        Sort = new javax.swing.JComboBox<>();
        Order = new javax.swing.JComboBox<>();
        UserAccounts1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton1.setForeground(new java.awt.Color(204, 0, 0));
        jButton1.setText("Log Out");
        jButton1.setBorderPainted(false);
        jButton1.setContentAreaFilled(false);
        jButton1.setDefaultCapable(false);
        jButton1.setFocusPainted(false);
        jButton1.setFocusable(false);
        jButton1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton1.addActionListener(this::jButton1ActionPerformed);
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 990, 260, 60));

        Patients.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Patients.setForeground(new java.awt.Color(255, 255, 255));
        Patients.setText("Patients");
        Patients.setBorderPainted(false);
        Patients.setContentAreaFilled(false);
        Patients.setDefaultCapable(false);
        Patients.setFocusPainted(false);
        Patients.setFocusable(false);
        Patients.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Patients.addActionListener(this::PatientsActionPerformed);
        getContentPane().add(Patients, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 440, 260, 80));

        MedicalRecords.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        MedicalRecords.setForeground(new java.awt.Color(255, 255, 255));
        MedicalRecords.setText("Medical Records");
        MedicalRecords.setBorderPainted(false);
        MedicalRecords.setContentAreaFilled(false);
        MedicalRecords.setDefaultCapable(false);
        MedicalRecords.setFocusPainted(false);
        MedicalRecords.setFocusable(false);
        MedicalRecords.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        MedicalRecords.addActionListener(this::MedicalRecordsActionPerformed);
        getContentPane().add(MedicalRecords, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 610, 260, 90));

        Services.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Services.setForeground(new java.awt.Color(255, 255, 255));
        Services.setText("Services");
        Services.setBorderPainted(false);
        Services.setContentAreaFilled(false);
        Services.setDefaultCapable(false);
        Services.setFocusPainted(false);
        Services.setFocusable(false);
        Services.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Services.addActionListener(this::ServicesActionPerformed);
        getContentPane().add(Services, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 670, 260, 90));

        Payments.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Payments.setForeground(new java.awt.Color(255, 255, 255));
        Payments.setText("Payments");
        Payments.setBorderPainted(false);
        Payments.setContentAreaFilled(false);
        Payments.setDefaultCapable(false);
        Payments.setFocusPainted(false);
        Payments.setFocusable(false);
        Payments.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Payments.addActionListener(this::PaymentsActionPerformed);
        getContentPane().add(Payments, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 730, 260, 80));

        Staff.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Staff.setForeground(new java.awt.Color(255, 255, 255));
        Staff.setText("Staff");
        Staff.setBorderPainted(false);
        Staff.setContentAreaFilled(false);
        Staff.setDefaultCapable(false);
        Staff.setFocusPainted(false);
        Staff.setFocusable(false);
        Staff.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Staff.addActionListener(this::StaffActionPerformed);
        getContentPane().add(Staff, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 780, 260, 80));

        Dashboard.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Dashboard.setForeground(new java.awt.Color(255, 255, 255));
        Dashboard.setText("Dashboard");
        Dashboard.setBorderPainted(false);
        Dashboard.setContentAreaFilled(false);
        Dashboard.setDefaultCapable(false);
        Dashboard.setFocusPainted(false);
        Dashboard.setFocusable(false);
        Dashboard.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Dashboard.addActionListener(this::DashboardActionPerformed);
        getContentPane().add(Dashboard, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 380, 260, 80));

        jButton11.setFont(new java.awt.Font("Segoe UI", 1, 40)); // NOI18N
        jButton11.setText("Doctors");
        jButton11.setBorderPainted(false);
        jButton11.setContentAreaFilled(false);
        jButton11.setDefaultCapable(false);
        jButton11.setFocusPainted(false);
        jButton11.setFocusable(false);
        jButton11.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton11.addActionListener(this::jButton11ActionPerformed);
        getContentPane().add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 40, 260, -1));

        UserAccounts.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        UserAccounts.setForeground(new java.awt.Color(255, 255, 255));
        UserAccounts.setText("User Accounts");
        UserAccounts.setBorderPainted(false);
        UserAccounts.setContentAreaFilled(false);
        UserAccounts.setDefaultCapable(false);
        UserAccounts.setFocusPainted(false);
        UserAccounts.setFocusable(false);
        UserAccounts.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        UserAccounts.addActionListener(this::UserAccountsActionPerformed);
        getContentPane().add(UserAccounts, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 830, 260, 80));

        jPanel2.setBackground(new java.awt.Color(222, 246, 236));

        DoctorsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Doctor ID", "First Name", "Last Name", "Specialization", "Contact Number", "Email", "Date Added", "Status"
            }
        ));
        DoctorsTable.setFocusCycleRoot(true);
        DoctorsTable.setGridColor(new java.awt.Color(231, 250, 250));
        DoctorsTable.setShowGrid(true);
        DoctorsTable.setSurrendersFocusOnKeystroke(true);
        jScrollPane1.setViewportView(DoctorsTable);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 1474, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 473, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 230, 1480, 480));

        Appointments.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Appointments.setForeground(new java.awt.Color(255, 255, 255));
        Appointments.setText("Appointments");
        Appointments.setBorderPainted(false);
        Appointments.setContentAreaFilled(false);
        Appointments.setDefaultCapable(false);
        Appointments.setFocusPainted(false);
        Appointments.setFocusable(false);
        Appointments.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Appointments.addActionListener(this::AppointmentsActionPerformed);
        getContentPane().add(Appointments, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 550, 260, 90));

        jTextField1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jTextField1.setText("Search doctors by name or specializations..");
        getContentPane().add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 160, 720, 50));

        jButton15.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton15.setForeground(new java.awt.Color(0, 102, 51));
        jButton15.setText("Doctors");
        jButton15.setDefaultCapable(false);
        jButton15.setFocusPainted(false);
        jButton15.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton15.addActionListener(this::jButton15ActionPerformed);
        getContentPane().add(jButton15, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 510, 260, 50));

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-search-47.png"))); // NOI18N
        jButton3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 51)));
        jButton3.setBorderPainted(false);
        jButton3.addActionListener(this::jButton3ActionPerformed);
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 160, -1, -1));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 102, 51));
        jLabel2.setText("Doctor Details");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("First Name");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Last Name");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setText("Specialization");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setText("Contact Number");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel8.setText("Email");

        Clear.setBackground(new java.awt.Color(240, 250, 244));
        Clear.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Clear.setForeground(new java.awt.Color(0, 102, 51));
        Clear.setText("Clear");

        Save.setBackground(new java.awt.Color(0, 102, 51));
        Save.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Save.setForeground(new java.awt.Color(255, 255, 255));
        Save.setText("Save");
        Save.addActionListener(this::SaveActionPerformed);

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel9.setText("Status");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Available", "Unavailable", " " }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel5)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel3)
                                    .addGap(16, 16, 16)))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(50, 50, 50)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(jLabel9)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(79, 79, 79)
                            .addComponent(Clear)
                            .addGap(18, 18, 18)
                            .addComponent(Save))
                        .addComponent(jComboBox1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(725, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Clear, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Save, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(77, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 730, 1480, 270));

        Filter.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Filter.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "FILTER BY: ALL", "Available", "Unavailable", " " }));
        Filter.addActionListener(this::FilterActionPerformed);
        getContentPane().add(Filter, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 160, 120, 50));

        Sort.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Sort.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SORT BY: DEFAULT", "First Name", "Last Name", "Patient ID", "Birth Date", "Gender" }));
        Sort.addActionListener(this::SortActionPerformed);
        getContentPane().add(Sort, new org.netbeans.lib.awtextra.AbsoluteConstraints(1310, 160, -1, 50));

        Order.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Order.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ORDER", "ASCENDING", "DESCENDING" }));
        Order.addActionListener(this::OrderActionPerformed);
        getContentPane().add(Order, new org.netbeans.lib.awtextra.AbsoluteConstraints(1460, 160, 100, 50));

        UserAccounts1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        UserAccounts1.setForeground(new java.awt.Color(255, 255, 255));
        UserAccounts1.setText("Archive");
        UserAccounts1.setBorderPainted(false);
        UserAccounts1.setContentAreaFilled(false);
        UserAccounts1.setDefaultCapable(false);
        UserAccounts1.setFocusPainted(false);
        UserAccounts1.setFocusable(false);
        UserAccounts1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        UserAccounts1.addActionListener(this::UserAccounts1ActionPerformed);
        getContentPane().add(UserAccounts1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 890, 260, 80));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Dashgh.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1930, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void PatientsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PatientsActionPerformed
        Patients Patients = new Patients();
        Patients.setVisible(true);
        this.dispose();            // TODO add your handling code here:
    }//GEN-LAST:event_PatientsActionPerformed

    private void MedicalRecordsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MedicalRecordsActionPerformed
    MedicalRecords records = new MedicalRecords();
    records.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_MedicalRecordsActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton11ActionPerformed

    private void AppointmentsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AppointmentsActionPerformed
        Appointments appointments = new Appointments();
        appointments.setVisible(true);
        this.dispose();           // TODO add your handling code here:
    }//GEN-LAST:event_AppointmentsActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
                searchDoctors();

    }//GEN-LAST:event_jButton3ActionPerformed

    private void DashboardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DashboardActionPerformed
       Dashboard dashboard = new Dashboard();
        dashboard.setVisible(true);
         this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_DashboardActionPerformed

    private void ServicesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ServicesActionPerformed
    Services services = new Services();
    services.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_ServicesActionPerformed

    private void PaymentsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PaymentsActionPerformed
    Payments payments = new Payments();
    payments.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_PaymentsActionPerformed

    private void StaffActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StaffActionPerformed
    Staff staff = new Staff();
    staff.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_StaffActionPerformed

    private void UserAccountsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UserAccountsActionPerformed
    UserAccounts accounts = new UserAccounts();
    accounts.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_UserAccountsActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
    Doctors doctors = new Doctors();
    doctors.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton15ActionPerformed

    private void UserAccounts1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UserAccounts1ActionPerformed
        Archive archive = new Archive();
        archive.setVisible(true);
        this.dispose();       // TODO add your handling code here:
    }//GEN-LAST:event_UserAccounts1ActionPerformed

    private void SaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SaveActionPerformed
        saveDoctor();
        // TODO add your handling code here:
    }//GEN-LAST:event_SaveActionPerformed

    private void FilterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FilterActionPerformed
        searchDoctors();

        // TODO add your handling code here:
    }//GEN-LAST:event_FilterActionPerformed

    private void SortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SortActionPerformed
        sortDoctors();

        // TODO add your handling code here:
    }//GEN-LAST:event_SortActionPerformed

    private void OrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OrderActionPerformed
        sortDoctors();
        // TODO add your handling code here:
    }//GEN-LAST:event_OrderActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    UserSession.logout();
    SignIn logout = new SignIn();
    logout.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Doctors().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Appointments;
    private javax.swing.JButton Clear;
    private javax.swing.JButton Dashboard;
    private javax.swing.JTable DoctorsTable;
    private javax.swing.JComboBox<String> Filter;
    private javax.swing.JButton MedicalRecords;
    private javax.swing.JComboBox<String> Order;
    private javax.swing.JButton Patients;
    private javax.swing.JButton Payments;
    private javax.swing.JButton Save;
    private javax.swing.JButton Services;
    private javax.swing.JComboBox<String> Sort;
    private javax.swing.JButton Staff;
    private javax.swing.JButton UserAccounts;
    private javax.swing.JButton UserAccounts1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton3;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    // End of variables declaration//GEN-END:variables
}
