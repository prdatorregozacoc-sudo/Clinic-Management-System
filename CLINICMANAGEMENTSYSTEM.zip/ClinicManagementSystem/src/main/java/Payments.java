import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class Payments extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Payments.class.getName());

        private Connection conn;
        private PreparedStatement pst;
        private ResultSet rs;
        private TableRowSorter<DefaultTableModel> sorter;
        private int editingPaymentId = -1;
        
    public Payments() {

    initComponents();
        getContentPane().setLayout(null);

    setupPaymentActions();

    setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);

    designSearchBar();
    designPaymentsTable();
    designPaymentDetailsPanel();

    connectDatabase();
    loadPayments();

    DefaultTableModel model =
            (DefaultTableModel) PaymentsTable.getModel();

    sorter = new TableRowSorter<>(model);
    PaymentsTable.setRowSorter(sorter);
    
    
jTextField1.getDocument().addDocumentListener(
        new javax.swing.event.DocumentListener() {

                @Override
                public void insertUpdate(
                        javax.swing.event.DocumentEvent e) {
                        searchPayments();
                }

                @Override
                public void removeUpdate(
                        javax.swing.event.DocumentEvent e) {
                        searchPayments();
                }

                @Override
                public void changedUpdate(
                        javax.swing.event.DocumentEvent e) {
                        searchPayments();
                }
        }
);


    jButton5.addActionListener(
            e -> clearPaymentForm()
    );

    jButton6.addActionListener(
            e -> savePayment()
    );

    // Keep the search field unfocused when the page opens
    getContentPane().setFocusable(true);

    addWindowListener(new java.awt.event.WindowAdapter() {
        @Override
        public void windowOpened(java.awt.event.WindowEvent evt) {
            getContentPane().requestFocusInWindow();
        }
    });

    addComponentListener(new java.awt.event.ComponentAdapter() {
        @Override
        public void componentResized(java.awt.event.ComponentEvent evt) {
            scalePayments();
        }
    });

    java.awt.EventQueue.invokeLater(() -> scalePayments());
}

    private java.awt.Image originalPaymentsBackground;


private void fixPaymentsSidebar() {

        int width = getContentPane().getWidth();
        int height = getContentPane().getHeight();

        if (width <= 0 || height <= 0) {
                return;
        }

        double scaleX = width / 1920.0;
        double scaleY = height / 1080.0;
        double fontScale = Math.min(scaleX, scaleY);

        javax.swing.JButton[] buttons = {
                Dashboard,
                Patients,
                Doctors,
                Appointments,
                MedicalRecords,
                Services,
                Payments,
                Staff,
                UserAccounts,
                UserAccounts1,
                jButton1
        };

        // Positions taken from Dashboard.java
        int[] positionsY = {
                390, 430, 490, 550, 610,
                670, 746, 780, 830, 890, 990
        };

       int[] heights = {
        60, 100, 90, 90, 90,
        90, 52, 80, 80, 80, 60
};

        int fontSize = Math.max(
                18,
                (int) Math.round(24 * fontScale)
        );

        for (int i = 0; i < buttons.length; i++) {

                javax.swing.JButton button = buttons[i];

                int buttonWidth = (int) (260 * scaleX);

                button.setBounds(
                        (int) (60 * scaleX),
                        (int) (positionsY[i] * scaleY),
                        buttonWidth,
                        (int) (heights[i] * scaleY)
                );

                button.setFont(new java.awt.Font(
                        "Segoe UI",
                        java.awt.Font.BOLD,
                        fontSize
                ));

                button.setHorizontalAlignment(
                        javax.swing.SwingConstants.LEFT
                );

                button.setFocusPainted(false);
        }
}
private void scalePayments() {

    int width = getContentPane().getWidth();
    int height = getContentPane().getHeight();

    if (width <= 0 || height <= 0) {
        return;
    }

    // =====================================
    // 1. RESPONSIVE BACKGROUND
    // =====================================

    if (originalPaymentsBackground == null
            && jLabel1.getIcon() instanceof javax.swing.ImageIcon) {

        originalPaymentsBackground =
                ((javax.swing.ImageIcon) jLabel1.getIcon()).getImage();
    }

    if (originalPaymentsBackground != null) {

        java.awt.Image image =
                originalPaymentsBackground.getScaledInstance(
                        width,
                        height,
                        java.awt.Image.SCALE_SMOOTH
                );

        jLabel1.setIcon(new javax.swing.ImageIcon(image));
    }

    jLabel1.setBounds(0, 0, width, height);

    getContentPane().setComponentZOrder(
            jLabel1,
            getContentPane().getComponentCount() - 1
    );

 // =====================================
// 3. MAIN CONTENT
// =====================================

int sidebarWidth = (int) (width * 400.0 / 1920.0);

int contentX = sidebarWidth + 20;
int contentWidth = width - contentX - 18;

    if (contentWidth <= 0) {
        return;
    }

    jButton11.setBounds(
            contentX,
            40,
            Math.min(370, contentWidth),
            65
    );

    jButton11.setFont(new java.awt.Font(
            "Segoe UI",
            java.awt.Font.BOLD,
            width < 1400 ? 32 : 40
    ));

    // =====================================
    // 4. SEARCH BAR
    // =====================================

    int searchY = Math.max(
            120,
            (int) (height * 160.0 / 1080.0)
    );

  int searchHeight = 42;
int gap = 8;

int iconWidth = 42;
int filterWidth = 160;
int sortWidth = 175;
int orderWidth = 145;

// Reference search width: 720px at 1920 resolution
int searchWidth = (int) (720 * width / 1920.0);

// Total width required by the dropdowns and search icon
int controlsWidth = iconWidth + filterWidth
        + sortWidth + orderWidth + gap * 4;

// Keep all controls within the content area
searchWidth = Math.max(
        100,
        Math.min(searchWidth, contentWidth - controlsWidth)
);

// SEARCH FIELD
jTextField1.setBounds(
        contentX,
        searchY,
        searchWidth,
        searchHeight
);

int nextX = contentX + searchWidth + gap;

// SEARCH BUTTON
jButton3.setBounds(
        nextX,
        searchY,
        iconWidth,
        searchHeight
);

nextX += iconWidth + gap;

// FILTER
Filter.setBounds(
        nextX,
        searchY,
        filterWidth,
        searchHeight
);

nextX += filterWidth + gap;

// SORT
Sort.setBounds(
        nextX,
        searchY,
        sortWidth,
        searchHeight
);

nextX += sortWidth + gap;

// ORDER
Order.setBounds(
        nextX,
        searchY,
        orderWidth,
        searchHeight
);
    // Scale search icon
    java.net.URL iconURL =
            getClass().getResource(
                    "/images/icons8-search-47.png"
            );

    if (iconURL != null) {

        java.awt.Image searchIcon =
                new javax.swing.ImageIcon(iconURL)
                        .getImage()
                        .getScaledInstance(
                                28,
                                28,
                                java.awt.Image.SCALE_SMOOTH
                        );

        jButton3.setIcon(
                new javax.swing.ImageIcon(searchIcon)
        );
    }

    // =====================================
    // 5. TABLE AND DETAILS PANEL
    // =====================================

    int tableY = searchY + searchHeight + 16;

    int detailsHeight = Math.min(
            300,
            Math.max(260, height / 3)
    );

    int detailsY = height - detailsHeight - 12;

    int tableHeight = Math.max(
            140,
            detailsY - tableY - 12
    );

    jPanel2.setBounds(
            contentX,
            tableY,
            contentWidth,
            tableHeight
    );

    jPanel2.setLayout(null);

    jScrollPane1.setBounds(
            0,
            0,
            contentWidth,
            tableHeight
    );

    jPanel1.setBounds(
            contentX,
            detailsY,
            contentWidth,
            detailsHeight
    );

    // =====================================
    // 6. APPLY PANEL LAYOUTS
    // =====================================

    fixPaymentsTable();
    fixPaymentDetailsPanel();
    
    
// Match the Dashboard sidebar
fixPaymentsSidebar();

    jPanel2.revalidate();
    jPanel2.repaint();

    jPanel1.revalidate();
    jPanel1.repaint();

    getContentPane().revalidate();
    getContentPane().repaint();
}
private void fixPaymentsTable() {

    PaymentsTable.setAutoResizeMode(
            javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS
    );

    int[] columnWidths = {
        85,   // Payment ID
        115,  // Appointment ID
        100,  // Amount
        180,  // Payment Date
        150,  // Payment Method
        155,  // Reference No.
        105,  // Status
        180   // Action
    };

    javax.swing.table.TableColumnModel columns =
            PaymentsTable.getColumnModel();

    for (int i = 0;
            i < columns.getColumnCount()
            && i < columnWidths.length;
            i++) {

        columns.getColumn(i).setPreferredWidth(
                columnWidths[i]
        );
    }

    int actionIndex = PaymentsTable.getColumnCount() - 1;

    columns.getColumn(actionIndex).setMinWidth(170);
    columns.getColumn(actionIndex).setPreferredWidth(180);

    jScrollPane1.setHorizontalScrollBarPolicy(
            javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED
    );

    jScrollPane1.setVerticalScrollBarPolicy(
            javax.swing.JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED
    );
}
private void fixPaymentDetailsPanel() {

    int panelWidth = jPanel1.getWidth();
    int panelHeight = jPanel1.getHeight();

    jPanel1.setLayout(null);

    jPanel1.setBackground(
            new java.awt.Color(222, 246, 236)
    );

    jPanel1.setBorder(
            javax.swing.BorderFactory.createLineBorder(
                    new java.awt.Color(0, 102, 51),
                    2
            )
    );

    // =====================================
    // PANEL TITLE
    // =====================================

    jLabel2.setBounds(25, 10, 260, 35);

    jLabel2.setFont(new java.awt.Font(
            "Segoe UI",
            java.awt.Font.BOLD,
            18
    ));

    // =====================================
    // THREE-COLUMN LAYOUT
    // =====================================

    int padding = 25;
    int columnGap = 18;

    int columnWidth =
            (panelWidth - padding * 2 - columnGap * 2) / 3;

    int x1 = padding;
    int x2 = x1 + columnWidth + columnGap;
    int x3 = x2 + columnWidth + columnGap;

    int row1 = 65;
    int row2 = 112;
    int row3 = 159;

    int fieldHeight = 35;

    int labelWidth = 125;

    // =====================================
    // COLUMN 1
    // =====================================

    // Patient ID
    jLabel3.setBounds(
            x1, row1, labelWidth, fieldHeight
    );

    jTextField8.setBounds(
            x1 + labelWidth,
            row1,
            columnWidth - labelWidth,
            fieldHeight
    );

    // Appointment ID
    jLabel4.setBounds(
            x1, row2, labelWidth, fieldHeight
    );

    jTextField7.setBounds(
            x1 + labelWidth,
            row2,
            columnWidth - labelWidth,
            fieldHeight
    );

    // =====================================
    // COLUMN 2
    // =====================================

    // Amount
    jLabel5.setBounds(
            x2, row1, labelWidth, fieldHeight
    );

    jTextField9.setBounds(
            x2 + labelWidth,
            row1,
            columnWidth - labelWidth,
            fieldHeight
    );

    // Payment Date
    jLabel6.setBounds(
            x2, row2, labelWidth, fieldHeight
    );

    jTextField10.setBounds(
            x2 + labelWidth,
            row2,
            columnWidth - labelWidth,
            fieldHeight
    );

    // =====================================
    // COLUMN 3
    // =====================================

    // Payment Method
    jLabel10.setBounds(
            x3, row1, labelWidth, fieldHeight
    );

    jTextField2.setBounds(
            x3 + labelWidth,
            row1,
            columnWidth - labelWidth,
            fieldHeight
    );

    // Reference No.
    jLabel11.setBounds(
            x3, row2, labelWidth, fieldHeight
    );

    jTextField3.setBounds(
            x3 + labelWidth,
            row2,
            columnWidth - labelWidth,
            fieldHeight
    );

// Status
jLabel12.setBounds(
        x3, row3, labelWidth, fieldHeight
);

jComboBox1.setBounds(
        x3 + labelWidth,
        row3,
        columnWidth - labelWidth,
        fieldHeight
);

    // =====================================
    // CLEAR AND SAVE BUTTONS
    // =====================================

    int buttonWidth = 110;
    int buttonHeight = 36;
    int buttonGap = 15;

    int buttonY = panelHeight - 48;

    int saveX = panelWidth - buttonWidth - 25;
    int clearX = saveX - buttonWidth - buttonGap;

    jButton5.setBounds(
            clearX,
            buttonY,
            buttonWidth,
            buttonHeight
    );

    jButton6.setBounds(
            saveX,
            buttonY,
            buttonWidth,
            buttonHeight
    );

    jPanel1.revalidate();
    jPanel1.repaint();
}
private void setupPaymentActions() {

        DefaultTableModel model = new DefaultTableModel(
                new Object[][]{},
                new String[]{
                        "Payment ID", "Appointment ID",
                        "Amount", "Payment Date",
                        "Payment Method", "Reference No.",
                        "Status", "Action"
                }
        ) {
                @Override
                public boolean isCellEditable(int row, int column) {
                        return column == 7;
                }
        };

        PaymentsTable.setModel(model);

        javax.swing.table.TableColumn action =
                PaymentsTable.getColumnModel().getColumn(7);

        action.setCellRenderer(new PaymentActionRenderer());
        action.setCellEditor(new PaymentActionEditor());
        action.setPreferredWidth(170);
        action.setMinWidth(150);
}


private void stylePaymentButton(
        javax.swing.JButton button, java.awt.Color color) {

        button.setBackground(color);
        button.setForeground(java.awt.Color.WHITE);

        button.setFont(new java.awt.Font(
                "Segoe UI", java.awt.Font.BOLD, 11));

        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setContentAreaFilled(false);
        button.setOpaque(false);

        button.setMargin(new java.awt.Insets(0, 0, 0, 0));

        button.setPreferredSize(new java.awt.Dimension(
                button.getText().equals("Edit") ? 58 : 78, 26));

        button.setUI(new javax.swing.plaf.basic.BasicButtonUI() {

                @Override
                public void paint(
                        java.awt.Graphics g,
                        javax.swing.JComponent c) {

                        java.awt.Graphics2D g2 =
                                (java.awt.Graphics2D) g.create();

                        g2.setRenderingHint(
                                java.awt.RenderingHints.KEY_ANTIALIASING,
                                java.awt.RenderingHints.VALUE_ANTIALIAS_ON);

                        g2.setColor(color);

                        g2.fillRoundRect(
                                0, 0,
                                c.getWidth() - 1,
                                c.getHeight() - 1,
                                12, 12);

                        g2.dispose();

                        super.paint(g, c);
                }
        });
}


private class PaymentActionRenderer extends javax.swing.JPanel
        implements javax.swing.table.TableCellRenderer {

        private final javax.swing.JButton edit =
                new javax.swing.JButton("Edit");
        private final javax.swing.JButton remove =
                new javax.swing.JButton("Remove");

 PaymentActionRenderer() {

        setLayout(new java.awt.FlowLayout(
                java.awt.FlowLayout.CENTER, 8, 5));

        setOpaque(false); // ADD HERE

        stylePaymentButton(edit,
                new java.awt.Color(0, 102, 51));

        stylePaymentButton(remove,
                new java.awt.Color(190, 40, 40));

        add(edit);
        add(remove);
}
        @Override
        public java.awt.Component getTableCellRendererComponent(
                javax.swing.JTable table, Object value,
                boolean selected, boolean focus,
                int row, int column) {
setBackground(java.awt.Color.WHITE);

                return this;
        }
}

private class PaymentActionEditor
        extends javax.swing.AbstractCellEditor
        implements javax.swing.table.TableCellEditor {

        private final javax.swing.JPanel panel =
                new javax.swing.JPanel(new java.awt.FlowLayout(
                        java.awt.FlowLayout.CENTER, 8, 5));

        private final javax.swing.JButton edit =
                new javax.swing.JButton("Edit");
        private final javax.swing.JButton remove =
                new javax.swing.JButton("Remove");

        private int selectedRow;

      
PaymentActionEditor() {

        panel.setOpaque(false);

        // GREEN EDIT BUTTON
        stylePaymentButton(edit,
                new java.awt.Color(0, 102, 51));

        // RED REMOVE BUTTON
        stylePaymentButton(remove,
                new java.awt.Color(190, 40, 40));

        panel.add(edit);
        panel.add(remove);

        // EDIT FUNCTION
        edit.addActionListener(e -> {

                int row = selectedRow;

                fireEditingStopped();

                editPayment(row);
        });

        // REMOVE FUNCTION
        remove.addActionListener(e -> {

                int row = selectedRow;

                fireEditingStopped();

                removePayment(row);
        });
}

        @Override
        public java.awt.Component getTableCellEditorComponent(
                javax.swing.JTable table, Object value,
                boolean selected, int row, int column) {

                selectedRow = row;
panel.setBackground(java.awt.Color.WHITE);
return panel;
        }

        @Override
        public Object getCellEditorValue() {
                return "";
        }
}

private void editPayment(int row) {

        int modelRow = PaymentsTable.convertRowIndexToModel(row);
        javax.swing.table.TableModel model = PaymentsTable.getModel();

        editingPaymentId = Integer.parseInt(
                model.getValueAt(modelRow, 0).toString());

        jTextField7.setText(
                model.getValueAt(modelRow, 1).toString());

        jTextField9.setText(
                model.getValueAt(modelRow, 2).toString());

        Object date = model.getValueAt(modelRow, 3);
        jTextField10.setText(date == null ? ""
                : date.toString().substring(0, 10));

        jTextField2.setText(
                String.valueOf(model.getValueAt(modelRow, 4)));

        Object reference = model.getValueAt(modelRow, 5);
        jTextField3.setText(reference == null
                ? "" : reference.toString());

        Object statusValue = model.getValueAt(modelRow, 6);

jComboBox1.setSelectedItem(
        statusValue == null
                ? "Pending"
                : statusValue.toString()
);

        // Retrieve Patient ID through the appointment
        String sql = "SELECT patient_id FROM Appointments "
                + "WHERE appointment_id = ?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setInt(1, Integer.parseInt(
                        jTextField7.getText()));

                try (ResultSet result = ps.executeQuery()) {
                        if (result.next()) {
                                jTextField8.setText(
                                        result.getString("patient_id"));
                        } else {
                                JOptionPane.showMessageDialog(this,
                                        "Appointment not found.");
                                clearPaymentForm();
                                return;
                        }
                }

        } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this,
                        "Unable to load patient ID:\n"
                        + ex.getMessage());
                clearPaymentForm();
                return;
        }

        jButton6.setText("Update");
}

private void removePayment(int row) {

        int modelRow = PaymentsTable.convertRowIndexToModel(row);

        int paymentId = Integer.parseInt(
                PaymentsTable.getModel()
                        .getValueAt(modelRow, 0).toString());

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Move this payment to Archive?",
                "Confirm Remove",
                JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION) {
                return;
        }

       String sql = "UPDATE Payments "
        + "SET is_archived = 1, status = 'Archived' "
        + "WHERE payment_id = ? AND is_archived = 0";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setInt(1, paymentId);

                if (ps.executeUpdate() > 0) {
                        JOptionPane.showMessageDialog(
                                this, "Payment archived successfully!");
                        clearPaymentForm();
                        loadPayments();
                }

        } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this,
                        "Unable to archive payment:\n"
                        + ex.getMessage());
        }
}


private void searchPayments() {

        if (sorter == null) {
                return;
        }

        String searchText = jTextField1.getText().trim();

        if (searchText.equalsIgnoreCase(
                "Search payments...")) {
                searchText = "";
        }

        String selectedFilter =
                Filter.getSelectedItem() == null
                ? "FILTER BY: ALL"
                : Filter.getSelectedItem().toString().trim();

        java.util.List<
                javax.swing.RowFilter<DefaultTableModel, Integer>>
                filters = new java.util.ArrayList<>();

        // FILTER BY PAYMENT STATUS
        if (selectedFilter.equalsIgnoreCase("Paid")
                || selectedFilter.equalsIgnoreCase("Pending")
                || selectedFilter.equalsIgnoreCase("Partial")) {

                filters.add(
                        javax.swing.RowFilter.regexFilter(
                                "(?i)^"
                                + java.util.regex.Pattern.quote(selectedFilter)
                                + "$",
                                6
                        )
                );
        }

        // SEARCH PAYMENT INFORMATION
        if (!searchText.isEmpty()) {

                String pattern = "(?i)"
                        + java.util.regex.Pattern.quote(searchText);

                filters.add(
                        javax.swing.RowFilter.regexFilter(
                                pattern,
                                0, 1, 2, 3, 4, 5
                        )
                );
        }

        // APPLY SEARCH AND FILTER
        if (filters.isEmpty()) {

                sorter.setRowFilter(null);

        } else {

                sorter.setRowFilter(
                        javax.swing.RowFilter.andFilter(filters)
                );
        }
}
    private void sortPayments() {

    if (sorter == null) {
        return;
    }

    String selectedSort =
            Sort.getSelectedItem().toString();

    String selectedOrder =
            Order.getSelectedItem().toString();

    int column;

    switch (selectedSort) {

        case "Payment ID":
            column = 0;
            break;

        case "Amount":
            column = 2;
            break;

        case "Payment Date":
            column = 3;
            break;

        default:
            sorter.setSortKeys(null);
            return;
    }

    javax.swing.SortOrder direction =
            javax.swing.SortOrder.ASCENDING;

    if ("DESCENDING".equals(selectedOrder)) {
        direction =
                javax.swing.SortOrder.DESCENDING;
    }

    java.util.List<
            javax.swing.RowSorter.SortKey> sortKeys =
            new java.util.ArrayList<>();

    sortKeys.add(
            new javax.swing.RowSorter.SortKey(
                    column,
                    direction
            )
    );

    sorter.setSortKeys(sortKeys);
}
        private void connectDatabase() {

        try {

            Class.forName(
                    "com.mysql.cj.jdbc.Driver"
            );

            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/ClinicManagementSystem",
                    "root",
                    ""
            );

            System.out.println(
                    "Payments Database Connected!"
            );

        } catch (ClassNotFoundException | SQLException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Database Connection Failed!\n"
                    + e.getMessage()
            );
        }
    }
            private void loadPayments() {

        if (conn == null) {
            return;
        }

        DefaultTableModel model =
                (DefaultTableModel)
                PaymentsTable.getModel();

        model.setRowCount(0);

  String sql =
        "SELECT payment_id, appointment_id, amount, "
        + "payment_date, payment_method, "
        + "reference_no, status "
        + "FROM Payments "
        + "WHERE is_archived = 0 "
        + "ORDER BY payment_id ASC";

        try {

            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();

            while (rs.next()) {

                Object[] row = {
                    rs.getInt("payment_id"),
                    rs.getInt("appointment_id"),
                    rs.getBigDecimal("amount"),
                    rs.getTimestamp("payment_date"),
                    rs.getString("payment_method"),
                    rs.getString("reference_no"),
rs.getString("status"),
""                };

                model.addRow(row);
            }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Failed to load payments!\n"
                    + e.getMessage()
            );
        }
    }

private void savePayment() {

        String patientText = jTextField8.getText().trim();
        String appointmentText = jTextField7.getText().trim();
        String amountText = jTextField9.getText().trim();
        String dateText = jTextField10.getText().trim();
        String method = jTextField2.getText().trim();
        String reference = jTextField3.getText().trim();
String status = jComboBox1.getSelectedItem().toString();
        if (patientText.isEmpty() || appointmentText.isEmpty()
                || amountText.isEmpty() || method.isEmpty()
                || status.isEmpty()) {

                JOptionPane.showMessageDialog(this,
                        "Please complete all required fields.");
                return;
        }

        try {

                int patientId = Integer.parseInt(patientText);
                int appointmentId = Integer.parseInt(appointmentText);
                double amount = Double.parseDouble(amountText);

                if (!Double.isFinite(amount) || amount < 0) {
                        JOptionPane.showMessageDialog(this,
                                "Enter a valid non-negative amount.");
                        return;
                }

                String check = "SELECT appointment_id FROM Appointments "
                        + "WHERE appointment_id = ? AND patient_id = ?";

                try (PreparedStatement ps = conn.prepareStatement(check)) {
                        ps.setInt(1, appointmentId);
                        ps.setInt(2, patientId);

                        try (ResultSet result = ps.executeQuery()) {
                                if (!result.next()) {
                                        JOptionPane.showMessageDialog(this,
                                                "Appointment does not belong "
                                                + "to this patient.");
                                        return;
                                }
                        }
                }

                java.sql.Timestamp paymentDate = null;

                if (!dateText.isEmpty()) {
                        paymentDate = java.sql.Timestamp.valueOf(
                                java.time.LocalDate.parse(dateText)
                                        .atStartOfDay());
                }

                boolean editing = editingPaymentId != -1;

                String sql;

                if (editing) {
                        sql = "UPDATE Payments SET appointment_id = ?, "
                                + "amount = ?, payment_date = ?, "
                                + "payment_method = ?, reference_no = ?, "
                                + "status = ? "
                                + "WHERE payment_id = ? AND is_archived = 0";
                } else if (paymentDate == null) {
                        sql = "INSERT INTO Payments "
                                + "(appointment_id, amount, payment_method, "
                                + "reference_no, status) "
                                + "VALUES (?, ?, ?, ?, ?)";
                } else {
                        sql = "INSERT INTO Payments "
                                + "(appointment_id, amount, payment_date, "
                                + "payment_method, reference_no, status) "
                                + "VALUES (?, ?, ?, ?, ?, ?)";
                }

                try (PreparedStatement ps = conn.prepareStatement(sql)) {

                        ps.setInt(1, appointmentId);
                        ps.setDouble(2, amount);

                        if (editing) {
                                ps.setTimestamp(3, paymentDate);
                                ps.setString(4, method);
                                ps.setString(5, reference);
                                ps.setString(6, status);
                                ps.setInt(7, editingPaymentId);

                        } else if (paymentDate == null) {
                                ps.setString(3, method);
                                ps.setString(4, reference);
                                ps.setString(5, status);

                        } else {
                                ps.setTimestamp(3, paymentDate);
                                ps.setString(4, method);
                                ps.setString(5, reference);
                                ps.setString(6, status);
                        }

                        int affected = ps.executeUpdate();

                        if (affected == 0) {
                                JOptionPane.showMessageDialog(this,
                                        "Payment was not found or is archived.");
                                return;
                        }
                }

                JOptionPane.showMessageDialog(this,
                        editing ? "Payment updated successfully!"
                                : "Payment saved successfully!");

                clearPaymentForm();
                loadPayments();

        } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this,
                        "Enter valid numeric IDs and amount.");

        } catch (java.time.format.DateTimeParseException ex) {
                JOptionPane.showMessageDialog(this,
                        "Use YYYY-MM-DD for Payment Date.");

        } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this,
                        "Unable to save payment:\n" + ex.getMessage());
        }
}

                    private void clearPaymentForm() {

        jTextField8.setText("");
        jTextField7.setText("");
        jTextField9.setText("");
        jTextField10.setText("");

        jTextField2.setText("");
        jTextField3.setText("");
jComboBox1.setSelectedItem("Pending");

        jTextField8.requestFocus();
        editingPaymentId = -1;
jButton6.setText("Save");
    }
                    
private void designSearchBar() {

    String placeholder = "Search payments...";

    jTextField1.setFont(
            new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 16)
    );

    jTextField1.setForeground(
            new java.awt.Color(130, 130, 130)
    );

    jTextField1.setText(placeholder);

    jTextField1.addFocusListener(
            new java.awt.event.FocusAdapter() {

                @Override
                public void focusGained(
                        java.awt.event.FocusEvent evt) {

                    if (jTextField1.getText().equals(placeholder)) {
                        jTextField1.setText("");
                        jTextField1.setForeground(
                                new java.awt.Color(40, 40, 40)
                        );
                    }
                }

                @Override
                public void focusLost(
                        java.awt.event.FocusEvent evt) {

                    if (jTextField1.getText().trim().isEmpty()) {
                        jTextField1.setText(placeholder);
                        jTextField1.setForeground(
                                new java.awt.Color(130, 130, 130)
                        );
                    }
                }
            }
    );
}

private void designPaymentDetailsPanel() {

    jPanel1.setBackground(
            new java.awt.Color(222, 246, 236)
    );

    jPanel1.setBorder(
            javax.swing.BorderFactory.createLineBorder(
                    new java.awt.Color(0, 102, 51),
                    2
            )
    );

    jPanel1.revalidate();
    jPanel1.repaint();
}

  
private void designPaymentsTable() {

        // TABLE APPEARANCE
        PaymentsTable.setFont(
                new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 14)
        );

        PaymentsTable.setRowHeight(38);
        PaymentsTable.setBackground(java.awt.Color.WHITE);
        PaymentsTable.setForeground(new java.awt.Color(40, 40, 40));

        PaymentsTable.setSelectionBackground(
                new java.awt.Color(222, 246, 236)
        );

        PaymentsTable.setSelectionForeground(
                new java.awt.Color(0, 102, 51)
        );

        PaymentsTable.setGridColor(
                new java.awt.Color(220, 235, 228)
        );

        PaymentsTable.setShowHorizontalLines(true);
        PaymentsTable.setShowVerticalLines(false);

        PaymentsTable.setIntercellSpacing(
                new java.awt.Dimension(0, 1)
        );

        // GREEN TABLE HEADER
        javax.swing.table.JTableHeader header =
                PaymentsTable.getTableHeader();

        header.setPreferredSize(
                new java.awt.Dimension(
                        header.getPreferredSize().width, 38
                )
        );

        header.setReorderingAllowed(false);

        javax.swing.table.DefaultTableCellRenderer headerRenderer =
                new javax.swing.table.DefaultTableCellRenderer();

        headerRenderer.setBackground(
                new java.awt.Color(0, 102, 51)
        );

        headerRenderer.setForeground(java.awt.Color.WHITE);

        headerRenderer.setFont(
                new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 14)
        );

        headerRenderer.setHorizontalAlignment(
                javax.swing.SwingConstants.CENTER
        );

        headerRenderer.setOpaque(true);

        // APPLY GREEN HEADER TO ALL COLUMNS
        for (int i = 0;
                i < PaymentsTable.getColumnCount();
                i++) {

                PaymentsTable.getColumnModel()
                        .getColumn(i)
                        .setHeaderRenderer(headerRenderer);
        }

        // CENTER TABLE CONTENT
        javax.swing.table.DefaultTableCellRenderer center =
                new javax.swing.table.DefaultTableCellRenderer();

        center.setHorizontalAlignment(
                javax.swing.SwingConstants.CENTER
        );

        // EXCLUDE ACTION COLUMN
        for (int i = 0;
                i < PaymentsTable.getColumnCount() - 1;
                i++) {

                PaymentsTable.getColumnModel()
                        .getColumn(i)
                        .setCellRenderer(center);
        }

        // EDIT AND REMOVE BUTTONS
        javax.swing.table.TableColumn action =
                PaymentsTable.getColumnModel().getColumn(7);

        action.setCellRenderer(new PaymentActionRenderer());
        action.setCellEditor(new PaymentActionEditor());

        action.setPreferredWidth(170);
        action.setMinWidth(150);

        PaymentsTable.setAutoResizeMode(
                javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS
        );

        jScrollPane1.getViewport().setBackground(
                java.awt.Color.WHITE
        );

        header.repaint();
        PaymentsTable.repaint();
}


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        Patients = new javax.swing.JButton();
        Appointments = new javax.swing.JButton();
        MedicalRecords = new javax.swing.JButton();
        Services = new javax.swing.JButton();
        Staff = new javax.swing.JButton();
        Dashboard = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        UserAccounts = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        PaymentsTable = new javax.swing.JTable();
        Doctors = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        Payments = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jTextField9 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jTextField10 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        Filter = new javax.swing.JComboBox<>();
        Sort = new javax.swing.JComboBox<>();
        Order = new javax.swing.JComboBox<>();
        UserAccounts1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton1.setForeground(new java.awt.Color(204, 0, 0));
        jButton1.setText("Log Out");
        jButton1.setBorderPainted(false);
        jButton1.setContentAreaFilled(false);
        jButton1.setDefaultCapable(false);
        jButton1.setFocusPainted(false);
        jButton1.setFocusable(false);
        jButton1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton1.addActionListener(this::jButton1ActionPerformed);
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 990, 260, 60));

        Patients.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Patients.setForeground(new java.awt.Color(255, 255, 255));
        Patients.setText("Patients");
        Patients.setBorderPainted(false);
        Patients.setContentAreaFilled(false);
        Patients.setDefaultCapable(false);
        Patients.setFocusPainted(false);
        Patients.setFocusable(false);
        Patients.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Patients.addActionListener(this::PatientsActionPerformed);
        getContentPane().add(Patients, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 450, 260, 60));

        Appointments.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Appointments.setForeground(new java.awt.Color(255, 255, 255));
        Appointments.setText("Appointments");
        Appointments.setBorderPainted(false);
        Appointments.setContentAreaFilled(false);
        Appointments.setDefaultCapable(false);
        Appointments.setFocusPainted(false);
        Appointments.setFocusable(false);
        Appointments.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Appointments.addActionListener(this::AppointmentsActionPerformed);
        getContentPane().add(Appointments, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 560, 260, 70));

        MedicalRecords.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        MedicalRecords.setForeground(new java.awt.Color(255, 255, 255));
        MedicalRecords.setText("Medical Records");
        MedicalRecords.setBorderPainted(false);
        MedicalRecords.setContentAreaFilled(false);
        MedicalRecords.setDefaultCapable(false);
        MedicalRecords.setFocusPainted(false);
        MedicalRecords.setFocusable(false);
        MedicalRecords.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        MedicalRecords.addActionListener(this::MedicalRecordsActionPerformed);
        getContentPane().add(MedicalRecords, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 620, 260, 70));

        Services.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Services.setForeground(new java.awt.Color(255, 255, 255));
        Services.setText("Services");
        Services.setBorderPainted(false);
        Services.setContentAreaFilled(false);
        Services.setDefaultCapable(false);
        Services.setFocusPainted(false);
        Services.setFocusable(false);
        Services.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Services.addActionListener(this::ServicesActionPerformed);
        getContentPane().add(Services, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 690, 260, 50));

        Staff.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Staff.setForeground(new java.awt.Color(255, 255, 255));
        Staff.setText("Staff");
        Staff.setBorderPainted(false);
        Staff.setContentAreaFilled(false);
        Staff.setDefaultCapable(false);
        Staff.setFocusPainted(false);
        Staff.setFocusable(false);
        Staff.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Staff.addActionListener(this::StaffActionPerformed);
        getContentPane().add(Staff, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 780, 260, 80));

        Dashboard.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Dashboard.setForeground(new java.awt.Color(255, 255, 255));
        Dashboard.setText("Dashboard");
        Dashboard.setBorderPainted(false);
        Dashboard.setContentAreaFilled(false);
        Dashboard.setDefaultCapable(false);
        Dashboard.setFocusPainted(false);
        Dashboard.setFocusable(false);
        Dashboard.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Dashboard.addActionListener(this::DashboardActionPerformed);
        getContentPane().add(Dashboard, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 380, 260, 80));

        jButton11.setFont(new java.awt.Font("Segoe UI", 1, 40)); // NOI18N
        jButton11.setText("Payments");
        jButton11.setBorderPainted(false);
        jButton11.setContentAreaFilled(false);
        jButton11.setDefaultCapable(false);
        jButton11.setFocusPainted(false);
        jButton11.setFocusable(false);
        jButton11.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton11.addActionListener(this::jButton11ActionPerformed);
        getContentPane().add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 40, 360, -1));

        UserAccounts.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        UserAccounts.setForeground(new java.awt.Color(255, 255, 255));
        UserAccounts.setText("User Accounts");
        UserAccounts.setBorderPainted(false);
        UserAccounts.setContentAreaFilled(false);
        UserAccounts.setDefaultCapable(false);
        UserAccounts.setFocusPainted(false);
        UserAccounts.setFocusable(false);
        UserAccounts.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        UserAccounts.addActionListener(this::UserAccountsActionPerformed);
        getContentPane().add(UserAccounts, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 830, 260, 80));

        jPanel2.setBackground(new java.awt.Color(222, 246, 236));

        PaymentsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Payment ID", "Appointment ID", "Amount", "Payment Date", "Payment Method", "Reference No.", "Status"
            }
        ));
        PaymentsTable.setFocusCycleRoot(true);
        PaymentsTable.setGridColor(new java.awt.Color(231, 250, 250));
        PaymentsTable.setShowGrid(true);
        PaymentsTable.setSurrendersFocusOnKeystroke(true);
        jScrollPane1.setViewportView(PaymentsTable);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1474, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 484, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 230, 1480, 490));

        Doctors.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Doctors.setForeground(new java.awt.Color(255, 255, 255));
        Doctors.setText("Doctors");
        Doctors.setBorderPainted(false);
        Doctors.setContentAreaFilled(false);
        Doctors.setDefaultCapable(false);
        Doctors.setFocusPainted(false);
        Doctors.setFocusable(false);
        Doctors.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Doctors.addActionListener(this::DoctorsActionPerformed);
        getContentPane().add(Doctors, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 500, 260, 70));

        jTextField1.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        jTextField1.setForeground(new java.awt.Color(102, 102, 102));
        jTextField1.setText("Search by patient name..");
        jTextField1.addActionListener(this::jTextField1ActionPerformed);
        getContentPane().add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 160, 720, 50));

        Payments.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Payments.setForeground(new java.awt.Color(0, 102, 51));
        Payments.setText("Payments");
        Payments.setDefaultCapable(false);
        Payments.setFocusPainted(false);
        Payments.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Payments.addActionListener(this::PaymentsActionPerformed);
        getContentPane().add(Payments, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 751, 260, -1));

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-search-47.png"))); // NOI18N
        jButton3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 51)));
        jButton3.setBorderPainted(false);
        jButton3.addActionListener(this::jButton3ActionPerformed);
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 160, -1, -1));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 102, 51));
        jLabel2.setText("Payment Details");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Patient ID");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Appointment ID");

        jButton5.setBackground(new java.awt.Color(240, 250, 244));
        jButton5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton5.setForeground(new java.awt.Color(0, 102, 51));
        jButton5.setText("Clear");

        jButton6.setBackground(new java.awt.Color(0, 102, 51));
        jButton6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.setText("Save");

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel10.setText("Payment Method");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setText("Amount");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel6.setText("Payment Date");

        jLabel11.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel11.setText("Reference No.");

        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel12.setText("Status");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pending", "Partial", "Paid" }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(58, 58, 58)
                        .addComponent(jTextField9))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(21, 21, 21)
                        .addComponent(jTextField10))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(108, 108, 108)
                        .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(50, 50, 50)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addGap(18, 18, 18)
                        .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jButton5)
                                .addGap(18, 18, 18)
                                .addComponent(jButton6))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel12)
                                    .addComponent(jLabel11))
                                .addGap(41, 41, 41)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextField3)
                                    .addComponent(jComboBox1, 0, 250, Short.MAX_VALUE))))
                        .addContainerGap(659, Short.MAX_VALUE))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jLabel2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4))))
                .addContainerGap(1327, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(146, 146, 146)
                    .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(1084, Short.MAX_VALUE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10)
                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel6)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel11))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel12)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel4)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel5)))
                .addContainerGap(16, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(66, 66, 66)
                    .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(142, Short.MAX_VALUE)))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 750, 1480, 240));

        Filter.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Filter.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "FILTER BY: ALL", "Paid", "Pending", "Partial" }));
        Filter.addActionListener(this::FilterActionPerformed);
        getContentPane().add(Filter, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 160, 120, 50));

        Sort.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Sort.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SORT BY: DEFAULT", "Payment ID", "Amount", "Payment Date" }));
        Sort.addActionListener(this::SortActionPerformed);
        getContentPane().add(Sort, new org.netbeans.lib.awtextra.AbsoluteConstraints(1310, 160, 100, 50));

        Order.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Order.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ORDER", "ASCENDING", "DESCENDING" }));
        Order.addActionListener(this::OrderActionPerformed);
        getContentPane().add(Order, new org.netbeans.lib.awtextra.AbsoluteConstraints(1420, 160, 100, 50));

        UserAccounts1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        UserAccounts1.setForeground(new java.awt.Color(255, 255, 255));
        UserAccounts1.setText("Archive");
        UserAccounts1.setBorderPainted(false);
        UserAccounts1.setContentAreaFilled(false);
        UserAccounts1.setDefaultCapable(false);
        UserAccounts1.setFocusPainted(false);
        UserAccounts1.setFocusable(false);
        UserAccounts1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        UserAccounts1.addActionListener(this::UserAccounts1ActionPerformed);
        getContentPane().add(UserAccounts1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 890, 260, 80));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Dashgh.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 1930, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void PatientsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PatientsActionPerformed
    Patients patients = new Patients();
    patients.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_PatientsActionPerformed

    private void AppointmentsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AppointmentsActionPerformed
    Appointments appointments = new Appointments();
    appointments.setVisible(true);
    this.dispose();          // TODO add your handling code here:
    }//GEN-LAST:event_AppointmentsActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton11ActionPerformed

    private void DoctorsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DoctorsActionPerformed
    Doctors doctors = new Doctors();
    doctors.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_DoctorsActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
            searchPayments();
// TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
            searchPayments();
// TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void DashboardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DashboardActionPerformed
    Dashboard dashboard = new Dashboard();
    dashboard.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_DashboardActionPerformed

    private void MedicalRecordsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MedicalRecordsActionPerformed
    MedicalRecords records = new MedicalRecords();
    records.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_MedicalRecordsActionPerformed

    private void ServicesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ServicesActionPerformed
    Services services = new Services();
    services.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_ServicesActionPerformed

    private void PaymentsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PaymentsActionPerformed
    Payments payments = new Payments();
    payments.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_PaymentsActionPerformed

    private void StaffActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StaffActionPerformed
    Staff staff = new Staff();
    staff.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_StaffActionPerformed

    private void UserAccountsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UserAccountsActionPerformed
    UserAccounts accounts = new UserAccounts();
    accounts.setVisible(true);
    this.dispose();
        // TODO add your handling code here:
    }//GEN-LAST:event_UserAccountsActionPerformed

    private void FilterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FilterActionPerformed
            searchPayments();
        // TODO add your handling code here:
    }//GEN-LAST:event_FilterActionPerformed

    private void SortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SortActionPerformed
        sortPayments();

        // TODO add your handling code here:
    }//GEN-LAST:event_SortActionPerformed

    private void OrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OrderActionPerformed
        sortPayments();
        // TODO add your handling code here:
    }//GEN-LAST:event_OrderActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    UserSession.logout();
    SignIn logout = new SignIn();
    logout.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void UserAccounts1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UserAccounts1ActionPerformed
         Archive archive = new Archive();
        archive.setVisible(true);
        this.dispose();         // TODO add your handling code here:
    }//GEN-LAST:event_UserAccounts1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Payments().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Appointments;
    private javax.swing.JButton Dashboard;
    private javax.swing.JButton Doctors;
    private javax.swing.JComboBox<String> Filter;
    private javax.swing.JButton MedicalRecords;
    private javax.swing.JComboBox<String> Order;
    private javax.swing.JButton Patients;
    private javax.swing.JButton Payments;
    private javax.swing.JTable PaymentsTable;
    private javax.swing.JButton Services;
    private javax.swing.JComboBox<String> Sort;
    private javax.swing.JButton Staff;
    private javax.swing.JButton UserAccounts;
    private javax.swing.JButton UserAccounts1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    // End of variables declaration//GEN-END:variables
}
