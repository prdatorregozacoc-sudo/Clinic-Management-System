import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Dashboard extends javax.swing.JFrame {
    private Connection conn;
    private PreparedStatement pst;
    private ResultSet rs;
    private javax.swing.JLabel dateLabel;
    private javax.swing.JLabel timeLabel;
    private javax.swing.Timer clockTimer;
    

// LOGGER
    private static final java.util.logging.Logger logger =
        java.util.logging.Logger.getLogger(Dashboard.class.getName());

    // =========================================================
    // DASHBOARD TABLE DESIGN
    // Styles Upcoming Appointments and Recent Patients tables
    // =========================================================

private void designDashboardTables() {

    styleTable(AppointmentsTable);
    styleTable(AppointmentsTable1);

    // Make entire table area white
    AppointmentsTable.setBackground(java.awt.Color.WHITE);
    AppointmentsTable1.setBackground(java.awt.Color.WHITE);

    AppointmentsTable.setFillsViewportHeight(true);
    AppointmentsTable1.setFillsViewportHeight(true);

    jScrollPane1.getViewport().setBackground(
            java.awt.Color.WHITE
    );

    jScrollPane2.getViewport().setBackground(
            java.awt.Color.WHITE
    );
        jScrollPane1.setBorder(
                javax.swing.BorderFactory.createLineBorder(
                        new java.awt.Color(0, 102, 51),
                        1
                )
        );

        jScrollPane2.setBorder(
                javax.swing.BorderFactory.createLineBorder(
                        new java.awt.Color(0, 102, 51),
                        1
                )
        );
    // Upcoming Appointments widths
    javax.swing.table.TableColumnModel appointmentColumns =
            AppointmentsTable.getColumnModel();

    appointmentColumns.getColumn(0).setPreferredWidth(90);
    appointmentColumns.getColumn(1).setPreferredWidth(200);
    appointmentColumns.getColumn(2).setPreferredWidth(170);
    appointmentColumns.getColumn(3).setPreferredWidth(170);
    appointmentColumns.getColumn(4).setPreferredWidth(110);

    // Recent Patients widths
    javax.swing.table.TableColumnModel patientColumns =
            AppointmentsTable1.getColumnModel();

    patientColumns.getColumn(0).setPreferredWidth(250);
    patientColumns.getColumn(1).setPreferredWidth(150);
    patientColumns.getColumn(2).setPreferredWidth(120);
}
        // =========================================================
    // GENERAL TABLE DESIGN
    // Used by Upcoming Appointments and Recent Patients
    // =========================================================

        private void styleTable(javax.swing.JTable table) {

                // =====================================================
                // TABLE BODY
                // =====================================================

                table.setFont(
                        new java.awt.Font(
                                "Segoe UI",
                                java.awt.Font.PLAIN,
                                15
                        )
                );

                table.setRowHeight(38);

                table.setBackground(
                        java.awt.Color.WHITE
                );

                table.setForeground(
                        new java.awt.Color(25, 25, 25)
                );

                // Stronger horizontal lines
                table.setGridColor(
                        new java.awt.Color(190, 215, 200)
                );

                table.setShowHorizontalLines(true);
                table.setShowVerticalLines(false);

                table.setIntercellSpacing(
                        new java.awt.Dimension(0, 1)
                );

                // Selection
                table.setSelectionBackground(
                        new java.awt.Color(205, 238, 220)
                );

                table.setSelectionForeground(
                        new java.awt.Color(0, 80, 40)
                );


                // =====================================================
                // HEADER
                // =====================================================

                javax.swing.table.JTableHeader header =
                        table.getTableHeader();

                header.setFont(
                        new java.awt.Font(
                                "Segoe UI",
                                java.awt.Font.BOLD,
                                15
                        )
                );

                header.setBackground(
                        new java.awt.Color(0, 102, 51)
                );

                header.setForeground(
                        java.awt.Color.WHITE
                );

                header.setPreferredSize(
                        new java.awt.Dimension(
                                header.getPreferredSize().width,
                                42
                        )
                );

                header.setReorderingAllowed(false);


                // =====================================================
                // CENTER HEADER
                // =====================================================

                javax.swing.table.DefaultTableCellRenderer headerRenderer =
                        new javax.swing.table.DefaultTableCellRenderer();

                headerRenderer.setBackground(
                        new java.awt.Color(0, 102, 51)
                );

                headerRenderer.setForeground(
                        java.awt.Color.WHITE
                );

                headerRenderer.setFont(
                        new java.awt.Font(
                                "Segoe UI",
                                java.awt.Font.BOLD,
                                15
                        )
                );

                headerRenderer.setHorizontalAlignment(
                        javax.swing.SwingConstants.CENTER
                );

                headerRenderer.setOpaque(true);

                for (int i = 0;
                        i < table.getColumnCount();
                        i++) {

                        table.getColumnModel()
                                .getColumn(i)
                                .setHeaderRenderer(headerRenderer);
                }


                // =====================================================
                // CENTER TABLE VALUES
                // =====================================================

                javax.swing.table.DefaultTableCellRenderer center =
                        new javax.swing.table.DefaultTableCellRenderer();

                center.setHorizontalAlignment(
                        javax.swing.SwingConstants.CENTER
                );

                for (int i = 0;
                        i < table.getColumnCount();
                        i++) {

                        table.getColumnModel()
                                .getColumn(i)
                                .setCellRenderer(center);
                }
        }
    private void loadRecentPatients() {

    if (conn == null) {
        return;
    }

    DefaultTableModel model =
            (DefaultTableModel) AppointmentsTable1.getModel();

    model.setRowCount(0);

    String sql =
            "SELECT CONCAT(first_name, ' ', last_name) AS patient_name, "
            + "date_added, status "
            + "FROM Patients "
            + "ORDER BY date_added DESC "
            + "LIMIT 5";

    try {

        pst = conn.prepareStatement(sql);
        rs = pst.executeQuery();

        while (rs.next()) {

            Object[] row = {
                rs.getString("patient_name"),
                rs.getDate("date_added"),
                rs.getString("status")
            };

            model.addRow(row);
        }

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "Failed to load recent patients!\n"
                + e.getMessage()
        );
    }
}  
        private void loadDashboardCounts() {

                if (conn == null) {
                        return;
                }

                String sql =
                        "SELECT "
                        + "(SELECT COUNT(*) FROM Patients) AS total_patients, "
                        + "(SELECT COUNT(*) FROM Appointments "
                        + "WHERE appointment_date = CURDATE() "
                        + "AND status != 'Cancelled') AS total_appointments, "
                        + "(SELECT COUNT(*) FROM Doctors "
                        + "WHERE status = 'Available') AS available_doctors, "
                        + "(SELECT COUNT(*) FROM Staff "
                        + "WHERE status = 'Active') AS active_staff";

                try {

                        pst = conn.prepareStatement(sql);
                        rs = pst.executeQuery();

                        if (rs.next()) {

                                TotalPatients.setText(
                                        String.valueOf(
                                                rs.getInt("total_patients")
                                        )
                                );

                                AppointmentsTotal.setText(
                                        String.valueOf(
                                                rs.getInt("total_appointments")
                                        )
                                );

                                TotalDoc.setText(
                                        String.valueOf(
                                                rs.getInt("available_doctors")
                                        )
                                );

                                AllStaff.setText(
                                        String.valueOf(
                                                rs.getInt("active_staff")
                                        )
                                );
                        }

                } catch (SQLException e) {

                        JOptionPane.showMessageDialog(
                                this,
                                "Failed to load dashboard counts!\n"
                                + e.getMessage()
                        );
                }
        }
private void setupDateTime() {

    // EASY SETTINGS
    int positionX = 1500;   // Higher = move right
    int dateY = 20;         // Higher = move down
    int timeY = 50;         // Higher = move down
    int width = 400;

    int dateFontSize = 16;
    int timeFontSize = 28;

    // CREATE LABELS
    dateLabel = new javax.swing.JLabel();
    timeLabel = new javax.swing.JLabel();

    // DATE
    dateLabel.setFont(
            new java.awt.Font(
                    "Segoe UI",
                    java.awt.Font.BOLD,
                    dateFontSize
            )
    );

    dateLabel.setForeground(
            java.awt.Color.WHITE
    );

    dateLabel.setHorizontalAlignment(
            javax.swing.SwingConstants.RIGHT
    );

    // TIME
    timeLabel.setFont(
            new java.awt.Font(
                    "Segoe UI",
                    java.awt.Font.BOLD,
                    timeFontSize
            )
    );

    timeLabel.setForeground(
            java.awt.Color.WHITE
    );

    timeLabel.setHorizontalAlignment(
            javax.swing.SwingConstants.RIGHT
    );

    // POSITION
    getContentPane().add(
            dateLabel,
            new org.netbeans.lib.awtextra.AbsoluteConstraints(
                    positionX,
                    dateY,
                    width,
                    30
            )
    );

    getContentPane().add(
            timeLabel,
            new org.netbeans.lib.awtextra.AbsoluteConstraints(
                    positionX,
                    timeY,
                    width,
                    40
            )
    );

    // START CLOCK
    updateDateTime();

    clockTimer = new javax.swing.Timer(
            1000,
            e -> updateDateTime()
    );

    clockTimer.start();
}
private void updateDateTime() {

    java.time.LocalDateTime now =
            java.time.LocalDateTime.now();

    java.time.format.DateTimeFormatter dateFormat =
            java.time.format.DateTimeFormatter.ofPattern(
                    "EEEE, MMMM dd, yyyy"
            );

    java.time.format.DateTimeFormatter timeFormat =
            java.time.format.DateTimeFormatter.ofPattern(
                    "hh:mm:ss a"
            );

    dateLabel.setText(
            now.format(dateFormat)
    );

    timeLabel.setText(
            now.format(timeFormat)
    );
}
        private void styleDashboardCards() {

                javax.swing.JPanel[] cards = {
                        TotalPatientsPanel,
                        AppointmentsPanel,
                        TotalDoctorsPanel,
                        TotalStaffPanel
                };

                for (javax.swing.JPanel card : cards) {

                        // Slightly darker mint background
                        card.setBackground(
                                new java.awt.Color(214, 239, 225)
                        );

                        // Green border
                        card.setBorder(
                                javax.swing.BorderFactory.createLineBorder(
                                        new java.awt.Color(0, 102, 51),
                                        2
                                )
                        );

                        card.setOpaque(true);
                }

                // Make numbers stronger
                TotalPatients.setForeground(
                        new java.awt.Color(0, 80, 40)
                );

                AppointmentsTotal.setForeground(
                        new java.awt.Color(0, 80, 40)
                );

                TotalDoc.setForeground(
                        new java.awt.Color(0, 80, 40)
                );

                AllStaff.setForeground(
                        new java.awt.Color(0, 80, 40)
                );
        }
// CONSTRUCTOR
    public Dashboard() {

                initComponents();

                styleDashboardCards();
                setupDateTime();
                designDashboardTables();

                connectDatabase();

                loadDashboardCounts();
                loadUpcomingAppointments();
                loadRecentPatients();

                AppointmentsTable.setDefaultEditor(
                        Object.class,
                        null
                );

                AppointmentsTable1.setDefaultEditor(
                        Object.class,
                        null
                );

                setExtendedState(
                        javax.swing.JFrame.MAXIMIZED_BOTH
                );

                java.awt.EventQueue.invokeLater(() -> {

                        getContentPane().setLayout(null);

                        scaleDashboard();

                        repaint();
                });
        }
    private void connectDatabase() {

        try {

                Class.forName(
                        "com.mysql.cj.jdbc.Driver"
                );

                conn = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/ClinicManagementSystem",
                        "root",
                        ""
                );

                System.out.println(
                        "Dashboard Database Connected!"
                );

        } catch (ClassNotFoundException | SQLException e) {

                JOptionPane.showMessageDialog(
                        this,
                        "Database Connection Failed!\n"
                        + e.getMessage()
                );
        }
}
    private void loadUpcomingAppointments() {

        if (conn == null) {
                return;
        }

        DefaultTableModel model =
                (DefaultTableModel)
                AppointmentsTable.getModel();

        model.setRowCount(0);

        String sql =
                "SELECT "
                + "a.appointment_id, "
                + "CONCAT(p.first_name, ' ', p.last_name) "
                + "AS patient_name, "
                + "CONCAT(d.first_name, ' ', d.last_name) "
                + "AS doctor_name, "
                + "a.appointment_date, "
                + "a.appointment_time, "
                + "a.status "
                + "FROM Appointments a "
                + "JOIN Patients p "
                + "ON a.patient_id = p.patient_id "
                + "JOIN Doctors d "
                + "ON a.doctor_id = d.doctor_id "
                + "WHERE a.appointment_date >= CURDATE() "
                + "AND a.status != 'Completed' "
                + "ORDER BY "
                + "a.appointment_date ASC, "
                + "a.appointment_time ASC "
                + "LIMIT 5";

        try {

                pst = conn.prepareStatement(sql);
                rs = pst.executeQuery();

                while (rs.next()) {

                        Object[] row = {

                                rs.getInt(
                                        "appointment_id"
                                ),

                                rs.getString(
                                        "patient_name"
                                ),

                                rs.getString(
                                        "doctor_name"
                                ),

                                rs.getDate(
                                        "appointment_date"
                                ),

                                rs.getTime(
                                        "appointment_time"
                                ),

                                rs.getString(
                                        "status"
                                )
                        };

                        model.addRow(row);
                }

        } catch (SQLException e) {

                JOptionPane.showMessageDialog(
                        this,
                        "Failed to load upcoming appointments!\n"
                        + e.getMessage()
                );
        }
}

// DASHBOARD RESPONSIVE SCALING

    // =========================================================
    // DASHBOARD RESPONSIVE SCALING
    // Adjusts component position and size based on screen size
    // Original design resolution: 1920 x 1080
    // =========================================================

    private void scaleDashboard() {

        int screenWidth = getContentPane().getWidth();
        int screenHeight = getContentPane().getHeight();

        double scaleX = screenWidth / 1920.0;
        double scaleY = screenHeight / 1080.0;

        // Use the smaller scale only for fonts and icons
        double fontScale = Math.min(scaleX, scaleY);

        for (java.awt.Component component :
                getContentPane().getComponents()) {

            java.awt.Rectangle b = component.getBounds();

            component.setBounds(

                // Position
                (int) (b.x * scaleX),
                (int) (b.y * scaleY),

                // Size
                (int) (b.width * scaleX),
                (int) (b.height * scaleY)
            );

            // Scale fonts
            java.awt.Font font = component.getFont();

            if (font != null) {

                component.setFont(
                    font.deriveFont(
                        (float) (
                            font.getSize2D()
                            * fontScale
                        )
                    )
                );
            }
        }
        
        // Scale the icons
        scaleDashboardIcons(fontScale);

        // Fix icon, title, and number positions inside the cards
        fixDashboardCardContents(fontScale);

        // Fix Upcoming Appointments and Recent Patients tables
        fixDashboardTables(fontScale);

        // Scale images
        scaleBackground();
        scaleBuildingImage();
    }
    
// TOP DASHBOARD CARDS
// Total Patients / Appointments / Doctors / Staff
 private void fixDashboardCards(double scaleX, double scaleY) {

        int y = (int) (200 * scaleY);
        int width = (int) (230 * scaleX);
        int height = (int) (115 * scaleY);
        // Total Patients
        TotalPatientsPanel.setBounds(
            (int) (420 * scaleX),
            y,
            width,
            height
        );

        // Appointments
        AppointmentsPanel.setBounds(
            (int) (680 * scaleX),
            y,
            width,
            height
        );

        // Total Doctors
        TotalDoctorsPanel.setBounds(
            (int) (950 * scaleX),
            y,
            width,
            height
        );

        // Total Staff
        TotalStaffPanel.setBounds(
            (int) (1220 * scaleX),
            y,
            width,
            height
        );
    }
    // DASHBOARD CARD ICONS
    private void scaleDashboardIcons(double scale) {

        // Patients icon
        scaleIcon(
            PatientsIcon,
            "/images/icons8-patients-80.png",
            scale
        );

        // Appointments icon
        scaleIcon(
            AppointmentsIcnon,
            "/images/icons8-appointment-80.png",
            scale
        );

        // Doctors icon
        scaleIcon(
            DoctorIcon,
            "/images/icons8-doctors-80 (1).png",
            scale
        );

        // Staff icon
        scaleIcon(
            StaffIcon,
            "/images/icons8-staff-80.png",
            scale
        );
    }


// GENERAL ICON SCALING METHOD


     private void scaleIcon(
            javax.swing.JLabel label,
            String path,
            double scale) {

        javax.swing.ImageIcon icon =
            new javax.swing.ImageIcon(
                getClass().getResource(path)
            );

        int size = (int) (68  * scale);

        java.awt.Image image =
            icon.getImage().getScaledInstance(
                size,
                size,
                java.awt.Image.SCALE_SMOOTH
            );

        label.setIcon(
            new javax.swing.ImageIcon(image)
        );
    }

    // =========================================================
    // RESPONSIVE DASHBOARD CARD CONTENTS
    // Positions the icon, title, and total number correctly
    // inside each dashboard card
    // =========================================================

    private void fixDashboardCardContents(double scale) {

        layoutDashboardCard(TotalPatientsPanel,
            PatientsIcon,
            jLabel2,
            TotalPatients,
            scale
        );

        layoutDashboardCard(AppointmentsPanel,
            AppointmentsIcnon,
            jLabel5,
            AppointmentsTotal,
            scale
        );

        layoutDashboardCard(TotalDoctorsPanel,
            DoctorIcon,
            jLabel8,
            TotalDoc,
            scale
        );

        layoutDashboardCard(TotalStaffPanel,
            StaffIcon,
            jLabel11,
            AllStaff,
            scale
        );
    }
    // =========================================================
    // SINGLE DASHBOARD CARD LAYOUT
    // =========================================================

         private void layoutDashboardCard(
                javax.swing.JPanel panel,
                javax.swing.JLabel icon,
                javax.swing.JLabel title,
                javax.swing.JLabel count,
                double scale) {

                panel.setLayout(null);

                int width = panel.getWidth();
                int height = panel.getHeight();

                int padding =
                        Math.max(6, (int) (8 * scale));

                // Slightly smaller icon so text gets more room
                int iconSize =
                        Math.min(
                                (int) (72 * scale),
                                height - (padding * 2)
                        );

                // ICON
                icon.setBounds(
                        padding,
                        (height - iconSize) / 2,
                        iconSize,
                        iconSize
                );

                // TEXT AREA
                int textX =
                        padding
                        + iconSize
                        + Math.max(4, (int) (5 * scale));

                int textWidth =
                        width - textX - padding;

                // =====================================================
                // TITLE
                // =====================================================

                int titleY =
                        Math.max(6, (int) (8 * scale));

                int titleHeight =
                        Math.max(38, (int) (42 * scale));

                float titleSize = 16f;

                // Total Patients
                if (title == jLabel2) {

                        title.setText(
                                "<html><div style='text-align:center;'>"
                                + "Total<br>Patients"
                                + "</div></html>"
                        );
                }

                // Today's Appointments
                if (title == jLabel5) {

                        title.setText(
                                "<html><div style='text-align:center;'>"
                                + "Today's<br>Appointments"
                                + "</div></html>"
                        );
                }

                // Available Doctors
                if (title == jLabel8) {

                        title.setText(
                                "<html><div style='text-align:center;'>"
                                + "Available<br>Doctors"
                                + "</div></html>"
                        );
                }

                // Active Staff
                if (title == jLabel11) {

                        title.setText(
                                "<html><div style='text-align:center;'>"
                                + "Active<br>Staff"
                                + "</div></html>"
                        );
                }

                title.setBounds(
                        textX,
                        titleY,
                        textWidth,
                        titleHeight
                );

                title.setHorizontalAlignment(
                        javax.swing.SwingConstants.CENTER
                );

                title.setVerticalAlignment(
                        javax.swing.SwingConstants.CENTER
                );

                title.setFont(
                        title.getFont().deriveFont(
                                Math.max(
                                        13f,
                                        titleSize * (float) scale
                                )
                        )
                );

                // =====================================================
                // NUMBER
                // =====================================================

                int countY =
                        titleY + titleHeight;

                count.setBounds(
                        textX,
                        countY,
                        textWidth,
                        height - countY - 3
                );

                count.setFont(
                        count.getFont().deriveFont(
                                Math.max(
                                        24f,
                                        34f * (float) scale
                                )
                        )
                );

                count.setHorizontalAlignment(
                        javax.swing.SwingConstants.CENTER
                );

                count.setVerticalAlignment(
                        javax.swing.SwingConstants.CENTER
                );

                panel.revalidate();
                panel.repaint();
        }
    // =========================================================
    // RESPONSIVE DASHBOARD TABLES
    // Fixes Upcoming Appointments and Recent Patients
    // =========================================================

    private void fixDashboardTables(double scale) {

        // =====================================================
        // UPCOMING APPOINTMENTS
        // =====================================================

        UpcomingPanel.setLayout(null);

        int upcomingWidth = UpcomingPanel.getWidth();
        int upcomingHeight = UpcomingPanel.getHeight();

        int padding = Math.max(8, (int) (12 * scale));
        int titleHeight = Math.max(28, (int) (40 * scale));
        int buttonHeight = Math.max(35, (int) (48 * scale));
        int buttonWidth = Math.max(
            240,
            ViewAll.getPreferredSize().width + 30
        );
        // Upcoming Appointments title
        jLabel14.setBounds(
            padding,
            padding,
            upcomingWidth - (padding * 2),
            titleHeight
        );

        // View All Appointments button
        ViewAll.setBounds(
            (upcomingWidth - buttonWidth) / 2,
            upcomingHeight - buttonHeight - padding,
            buttonWidth,
            buttonHeight
        );

        ViewAll.setHorizontalAlignment(
            javax.swing.SwingConstants.CENTER
        );
        // Table position
        int tableY =
            padding + titleHeight + 8;

        int tableHeight =
            ViewAll.getY() - tableY - 8;

        jScrollPane1.setBounds(
            0,
            tableY,
            upcomingWidth,
            tableHeight
        );

        // Make all 5 columns fit
        AppointmentsTable.setAutoResizeMode(
            javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS
        );


        // =====================================================
        // RECENT PATIENTS
        // =====================================================

        jPanel7.setLayout(null);

        int recentWidth = jPanel7.getWidth();
        int recentHeight = jPanel7.getHeight();

        int recentTitleHeight =
                Math.max(24, (int) (32 * scale));

        int recentButtonHeight =
                Math.max(35, (int) (48 * scale));

        int recentButtonWidth =
                Math.max(
                        220,
                        ViewAll1.getPreferredSize().width + 30
                );

        // Recent Patients title
        jLabel16.setBounds(
                padding,
                padding,
                recentWidth - (padding * 2),
                recentTitleHeight
        );

        // View All Patients button
        ViewAll1.setBounds(
                (recentWidth - recentButtonWidth) / 2,
                recentHeight - recentButtonHeight - padding,
                recentButtonWidth,
                recentButtonHeight
        );

        ViewAll1.setHorizontalAlignment(
                javax.swing.SwingConstants.CENTER
        );

        // Table position
        int recentTableY =
                padding + recentTitleHeight + 5;

        int recentTableHeight =
                ViewAll1.getY()
                - recentTableY
                - 8;

        jScrollPane2.setBounds(
                0,
                recentTableY,
                recentWidth,
                recentTableHeight
        );

        AppointmentsTable1.setAutoResizeMode(
                javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS
        );

        jPanel7.revalidate();
        jPanel7.repaint();
    }
// DASHBOARD BACKGROUND IMAGE

    private void scaleBackground() {

        int width = getContentPane().getWidth();
        int height = getContentPane().getHeight();

        javax.swing.ImageIcon icon =
            new javax.swing.ImageIcon(
                getClass().getResource("/images/Dashgh.png")
            );

        java.awt.Image image =
            icon.getImage().getScaledInstance(
                width,
                height,
                java.awt.Image.SCALE_SMOOTH
            );

        jLabel1.setIcon(
            new javax.swing.ImageIcon(image)
        );

        jLabel1.setBounds(
            0,
            0,
            width,
            height
        );

        // Keep background behind all other components
        getContentPane().setComponentZOrder(
            jLabel1,
            getContentPane().getComponentCount() - 1
        );
    }


    // =========================================================
    // CLINIC BUILDING IMAGE
    // Crops image to completely fill panel
    // Removes visible black bars around the photo
    // =========================================================

    private void scaleBuildingImage() {

        jPanel6.setLayout(null);

        int panelWidth = jPanel6.getWidth();
        int panelHeight = jPanel6.getHeight();

        jLabel15.setBounds(
            0,
            0,
            panelWidth,
            panelHeight
        );

        javax.swing.ImageIcon icon =
            new javax.swing.ImageIcon(
                getClass().getResource("/images/bldg (1).png")
            );

        java.awt.Image original = icon.getImage();

        int imageWidth = icon.getIconWidth();
        int imageHeight = icon.getIconHeight();

        double panelRatio =
            (double) panelWidth / panelHeight;

        double imageRatio =
            (double) imageWidth / imageHeight;

        int cropX = 0;
        int cropY = 0;
        int cropWidth = imageWidth;
        int cropHeight = imageHeight;

        if (imageRatio > panelRatio) {

            // Image is too wide
            cropWidth =
                (int) (imageHeight * panelRatio);

            cropX =
                (imageWidth - cropWidth) / 2;

        } else {

            // Image is too tall
            cropHeight =
                (int) (imageWidth / panelRatio);

            cropY =
                (imageHeight - cropHeight) / 2;
        }

        java.awt.image.BufferedImage output =
            new java.awt.image.BufferedImage(
                panelWidth,
                panelHeight,
                java.awt.image.BufferedImage.TYPE_INT_RGB
            );

        java.awt.Graphics2D g2 =
            output.createGraphics();

        g2.setRenderingHint(
            java.awt.RenderingHints.KEY_INTERPOLATION,
            java.awt.RenderingHints.VALUE_INTERPOLATION_BILINEAR
        );

        g2.drawImage(
            original,

            // Destination
            0,
            0,
            panelWidth,
            panelHeight,

            // Cropped source area
            cropX,
            cropY,
            cropX + cropWidth,
            cropY + cropHeight,

            null
        );

        g2.dispose();

        jLabel15.setIcon(
            new javax.swing.ImageIcon(output)
        );

        jPanel6.repaint();
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        LogOut = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        Doctors = new javax.swing.JButton();
        Patients = new javax.swing.JButton();
        MedicalRecords = new javax.swing.JButton();
        Services = new javax.swing.JButton();
        Payments = new javax.swing.JButton();
        Staff = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        TotalStaffPanel = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        StaffIcon = new javax.swing.JLabel();
        AllStaff = new javax.swing.JLabel();
        TotalDoctorsPanel = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        DoctorIcon = new javax.swing.JLabel();
        TotalDoc = new javax.swing.JLabel();
        AppointmentsPanel = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        AppointmentsIcnon = new javax.swing.JLabel();
        AppointmentsTotal = new javax.swing.JLabel();
        TotalPatientsPanel = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        PatientsIcon = new javax.swing.JLabel();
        TotalPatients = new javax.swing.JLabel();
        UserAccounts = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        AppointmentsTable1 = new javax.swing.JTable();
        ViewAll1 = new javax.swing.JButton();
        AddMEd = new javax.swing.JButton();
        UpcomingPanel = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        AppointmentsTable = new javax.swing.JTable();
        ViewAll = new javax.swing.JButton();
        Add = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jButton17 = new javax.swing.JButton();
        Appointments = new javax.swing.JButton();
        UserAccounts1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        LogOut.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        LogOut.setForeground(new java.awt.Color(204, 0, 0));
        LogOut.setText("Log Out");
        LogOut.setBorderPainted(false);
        LogOut.setContentAreaFilled(false);
        LogOut.setDefaultCapable(false);
        LogOut.setFocusPainted(false);
        LogOut.setFocusable(false);
        LogOut.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        LogOut.addActionListener(this::LogOutActionPerformed);
        getContentPane().add(LogOut, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 990, 260, 60));

        jButton3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton3.setForeground(new java.awt.Color(102, 102, 102));
        jButton3.setText("Clinic Management System");
        jButton3.setBorderPainted(false);
        jButton3.setContentAreaFilled(false);
        jButton3.setDefaultCapable(false);
        jButton3.setFocusPainted(false);
        jButton3.setFocusable(false);
        jButton3.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 90, 260, -1));

        Doctors.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Doctors.setForeground(new java.awt.Color(255, 255, 255));
        Doctors.setText("Doctors");
        Doctors.setBorderPainted(false);
        Doctors.setContentAreaFilled(false);
        Doctors.setDefaultCapable(false);
        Doctors.setFocusPainted(false);
        Doctors.setFocusable(false);
        Doctors.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Doctors.addActionListener(this::DoctorsActionPerformed);
        getContentPane().add(Doctors, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 490, 260, 90));

        Patients.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Patients.setForeground(new java.awt.Color(255, 255, 255));
        Patients.setText("Patients");
        Patients.setBorderPainted(false);
        Patients.setContentAreaFilled(false);
        Patients.setDefaultCapable(false);
        Patients.setFocusPainted(false);
        Patients.setFocusable(false);
        Patients.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Patients.addActionListener(this::PatientsActionPerformed);
        getContentPane().add(Patients, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 430, 260, 100));

        MedicalRecords.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        MedicalRecords.setForeground(new java.awt.Color(255, 255, 255));
        MedicalRecords.setText("Medical Records");
        MedicalRecords.setBorderPainted(false);
        MedicalRecords.setContentAreaFilled(false);
        MedicalRecords.setDefaultCapable(false);
        MedicalRecords.setFocusPainted(false);
        MedicalRecords.setFocusable(false);
        MedicalRecords.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        MedicalRecords.addActionListener(this::MedicalRecordsActionPerformed);
        getContentPane().add(MedicalRecords, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 610, 260, 90));

        Services.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Services.setForeground(new java.awt.Color(255, 255, 255));
        Services.setText("Services");
        Services.setBorderPainted(false);
        Services.setContentAreaFilled(false);
        Services.setDefaultCapable(false);
        Services.setFocusPainted(false);
        Services.setFocusable(false);
        Services.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Services.addActionListener(this::ServicesActionPerformed);
        getContentPane().add(Services, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 670, 260, 90));

        Payments.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Payments.setForeground(new java.awt.Color(255, 255, 255));
        Payments.setText("Payments");
        Payments.setBorderPainted(false);
        Payments.setContentAreaFilled(false);
        Payments.setDefaultCapable(false);
        Payments.setFocusPainted(false);
        Payments.setFocusable(false);
        Payments.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Payments.addActionListener(this::PaymentsActionPerformed);
        getContentPane().add(Payments, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 730, 260, 80));

        Staff.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Staff.setForeground(new java.awt.Color(255, 255, 255));
        Staff.setText("Staff");
        Staff.setBorderPainted(false);
        Staff.setContentAreaFilled(false);
        Staff.setDefaultCapable(false);
        Staff.setFocusPainted(false);
        Staff.setFocusable(false);
        Staff.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Staff.addActionListener(this::StaffActionPerformed);
        getContentPane().add(Staff, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 780, 260, 80));

        jButton10.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton10.setForeground(new java.awt.Color(0, 102, 51));
        jButton10.setText("Dashboard");
        jButton10.setDefaultCapable(false);
        jButton10.setFocusPainted(false);
        jButton10.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        getContentPane().add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 390, 260, 60));

        jButton11.setFont(new java.awt.Font("Segoe UI", 1, 40)); // NOI18N
        jButton11.setText("Admin");
        jButton11.setBorderPainted(false);
        jButton11.setContentAreaFilled(false);
        jButton11.setDefaultCapable(false);
        jButton11.setFocusPainted(false);
        jButton11.setFocusable(false);
        jButton11.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        getContentPane().add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 50, 260, -1));

        jButton12.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton12.setText("Welcome Back,");
        jButton12.setBorderPainted(false);
        jButton12.setContentAreaFilled(false);
        jButton12.setDefaultCapable(false);
        jButton12.setFocusPainted(false);
        jButton12.setFocusable(false);
        jButton12.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        getContentPane().add(jButton12, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 30, 260, -1));

        TotalStaffPanel.setBackground(new java.awt.Color(222, 240, 229));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel11.setText("Active Staff");

        StaffIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-staff-80.png"))); // NOI18N

        AllStaff.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        AllStaff.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        AllStaff.setText("0");

        javax.swing.GroupLayout TotalStaffPanelLayout = new javax.swing.GroupLayout(TotalStaffPanel);
        TotalStaffPanel.setLayout(TotalStaffPanelLayout);
        TotalStaffPanelLayout.setHorizontalGroup(
            TotalStaffPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TotalStaffPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(StaffIcon)
                .addGroup(TotalStaffPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(TotalStaffPanelLayout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addComponent(AllStaff))
                    .addGroup(TotalStaffPanelLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel11)))
                .addContainerGap(30, Short.MAX_VALUE))
        );
        TotalStaffPanelLayout.setVerticalGroup(
            TotalStaffPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TotalStaffPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(TotalStaffPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(StaffIcon)
                    .addGroup(TotalStaffPanelLayout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(AllStaff, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(TotalStaffPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(1220, 200, 230, 100));

        TotalDoctorsPanel.setBackground(new java.awt.Color(222, 240, 229));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel8.setText("Available Doctors");

        DoctorIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-doctors-80 (1).png"))); // NOI18N

        TotalDoc.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        TotalDoc.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TotalDoc.setText("0");

        javax.swing.GroupLayout TotalDoctorsPanelLayout = new javax.swing.GroupLayout(TotalDoctorsPanel);
        TotalDoctorsPanel.setLayout(TotalDoctorsPanelLayout);
        TotalDoctorsPanelLayout.setHorizontalGroup(
            TotalDoctorsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TotalDoctorsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(DoctorIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(TotalDoctorsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(TotalDoctorsPanelLayout.createSequentialGroup()
                        .addGap(60, 60, 60)
                        .addComponent(TotalDoc)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TotalDoctorsPanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );
        TotalDoctorsPanelLayout.setVerticalGroup(
            TotalDoctorsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TotalDoctorsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(TotalDoctorsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(DoctorIcon)
                    .addGroup(TotalDoctorsPanelLayout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(TotalDoc, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(TotalDoctorsPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 200, 230, 100));

        AppointmentsPanel.setBackground(new java.awt.Color(222, 240, 229));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setText("Today's Appointments");

        AppointmentsIcnon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-appointment-80.png"))); // NOI18N

        AppointmentsTotal.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        AppointmentsTotal.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        AppointmentsTotal.setText("0");

        javax.swing.GroupLayout AppointmentsPanelLayout = new javax.swing.GroupLayout(AppointmentsPanel);
        AppointmentsPanel.setLayout(AppointmentsPanelLayout);
        AppointmentsPanelLayout.setHorizontalGroup(
            AppointmentsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, AppointmentsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(AppointmentsIcnon)
                .addGroup(AppointmentsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(AppointmentsPanelLayout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addComponent(AppointmentsTotal))
                    .addGroup(AppointmentsPanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        AppointmentsPanelLayout.setVerticalGroup(
            AppointmentsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(AppointmentsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(AppointmentsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(AppointmentsIcnon)
                    .addGroup(AppointmentsPanelLayout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(AppointmentsTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(8, Short.MAX_VALUE))
        );

        getContentPane().add(AppointmentsPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 200, 230, 100));

        TotalPatientsPanel.setBackground(new java.awt.Color(222, 240, 229));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel2.setText("Total Patients");

        PatientsIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-patients-80.png"))); // NOI18N

        TotalPatients.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        TotalPatients.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TotalPatients.setText("0");

        javax.swing.GroupLayout TotalPatientsPanelLayout = new javax.swing.GroupLayout(TotalPatientsPanel);
        TotalPatientsPanel.setLayout(TotalPatientsPanelLayout);
        TotalPatientsPanelLayout.setHorizontalGroup(
            TotalPatientsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TotalPatientsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(PatientsIcon)
                .addGroup(TotalPatientsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(TotalPatientsPanelLayout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addComponent(TotalPatients))
                    .addGroup(TotalPatientsPanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel2)))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        TotalPatientsPanelLayout.setVerticalGroup(
            TotalPatientsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TotalPatientsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(TotalPatientsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(PatientsIcon)
                    .addGroup(TotalPatientsPanelLayout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(TotalPatients, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(TotalPatientsPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 200, 230, 100));

        UserAccounts.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        UserAccounts.setForeground(new java.awt.Color(255, 255, 255));
        UserAccounts.setText("Archive");
        UserAccounts.setBorderPainted(false);
        UserAccounts.setContentAreaFilled(false);
        UserAccounts.setDefaultCapable(false);
        UserAccounts.setFocusPainted(false);
        UserAccounts.setFocusable(false);
        UserAccounts.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        UserAccounts.addActionListener(this::UserAccountsActionPerformed);
        getContentPane().add(UserAccounts, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 890, 260, 80));

        jPanel7.setBackground(new java.awt.Color(222, 246, 236));

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel16.setText("Recent Patients");

        AppointmentsTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Patient Name", "Date", "Status"
            }
        ));
        AppointmentsTable1.setFocusCycleRoot(true);
        AppointmentsTable1.setGridColor(new java.awt.Color(231, 250, 250));
        AppointmentsTable1.setShowGrid(true);
        AppointmentsTable1.setSurrendersFocusOnKeystroke(true);
        jScrollPane2.setViewportView(AppointmentsTable1);

        ViewAll1.setBackground(new java.awt.Color(0, 102, 51));
        ViewAll1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        ViewAll1.setForeground(new java.awt.Color(255, 255, 255));
        ViewAll1.setText("View All Patients");
        ViewAll1.setDefaultCapable(false);
        ViewAll1.setFocusPainted(false);
        ViewAll1.setFocusable(false);
        ViewAll1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        ViewAll1.addActionListener(this::ViewAll1ActionPerformed);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(ViewAll1)
                .addGap(449, 449, 449))
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1070, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(455, 455, 455)
                        .addComponent(jLabel16)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel16)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 256, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ViewAll1)
                .addContainerGap())
        );

        getContentPane().add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 710, 1080, 350));

        AddMEd.setBackground(new java.awt.Color(0, 102, 51));
        AddMEd.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        AddMEd.setForeground(new java.awt.Color(255, 255, 255));
        AddMEd.setText("Add Medical Record");
        AddMEd.setDefaultCapable(false);
        AddMEd.setFocusPainted(false);
        AddMEd.setFocusable(false);
        AddMEd.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        AddMEd.addActionListener(this::AddMEdActionPerformed);
        getContentPane().add(AddMEd, new org.netbeans.lib.awtextra.AbsoluteConstraints(1500, 1010, -1, 48));

        UpcomingPanel.setBackground(new java.awt.Color(222, 246, 236));

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel14.setText("Upcoming Appointments");

        AppointmentsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Appointment ID", "Patient Name", "Doctor", "Date", "Time", "Status"
            }
        ));
        AppointmentsTable.setFocusCycleRoot(true);
        AppointmentsTable.setGridColor(new java.awt.Color(231, 250, 250));
        AppointmentsTable.setShowGrid(true);
        AppointmentsTable.setSurrendersFocusOnKeystroke(true);
        jScrollPane1.setViewportView(AppointmentsTable);

        ViewAll.setBackground(new java.awt.Color(0, 102, 51));
        ViewAll.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        ViewAll.setForeground(new java.awt.Color(255, 255, 255));
        ViewAll.setText("View All Appointments");
        ViewAll.setDefaultCapable(false);
        ViewAll.setFocusPainted(false);
        ViewAll.setFocusable(false);
        ViewAll.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        ViewAll.addActionListener(this::ViewAllActionPerformed);

        javax.swing.GroupLayout UpcomingPanelLayout = new javax.swing.GroupLayout(UpcomingPanel);
        UpcomingPanel.setLayout(UpcomingPanelLayout);
        UpcomingPanelLayout.setHorizontalGroup(
            UpcomingPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(UpcomingPanelLayout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1036, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 38, Short.MAX_VALUE))
            .addGroup(UpcomingPanelLayout.createSequentialGroup()
                .addGap(373, 373, 373)
                .addComponent(jLabel14)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, UpcomingPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(ViewAll)
                .addGap(409, 409, 409))
        );
        UpcomingPanelLayout.setVerticalGroup(
            UpcomingPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(UpcomingPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 236, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ViewAll)
                .addContainerGap())
        );

        getContentPane().add(UpcomingPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 350, 1080, 330));

        Add.setBackground(new java.awt.Color(0, 102, 51));
        Add.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Add.setForeground(new java.awt.Color(255, 255, 255));
        Add.setText("      Add Patient");
        Add.setDefaultCapable(false);
        Add.setFocusPainted(false);
        Add.setFocusable(false);
        Add.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Add.addActionListener(this::AddActionPerformed);
        getContentPane().add(Add, new org.netbeans.lib.awtextra.AbsoluteConstraints(1500, 890, 200, 48));

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/bldg (1).png"))); // NOI18N

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel15)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 660, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(1470, 200, 440, 660));

        jButton17.setBackground(new java.awt.Color(0, 102, 51));
        jButton17.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton17.setForeground(new java.awt.Color(255, 255, 255));
        jButton17.setText(" New Appointment");
        jButton17.setDefaultCapable(false);
        jButton17.setFocusPainted(false);
        jButton17.setFocusable(false);
        jButton17.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton17.addActionListener(this::jButton17ActionPerformed);
        getContentPane().add(jButton17, new org.netbeans.lib.awtextra.AbsoluteConstraints(1500, 950, 200, 48));

        Appointments.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Appointments.setForeground(new java.awt.Color(255, 255, 255));
        Appointments.setText("Appointments");
        Appointments.setBorderPainted(false);
        Appointments.setContentAreaFilled(false);
        Appointments.setDefaultCapable(false);
        Appointments.setFocusPainted(false);
        Appointments.setFocusable(false);
        Appointments.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Appointments.addActionListener(this::AppointmentsActionPerformed);
        getContentPane().add(Appointments, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 550, 260, 90));

        UserAccounts1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        UserAccounts1.setForeground(new java.awt.Color(255, 255, 255));
        UserAccounts1.setText("User Accounts");
        UserAccounts1.setBorderPainted(false);
        UserAccounts1.setContentAreaFilled(false);
        UserAccounts1.setDefaultCapable(false);
        UserAccounts1.setFocusPainted(false);
        UserAccounts1.setFocusable(false);
        UserAccounts1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        UserAccounts1.addActionListener(this::UserAccounts1ActionPerformed);
        getContentPane().add(UserAccounts1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 830, 260, 80));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Dashgh.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1930, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void DoctorsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DoctorsActionPerformed
        Doctors doctors = new Doctors();
        doctors.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_DoctorsActionPerformed

    private void MedicalRecordsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MedicalRecordsActionPerformed
    MedicalRecords records = new MedicalRecords();
    records.setVisible(true);
    this.dispose();
        // TODO add your handling code here:
    }//GEN-LAST:event_MedicalRecordsActionPerformed

    private void PatientsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PatientsActionPerformed
        Patients Patients = new Patients();
        Patients.setVisible(true);
        this.dispose();    
    }//GEN-LAST:event_PatientsActionPerformed

    private void AppointmentsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AppointmentsActionPerformed
        Appointments appointments = new Appointments();
        appointments.setVisible(true);
        this.dispose();   
    }//GEN-LAST:event_AppointmentsActionPerformed

    private void AddMEdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddMEdActionPerformed
    MedicalRecords records = new MedicalRecords();
    records.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_AddMEdActionPerformed

    private void AddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddActionPerformed
        Patients Patients = new Patients();
        Patients.setVisible(true);
        this.dispose();           // TODO add your handling code here:
    }//GEN-LAST:event_AddActionPerformed

    private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton17ActionPerformed
        Appointments appointments = new Appointments();
        appointments.setVisible(true);
        this.dispose();             // TODO add your handling code here:
    }//GEN-LAST:event_jButton17ActionPerformed

    private void ServicesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ServicesActionPerformed
    Services services = new Services();
    services.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_ServicesActionPerformed

    private void PaymentsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PaymentsActionPerformed
    Payments payments = new Payments();
    payments.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_PaymentsActionPerformed

    private void StaffActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StaffActionPerformed
    Staff staff = new Staff();
    staff.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_StaffActionPerformed

    private void UserAccountsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UserAccountsActionPerformed
        Archive archive = new Archive();
        archive.setVisible(true);
        this.dispose();     // TODO add your handling code here:
    }//GEN-LAST:event_UserAccountsActionPerformed

    private void LogOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LogOutActionPerformed
    UserSession.logout();
    SignIn logout = new SignIn();
    logout.setVisible(true);
    this.dispose();
        // TODO add your handling code here:
    }//GEN-LAST:event_LogOutActionPerformed

    private void UserAccounts1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UserAccounts1ActionPerformed
    UserAccounts accounts = new UserAccounts();
    accounts.setVisible(true);
    this.dispose();     // TODO add your handling code here:
    }//GEN-LAST:event_UserAccounts1ActionPerformed

    private void ViewAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ViewAllActionPerformed
        Appointments appointments = new Appointments();
        appointments.setVisible(true);
        this.dispose();           // TODO add your handling code here:
    }//GEN-LAST:event_ViewAllActionPerformed

    private void ViewAll1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ViewAll1ActionPerformed
        Patients patients = new Patients();
        patients.setVisible(true);
        this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_ViewAll1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Add;
    private javax.swing.JButton AddMEd;
    private javax.swing.JLabel AllStaff;
    private javax.swing.JButton Appointments;
    private javax.swing.JLabel AppointmentsIcnon;
    private javax.swing.JPanel AppointmentsPanel;
    private javax.swing.JTable AppointmentsTable;
    private javax.swing.JTable AppointmentsTable1;
    private javax.swing.JLabel AppointmentsTotal;
    private javax.swing.JLabel DoctorIcon;
    private javax.swing.JButton Doctors;
    private javax.swing.JButton LogOut;
    private javax.swing.JButton MedicalRecords;
    private javax.swing.JButton Patients;
    private javax.swing.JLabel PatientsIcon;
    private javax.swing.JButton Payments;
    private javax.swing.JButton Services;
    private javax.swing.JButton Staff;
    private javax.swing.JLabel StaffIcon;
    private javax.swing.JLabel TotalDoc;
    private javax.swing.JPanel TotalDoctorsPanel;
    private javax.swing.JLabel TotalPatients;
    private javax.swing.JPanel TotalPatientsPanel;
    private javax.swing.JPanel TotalStaffPanel;
    private javax.swing.JPanel UpcomingPanel;
    private javax.swing.JButton UserAccounts;
    private javax.swing.JButton UserAccounts1;
    private javax.swing.JButton ViewAll;
    private javax.swing.JButton ViewAll1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables

}