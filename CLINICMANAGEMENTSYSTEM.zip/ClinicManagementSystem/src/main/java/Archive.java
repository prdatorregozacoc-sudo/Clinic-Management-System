/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author sagar
 */
public class Archive extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Archive.class.getName());
    private java.sql.Connection conn;

private static final String SEARCH_HINT =
        "Search archived records...";

private void designArchiveTable() {

    ArchiveTable.setFont(
            new java.awt.Font(
                    "Segoe UI",
                    java.awt.Font.PLAIN,
                    15
            )
    );

    ArchiveTable.setRowHeight(38);
    // Remove blue selection background
ArchiveTable.setSelectionBackground(java.awt.Color.WHITE);

// Keep text color consistent
ArchiveTable.setSelectionForeground(
        new java.awt.Color(0, 0, 0)
);

// Remove focus border around selected cells
ArchiveTable.setShowGrid(false);
ArchiveTable.setFocusable(false);
ArchiveTable.setRowSelectionAllowed(false);
ArchiveTable.setColumnSelectionAllowed(false);
ArchiveTable.setCellSelectionEnabled(false);

    ArchiveTable.setBackground(
            java.awt.Color.WHITE
    );

  
 


    ArchiveTable.setShowHorizontalLines(true);
    ArchiveTable.setShowVerticalLines(false);

    ArchiveTable.setIntercellSpacing(
            new java.awt.Dimension(0, 1)
    );

    ArchiveTable.setFillsViewportHeight(true);


    ArchiveTable.setSelectionForeground(
            new java.awt.Color(0, 80, 40)
    );

    // =====================================================
    // HEADER
    // =====================================================

    javax.swing.table.JTableHeader header =
            ArchiveTable.getTableHeader();

    header.setFont(
            new java.awt.Font(
                    "Segoe UI",
                    java.awt.Font.BOLD,
                    15
            )
    );

    header.setBackground(
            new java.awt.Color(0, 102, 51)
    );

    header.setForeground(
            java.awt.Color.WHITE
    );

    header.setPreferredSize(
            new java.awt.Dimension(
                    header.getPreferredSize().width,
                    42
            )
    );

    header.setReorderingAllowed(false);

    javax.swing.table.DefaultTableCellRenderer headerRenderer =
            new javax.swing.table.DefaultTableCellRenderer();

    headerRenderer.setBackground(
            new java.awt.Color(0, 102, 51)
    );

    headerRenderer.setForeground(
            java.awt.Color.WHITE
    );

    headerRenderer.setFont(
            new java.awt.Font(
                    "Segoe UI",
                    java.awt.Font.BOLD,
                    15
            )
    );

    headerRenderer.setHorizontalAlignment(
            javax.swing.SwingConstants.CENTER
    );

    headerRenderer.setOpaque(true);

    for (int i = 0;
            i < ArchiveTable.getColumnCount();
            i++) {

        ArchiveTable.getColumnModel()
                .getColumn(i)
                .setHeaderRenderer(headerRenderer);
    }

    // =====================================================
    // CENTER VALUES
    // =====================================================

    javax.swing.table.DefaultTableCellRenderer center =
            new javax.swing.table.DefaultTableCellRenderer();

    center.setHorizontalAlignment(
            javax.swing.SwingConstants.CENTER
    );

    for (int i = 0;
            i < ArchiveTable.getColumnCount();
            i++) {

        ArchiveTable.getColumnModel()
                .getColumn(i)
                .setCellRenderer(center);
    }

    // =====================================================
    // COLUMN WIDTHS
    // =====================================================

    javax.swing.table.TableColumnModel columns =
            ArchiveTable.getColumnModel();

    columns.getColumn(0).setPreferredWidth(130);
    columns.getColumn(1).setPreferredWidth(100);
    columns.getColumn(2).setPreferredWidth(350);
    columns.getColumn(3).setPreferredWidth(170);
    columns.getColumn(4).setPreferredWidth(130);
    columns.getColumn(5).setPreferredWidth(130);

    // =====================================================
    // SCROLLPANE
    // =====================================================

    jScrollPane1.getViewport().setBackground(
            java.awt.Color.WHITE
    );

    jScrollPane1.setBorder(
            javax.swing.BorderFactory.createLineBorder(
                    new java.awt.Color(0, 102, 51),
                    1
            )
    );

    ArchiveTable.setDefaultEditor(
            Object.class,
            null
    );
}
   
    public Archive() {

    initComponents();
    loadArchiveRecords();
            getContentPane().setLayout(null);


    setupArchivePage();
    designArchiveTable();
    setupRestoreButton();

    // Search placeholder styling
    jTextField1.setFont(
            new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 16)
    );

    connectDatabase();
    loadArchiveRecords();

    setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);

    // Prevent search field from being selected by default
    getContentPane().setFocusable(true);

    addWindowListener(new java.awt.event.WindowAdapter() {
        @Override
        public void windowOpened(java.awt.event.WindowEvent evt) {
            getContentPane().requestFocusInWindow();
        }
    });
            addComponentListener(new java.awt.event.ComponentAdapter() {
                @Override
                public void componentResized(java.awt.event.ComponentEvent evt) {
                        fixArchiveLayout();
                }
        });

        java.awt.EventQueue.invokeLater(() -> fixArchiveLayout());
}
    private void enableLiveArchiveSearch() {

        jTextField1.getDocument().addDocumentListener(
                new javax.swing.event.DocumentListener() {

                        @Override
                        public void insertUpdate(
                                javax.swing.event.DocumentEvent e) {
                                loadArchiveRecords();
                        }

                        @Override
                        public void removeUpdate(
                                javax.swing.event.DocumentEvent e) {
                                loadArchiveRecords();
                        }

                        @Override
                        public void changedUpdate(
                                javax.swing.event.DocumentEvent e) {
                                loadArchiveRecords();
                        }
                }
        );
}
private java.awt.Image originalArchiveBackground;

private void fixArchiveSidebar() {

        int width = getContentPane().getWidth();
        int height = getContentPane().getHeight();

        if (width <= 0 || height <= 0) {
                return;
        }

        double scaleX = width / 1920.0;
        double scaleY = height / 1080.0;

        javax.swing.JButton[] buttons = {
                Dashboard,
                Patients,
                Doctors,
                Appointments,
                MedicalRecords,
                Services,
                Payments,
                Staff,
                UserAccounts,
                Archive,
                jButton1
        };

        int[] positionsY = {
                380, 450, 500, 560, 620,
                690, 750, 800, 840, 900, 990
        };

        int[] heights = {
                80, 60, 70, 70, 70,
                50, 40, 40, 60, 60, 60
        };

        int fontSize = Math.max(
                18,
                (int) Math.round(
                        24 * Math.min(scaleX, scaleY)
                )
        );

        for (int i = 0; i < buttons.length; i++) {

                javax.swing.JButton button = buttons[i];

                button.setBounds(
                        (int) (60 * scaleX),
                        (int) (positionsY[i] * scaleY),
                        (int) (260 * scaleX),
                        (int) (heights[i] * scaleY)
                );

                button.setFont(
                        new java.awt.Font(
                                "Segoe UI",
                                java.awt.Font.BOLD,
                                fontSize
                        )
                );

                button.setHorizontalAlignment(
                        javax.swing.SwingConstants.LEFT
                );

                button.setFocusPainted(false);
        }

        // Keep Archive selected
        Archive.setForeground(
                new java.awt.Color(0, 102, 51)
        );

        // Keep Log Out red
        jButton1.setForeground(
                new java.awt.Color(204, 0, 0)
        );
}

private void fixArchiveLayout() {

        int width = getContentPane().getWidth();
        int height = getContentPane().getHeight();

        if (width <= 0 || height <= 0) {
                return;
        }

        // 1. RESPONSIVE BACKGROUND
        if (originalArchiveBackground == null
                && jLabel1.getIcon() instanceof javax.swing.ImageIcon) {

                originalArchiveBackground =
                        ((javax.swing.ImageIcon) jLabel1.getIcon()).getImage();
        }

        if (originalArchiveBackground != null) {

                java.awt.Image image =
                        originalArchiveBackground.getScaledInstance(
                                width,
                                height,
                                java.awt.Image.SCALE_SMOOTH
                        );

                jLabel1.setIcon(new javax.swing.ImageIcon(image));
        }

        jLabel1.setBounds(0, 0, width, height);

        getContentPane().setComponentZOrder(
                jLabel1,
                getContentPane().getComponentCount() - 1
        );

        // 2. RESPONSIVE SIDEBAR
        int sidebarWidth = Math.max(
                210,
                (int) (width * 0.205)
        );

 
        // 3. MAIN CONTENT
        int contentX = sidebarWidth + 20;
        int contentWidth = width - contentX - 18;

        if (contentWidth <= 0) {
                return;
        }

        // ARCHIVE TITLE
        jButton11.setBounds(
                contentX,
                40,
                Math.min(360, contentWidth),
                65
        );

        jButton11.setFont(
                new java.awt.Font(
                        "Segoe UI",
                        java.awt.Font.BOLD,
                        width < 1400 ? 30 : 40
                )
        );

     // 4. SEARCH AND FILTER CONTROLS

int searchY = Math.max(
        115,
        Math.min(150, height / 5 - 15)
);

int searchHeight = 42;
int gap = 8;

int iconWidth = 42;
int filterWidth = 160;
int sortWidth = 190;
int orderWidth = 145;

// Shorter search bar
int searchWidth = (int) (720 * width / 1920.0);

int controlsWidth = iconWidth
        + filterWidth
        + sortWidth
        + orderWidth
        + gap * 4;

searchWidth = Math.max(
        100,
        Math.min(searchWidth, contentWidth - controlsWidth)
);

// SEARCH BAR
jTextField1.setBounds(
        contentX, searchY,
        searchWidth, searchHeight
);

int nextX = contentX + searchWidth + gap;

// SEARCH BUTTON
jButton3.setBounds(
        nextX, searchY,
        iconWidth, searchHeight
);

nextX += iconWidth + gap;

// FILTER
Filter.setBounds(
        nextX, searchY,
        filterWidth, searchHeight
);

nextX += filterWidth + gap;

// SORT
Sort.setBounds(
        nextX, searchY,
        sortWidth, searchHeight
);

nextX += sortWidth + gap;

// ORDER
Order.setBounds(
        nextX, searchY,
        orderWidth, searchHeight
);

// SMALLER SEARCH ICON
java.net.URL iconURL =
        getClass().getResource(
                "/images/icons8-search-47.png"
        );

if (iconURL != null) {

        java.awt.Image icon =
                new javax.swing.ImageIcon(iconURL)
                        .getImage()
                        .getScaledInstance(
                                22, 22,
                                java.awt.Image.SCALE_SMOOTH
                        );

        jButton3.setIcon(
                new javax.swing.ImageIcon(icon)
        );
}

jButton3.setHorizontalAlignment(
        javax.swing.SwingConstants.CENTER
);

jButton3.setVerticalAlignment(
        javax.swing.SwingConstants.CENTER
);

jButton3.setMargin(
        new java.awt.Insets(0, 0, 0, 0)
);
        // 5. RESPONSIVE ARCHIVE TABLE
        int tableY = searchY + searchHeight + 18;
        int tableHeight = height - tableY - 16;

        jPanel2.setBounds(
                contentX,
                tableY,
                contentWidth,
                tableHeight
        );

        jPanel2.setLayout(null);

        jScrollPane1.setBounds(
                0,
                0,
                contentWidth,
                tableHeight
        );

        // 6. RESPONSIVE COLUMN WIDTHS
        ArchiveTable.setAutoResizeMode(
                javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS
        );

        int[] columnWidths = {
                125,  // Type
                100,  // Record ID
                320,  // Name / Description
                150,  // Record Date
                120,  // Status
                130   // Action / Restore
        };

        javax.swing.table.TableColumnModel columns =
                ArchiveTable.getColumnModel();

        for (int i = 0;
                i < columns.getColumnCount()
                && i < columnWidths.length;
                i++) {

                columns.getColumn(i).setPreferredWidth(
                        columnWidths[i]
                );
        }

        if (columns.getColumnCount() > 5) {
                columns.getColumn(5).setMinWidth(110);
                columns.getColumn(5).setPreferredWidth(130);
        }

        jScrollPane1.setHorizontalScrollBarPolicy(
                javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED
        );

        jScrollPane1.setVerticalScrollBarPolicy(
                javax.swing.JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED
        );

        // 7. REFRESH LAYOUT
        fixArchiveSidebar();

        jPanel2.revalidate();
        jPanel2.repaint();

        getContentPane().revalidate();
        getContentPane().repaint();
}

private void restoreRecord(int row) {

        int modelRow = ArchiveTable.convertRowIndexToModel(row);

        String type = ArchiveTable.getModel()
                .getValueAt(modelRow, 0).toString();

        int recordId = Integer.parseInt(
                ArchiveTable.getModel()
                        .getValueAt(modelRow, 1).toString()
        );

        String description = ArchiveTable.getModel()
                .getValueAt(modelRow, 2).toString();

        int confirm = javax.swing.JOptionPane.showConfirmDialog(
                this,
                "Restore " + description + " to " + type + "?",
                "Confirm Restore",
                javax.swing.JOptionPane.YES_NO_OPTION
        );

        if (confirm != javax.swing.JOptionPane.YES_OPTION) {
            return;
        }

        String sql;

        switch (type) {
            case "Patients":
                sql = "UPDATE Patients SET status = 'Active' "
                        + "WHERE patient_id = ? AND status = 'Archived'";
                break;
case "Appointments":
        sql = "UPDATE Appointments "
                + "SET status = 'Scheduled' "
                + "WHERE appointment_id = ? "
                + "AND status = 'Archived'";
        break;
     case "Doctors":
        sql = "UPDATE Doctors "
                + "SET status = 'Available' "
                + "WHERE doctor_id = ? "
                + "AND status = 'Archived'";
        break;
case "Services":
        sql = "UPDATE Services "
                + "SET status = 'Active' "
                + "WHERE service_id = ? "
                + "AND status = 'Archived'";
        break;
    case "Payments":
        sql = "UPDATE Payments "
                + "SET is_archived = 0, status = 'Paid' "
                + "WHERE payment_id = ? "
                + "AND is_archived = 1";
        break;

            case "Staff":
                sql = "UPDATE Staff SET status = 'Active' "
                        + "WHERE staff_id = ? "
                        + "AND status IN ('Inactive', 'Archived')";
                break;

            case "User Accounts":
                sql = "UPDATE UserAccount SET status = 'Active' "
                        + "WHERE user_id = ? "
                        + "AND status IN ('Inactive', 'Disabled', 'Archived')";
                break;
case "Medical Records":
        sql = "UPDATE MedicalRecords "
                + "SET status = 'Active' "
                + "WHERE record_id = ? "
                + "AND status = 'Archived'";
        break;
            default:
                return;
        }

        try {

            if (conn == null || conn.isClosed()) {
                connectDatabase();
            }

            if (conn == null || conn.isClosed()) {
                return;
            }

            try (java.sql.PreparedStatement pst =
                    conn.prepareStatement(sql)) {

                pst.setInt(1, recordId);

                int updated = pst.executeUpdate();

                if (updated > 0) {

                    javax.swing.JOptionPane.showMessageDialog(
                            this,
                            "Record restored successfully!"
                    );

                    loadArchiveRecords();

                } else {

                    javax.swing.JOptionPane.showMessageDialog(
                            this,
                            "Record could not be restored."
                    );
                }
            }

        } catch (java.sql.SQLException e) {

            javax.swing.JOptionPane.showMessageDialog(
                    this,
                    "Restore failed!\n" + e.getMessage()
            );
        }
}



private javax.swing.JButton createRestoreButton() {

        javax.swing.JButton button =
                new javax.swing.JButton("Restore") {

                    @Override
                    protected void paintComponent(
                            java.awt.Graphics g) {

                        java.awt.Graphics2D g2 =
                                (java.awt.Graphics2D) g.create();

                        g2.setRenderingHint(
                                java.awt.RenderingHints.KEY_ANTIALIASING,
                                java.awt.RenderingHints.VALUE_ANTIALIAS_ON
                        );

                        g2.setColor(
                                new java.awt.Color(0, 153, 76)
                        );

                        g2.fillRoundRect(
                                0, 0,
                                getWidth() - 1,
                                getHeight() - 1,
                                8, 8
                        );

                        g2.dispose();
                        super.paintComponent(g);
                    }
                };

        button.setPreferredSize(
                new java.awt.Dimension(75, 24)
        );

        button.setFont(
                new java.awt.Font(
                        "Segoe UI",
                        java.awt.Font.BOLD,
                        11
                )
        );

        button.setForeground(java.awt.Color.WHITE);
        button.setContentAreaFilled(false);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setOpaque(false);

        return button;
}


private void setupRestoreButton() {

        javax.swing.table.TableColumn column =
                ArchiveTable.getColumnModel().getColumn(5);

        column.setPreferredWidth(100);

        column.setCellRenderer(
                (table, value, selected, focused, row, col) -> {

                    javax.swing.JPanel panel =
                            new javax.swing.JPanel(
                                    new java.awt.GridBagLayout()
                            );

                    panel.setBackground(java.awt.Color.WHITE);
                    panel.setOpaque(true);

                    panel.add(createRestoreButton());

                    return panel;
                }
        );

        column.setCellEditor(
                new javax.swing.DefaultCellEditor(
                        new javax.swing.JCheckBox()
                ) {

                    private final javax.swing.JPanel panel =
                            new javax.swing.JPanel(
                                    new java.awt.GridBagLayout()
                            );

                    private final javax.swing.JButton button =
                            createRestoreButton();

                    private int selectedRow;

                    {
                        panel.setBackground(java.awt.Color.WHITE);
                        panel.setOpaque(true);
                        panel.add(button);

                        button.addActionListener(e -> {

                            int rowToRestore = selectedRow;

                            fireEditingStopped();

                            restoreRecord(rowToRestore);
                        });
                    }

                    @Override
                    public java.awt.Component getTableCellEditorComponent(
                            javax.swing.JTable table,
                            Object value,
                            boolean selected,
                            int row,
                            int column) {

                        selectedRow = row;

                        return panel;
                    }

                    @Override
                    public Object getCellEditorValue() {
                        return "Restore";
                    }
                }
        );
}

    private void setupArchivePage() {

    // Correct table columns
  
ArchiveTable.setModel(
        new javax.swing.table.DefaultTableModel(
                new Object[][]{},
                new String[]{
                    "Type",
                    "Record ID",
                    "Name / Description",
                    "Record Date",
                    "Status",
                    "Action"
                }
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 5;
            }
        }
);

Filter.setModel(
        new javax.swing.DefaultComboBoxModel<>(
                new String[]{
                        "FILTER BY: ALL",            
                        "Patients",
                        "Doctors",
                        "Appointments",
                        "Services",
                        "Payments",
                        "Medical Records",
                        "Staff",
                        "User Accounts"
                }
        )
);

    // Correct sort
    Sort.setModel(
            new javax.swing.DefaultComboBoxModel<>(
                    new String[]{
                        "SORT BY: DEFAULT",
                        "Record ID",
                        "Name / Description",
                        "Record Date",
                        "Status"
                    }
            )
    );

    Order.setModel(
            new javax.swing.DefaultComboBoxModel<>(
                    new String[]{
                        "ORDER",
                        "ASCENDING",
                        "DESCENDING"
                    }
            )
    );

    // Search placeholder
    jTextField1.setText(SEARCH_HINT);

  

    jTextField1.addFocusListener(
            new java.awt.event.FocusAdapter() {

        @Override
        public void focusGained(
                java.awt.event.FocusEvent evt) {

            if (jTextField1.getText()
                    .equals(SEARCH_HINT)) {

                jTextField1.setText("");

                jTextField1.setForeground(
                        java.awt.Color.BLACK
                );
            }
        }

   @Override
public void focusLost(
        java.awt.event.FocusEvent evt) {

    if (jTextField1.getText()
            .trim()
            .isEmpty()) {

        jTextField1.setText(
                SEARCH_HINT
        );

        jTextField1.setForeground(
                new java.awt.Color(
                        120,
                        120,
                        120
                )
        );
    }
}
});
}
            private void connectDatabase() {

    try {

        Class.forName(
                "com.mysql.cj.jdbc.Driver"
        );

        conn =
                java.sql.DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/ClinicManagementSystem",
                        "root",
                        ""
                );

        System.out.println(
                "Archive Database Connected!"
        );

    } catch (
            ClassNotFoundException |
            java.sql.SQLException e) {

        javax.swing.JOptionPane.showMessageDialog(
                this,
                "Database Connection Failed!\n"
                + e.getMessage()
        );
    }
}
private void loadArchiveRecords() {

    try {

        if (conn == null || conn.isClosed()) {
            connectDatabase();
        }

        if (conn == null) {
            return;
        }

        String search =
                jTextField1.getText().trim();

        if (search.equals(SEARCH_HINT)) {
            search = "";
        }

        String filter =
                String.valueOf(
                        Filter.getSelectedItem()
                );

        String sort =
                String.valueOf(
                        Sort.getSelectedItem()
                );

        String order =
                String.valueOf(
                        Order.getSelectedItem()
                );

        String baseQuery =
                "SELECT * FROM ("

                // PATIENTS
                + "SELECT "
                + "'Patients' AS type, "
                + "patient_id AS record_id, "
                + "CONCAT(first_name, ' ', last_name) "
                + "AS description, "
                + "DATE(date_added) AS record_date, "
                + "status "
                + "FROM Patients "
                + "WHERE status = 'Archived' "

                + "UNION ALL "

                // DOCTORS
                + "SELECT "
                + "'Doctors' AS type, "
                + "doctor_id AS record_id, "
                + "CONCAT(first_name, ' ', last_name, "
                + "' - ', specialization) AS description, "
                + "DATE(date_added) AS record_date, "
                + "status "
                + "FROM Doctors "
                + "WHERE status = 'Archived' "

                + "UNION ALL "

                // APPOINTMENTS
                + "SELECT "
                + "'Appointments' AS type, "
                + "a.appointment_id AS record_id, "
                + "CONCAT("
                + "p.first_name, ' ', p.last_name"
                + ") AS description, "
                + "a.appointment_date AS record_date, "
                + "a.status "
                + "FROM Appointments a "
                + "LEFT JOIN Patients p "
                + "ON a.patient_id = p.patient_id "
                + "WHERE a.status = 'Archived' "

                + "UNION ALL "
                // PAYMENTS
+ "SELECT "
+ "'Payments' AS type, "
+ "payment_id AS record_id, "
+ "CONCAT('Payment #', payment_id) AS description, "
+ "payment_date AS record_date, "
+ "status "
+ "FROM Payments "
+ "WHERE is_archived = 1 "

+ "UNION ALL "
                
                
                // MEDICAL RECORDS
                + "SELECT "
                + "'Medical Records' AS type, "
                + "record_id AS record_id, "
                + "CONCAT('Patient #', patient_id, "
                + "' - ', diagnosis) AS description, "
                + "record_date AS record_date, "
                + "status "
                + "FROM MedicalRecords "
                + "WHERE status = 'Archived' "

                + "UNION ALL "

                
    // SERVICES
+ "SELECT "
+ "'Services' AS type, "
+ "service_id AS record_id, "
+ "service_name AS description, "
+ "NULL AS record_date, "
+ "status "
+ "FROM Services "
+ "WHERE status = 'Archived' "

+ "UNION ALL "


                // STAFF
                + "SELECT "
                + "'Staff' AS type, "
                + "staff_id AS record_id, "
                + "CONCAT(first_name, ' ', last_name) "
                + "AS description, "
                + "DATE(date_added) AS record_date, "
                + "status "
                + "FROM Staff "
                + "WHERE status IN "
                + "('Inactive', 'Archived') "

                + "UNION ALL "

                // USER ACCOUNTS
                + "SELECT "
                + "'User Accounts' AS type, "
                + "user_id AS record_id, "
                + "username AS description, "
                + "DATE(date_created) AS record_date, "
                + "status "
                + "FROM UserAccount "
                + "WHERE status IN "
                + "('Inactive', 'Disabled', 'Archived') "

                + ") AS archive_data "
                + "WHERE 1 = 1 ";
        

        StringBuilder sql =
                new StringBuilder(baseQuery);

        java.util.ArrayList<String> values =
                new java.util.ArrayList<>();

// ==========================================
// FILTER BY CATEGORY
// ==========================================

if (!filter.equals("FILTER BY: ALL")) {

        sql.append("AND type = ? ");
        values.add(filter);
}

// ==========================================
// SEARCH ARCHIVED RECORDS
// ==========================================

if (!search.isEmpty()) {

        sql.append(
                "AND ("
                + "LOWER(type) LIKE ? "
                + "OR CAST(record_id AS CHAR) LIKE ? "
                + "OR LOWER(description) LIKE ? "
                + "OR LOWER(status) LIKE ? "
                + ") "
        );

        String keyword = "%" + search.toLowerCase() + "%";

        values.add(keyword);
        values.add(keyword);
        values.add(keyword);
        values.add(keyword);
}

// ==========================================
// SORT BY COLUMN
// ==========================================

String sortColumn;

switch (sort) {

        case "Record ID":
                sortColumn = "record_id";
                break;

        case "Name / Description":
                sortColumn = "description";
                break;

        case "Record Date":
                sortColumn = "record_date";
                break;

        case "Status":
                sortColumn = "status";
                break;

        case "SORT BY: DEFAULT":
        default:
                sortColumn = "record_date";
                break;
}

// ==========================================
// ORDER: ASCENDING OR DESCENDING
// ==========================================

String sortOrder;

switch (order) {

        case "ASCENDING":
                sortOrder = "ASC";
                break;

        case "DESCENDING":
                sortOrder = "DESC";
                break;

        case "ORDER":
        default:
                sortOrder = "DESC";
                break;
}

// ==========================================
// APPLY SORTING AND ORDER
// ==========================================

sql.append(
        "ORDER BY "
        + sortColumn
        + " "
        + sortOrder
        + ", type ASC, record_id ASC"
);
        java.sql.PreparedStatement pst =
                conn.prepareStatement(
                        sql.toString()
                );

        for (int i = 0;
                i < values.size();
                i++) {

            pst.setString(
                    i + 1,
                    values.get(i)
            );
        }

        java.sql.ResultSet rs =
                pst.executeQuery();

        javax.swing.table.DefaultTableModel model =
                (javax.swing.table.DefaultTableModel)
                ArchiveTable.getModel();

        model.setRowCount(0);

        while (rs.next()) {

         Object[] row = {
    rs.getString("type"),
    rs.getInt("record_id"),
    rs.getString("description"),
    rs.getDate("record_date"),
    rs.getString("status"),
    "Restore"
};

            model.addRow(row);
        }

        rs.close();
        pst.close();

    } catch (java.sql.SQLException e) {

        javax.swing.JOptionPane.showMessageDialog(
                this,
                "Failed to load archive!\n"
                + e.getMessage()
        );
    }
}
private void searchArchive() {
    loadArchiveRecords();
}

private void sortArchive() {
    loadArchiveRecords();
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        Patients = new javax.swing.JButton();
        Appointments = new javax.swing.JButton();
        MedicalRecords = new javax.swing.JButton();
        Services = new javax.swing.JButton();
        Payments = new javax.swing.JButton();
        Dashboard = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        Staff = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        ArchiveTable = new javax.swing.JTable();
        Doctors = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        Archive = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        Filter = new javax.swing.JComboBox<>();
        Sort = new javax.swing.JComboBox<>();
        Order = new javax.swing.JComboBox<>();
        UserAccounts = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton1.setForeground(new java.awt.Color(204, 0, 0));
        jButton1.setText("Log Out");
        jButton1.setBorderPainted(false);
        jButton1.setContentAreaFilled(false);
        jButton1.setDefaultCapable(false);
        jButton1.setFocusPainted(false);
        jButton1.setFocusable(false);
        jButton1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton1.addActionListener(this::jButton1ActionPerformed);
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 990, 260, 60));

        Patients.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Patients.setForeground(new java.awt.Color(255, 255, 255));
        Patients.setText("Patients");
        Patients.setBorderPainted(false);
        Patients.setContentAreaFilled(false);
        Patients.setDefaultCapable(false);
        Patients.setFocusPainted(false);
        Patients.setFocusable(false);
        Patients.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Patients.addActionListener(this::PatientsActionPerformed);
        getContentPane().add(Patients, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 450, 260, 60));

        Appointments.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Appointments.setForeground(new java.awt.Color(255, 255, 255));
        Appointments.setText("Appointments");
        Appointments.setBorderPainted(false);
        Appointments.setContentAreaFilled(false);
        Appointments.setDefaultCapable(false);
        Appointments.setFocusPainted(false);
        Appointments.setFocusable(false);
        Appointments.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Appointments.addActionListener(this::AppointmentsActionPerformed);
        getContentPane().add(Appointments, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 560, 260, 70));

        MedicalRecords.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        MedicalRecords.setForeground(new java.awt.Color(255, 255, 255));
        MedicalRecords.setText("Medical Records");
        MedicalRecords.setBorderPainted(false);
        MedicalRecords.setContentAreaFilled(false);
        MedicalRecords.setDefaultCapable(false);
        MedicalRecords.setFocusPainted(false);
        MedicalRecords.setFocusable(false);
        MedicalRecords.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        MedicalRecords.addActionListener(this::MedicalRecordsActionPerformed);
        getContentPane().add(MedicalRecords, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 620, 260, 70));

        Services.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Services.setForeground(new java.awt.Color(255, 255, 255));
        Services.setText("Services");
        Services.setBorderPainted(false);
        Services.setContentAreaFilled(false);
        Services.setDefaultCapable(false);
        Services.setFocusPainted(false);
        Services.setFocusable(false);
        Services.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Services.addActionListener(this::ServicesActionPerformed);
        getContentPane().add(Services, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 690, 260, 50));

        Payments.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Payments.setForeground(new java.awt.Color(255, 255, 255));
        Payments.setText("Payments");
        Payments.setBorderPainted(false);
        Payments.setContentAreaFilled(false);
        Payments.setDefaultCapable(false);
        Payments.setFocusPainted(false);
        Payments.setFocusable(false);
        Payments.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Payments.addActionListener(this::PaymentsActionPerformed);
        getContentPane().add(Payments, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 750, 260, 40));

        Dashboard.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Dashboard.setForeground(new java.awt.Color(255, 255, 255));
        Dashboard.setText("Dashboard");
        Dashboard.setBorderPainted(false);
        Dashboard.setContentAreaFilled(false);
        Dashboard.setDefaultCapable(false);
        Dashboard.setFocusPainted(false);
        Dashboard.setFocusable(false);
        Dashboard.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Dashboard.addActionListener(this::DashboardActionPerformed);
        getContentPane().add(Dashboard, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 380, 260, 80));

        jButton11.setFont(new java.awt.Font("Segoe UI", 1, 40)); // NOI18N
        jButton11.setText("Archive");
        jButton11.setBorderPainted(false);
        jButton11.setContentAreaFilled(false);
        jButton11.setDefaultCapable(false);
        jButton11.setFocusPainted(false);
        jButton11.setFocusable(false);
        jButton11.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton11.addActionListener(this::jButton11ActionPerformed);
        getContentPane().add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 40, 360, -1));

        Staff.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Staff.setForeground(new java.awt.Color(255, 255, 255));
        Staff.setText("Staff");
        Staff.setBorderPainted(false);
        Staff.setContentAreaFilled(false);
        Staff.setDefaultCapable(false);
        Staff.setFocusPainted(false);
        Staff.setFocusable(false);
        Staff.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Staff.addActionListener(this::StaffActionPerformed);
        getContentPane().add(Staff, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 800, 260, 40));

        jPanel2.setBackground(new java.awt.Color(222, 246, 236));

        ArchiveTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Type ", "Record ID ", "Username", "Name / Description ", "Date Archived ", "Status "
            }
        ));
        ArchiveTable.setFocusCycleRoot(true);
        ArchiveTable.setGridColor(new java.awt.Color(231, 250, 250));
        ArchiveTable.setShowGrid(true);
        ArchiveTable.setSurrendersFocusOnKeystroke(true);
        jScrollPane1.setViewportView(ArchiveTable);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1494, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 834, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 230, 1500, 840));

        Doctors.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Doctors.setForeground(new java.awt.Color(255, 255, 255));
        Doctors.setText("Doctors");
        Doctors.setBorderPainted(false);
        Doctors.setContentAreaFilled(false);
        Doctors.setDefaultCapable(false);
        Doctors.setFocusPainted(false);
        Doctors.setFocusable(false);
        Doctors.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Doctors.addActionListener(this::DoctorsActionPerformed);
        getContentPane().add(Doctors, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 500, 260, 70));

        jTextField1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jTextField1.setText("Search archived records... ");
        jTextField1.addActionListener(this::jTextField1ActionPerformed);
        getContentPane().add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 160, 720, 50));

        Archive.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Archive.setForeground(new java.awt.Color(0, 102, 51));
        Archive.setText("Archive");
        Archive.setDefaultCapable(false);
        Archive.setFocusPainted(false);
        Archive.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Archive.addActionListener(this::ArchiveActionPerformed);
        getContentPane().add(Archive, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 900, 260, 60));

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-search-47.png"))); // NOI18N
        jButton3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 51)));
        jButton3.setBorderPainted(false);
        jButton3.addActionListener(this::jButton3ActionPerformed);
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 160, -1, -1));

        Filter.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Filter.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "FILTER BY: ALL", "Patients", "Doctors", "Appointments", "Payments", "Medical Records", "Staff", "User Accounts" }));
        Filter.addActionListener(this::FilterActionPerformed);
        getContentPane().add(Filter, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 160, 120, 50));

        Sort.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Sort.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SORT BY: DEFAULT", "Record ID", "Name / Description", "Date Archived", "Status" }));
        Sort.addActionListener(this::SortActionPerformed);
        getContentPane().add(Sort, new org.netbeans.lib.awtextra.AbsoluteConstraints(1310, 160, 100, 50));

        Order.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Order.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ORDER", "ASCENDING", "DESCENDING" }));
        Order.addActionListener(this::OrderActionPerformed);
        getContentPane().add(Order, new org.netbeans.lib.awtextra.AbsoluteConstraints(1420, 160, 100, 50));

        UserAccounts.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        UserAccounts.setForeground(new java.awt.Color(255, 255, 255));
        UserAccounts.setText("User Accounts");
        UserAccounts.setBorderPainted(false);
        UserAccounts.setContentAreaFilled(false);
        UserAccounts.setDefaultCapable(false);
        UserAccounts.setFocusPainted(false);
        UserAccounts.setFocusable(false);
        UserAccounts.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        UserAccounts.addActionListener(this::UserAccountsActionPerformed);
        getContentPane().add(UserAccounts, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 840, 260, 60));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Dashgh.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1930, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        UserSession.logout();
        SignIn logout = new SignIn();
        logout.setVisible(true);
        this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void PatientsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PatientsActionPerformed
        Patients patients = new Patients();
        patients.setVisible(true);
        this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_PatientsActionPerformed

    private void AppointmentsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AppointmentsActionPerformed
        Appointments appointments = new Appointments();
        appointments.setVisible(true);
        this.dispose();          // TODO add your handling code here:
    }//GEN-LAST:event_AppointmentsActionPerformed

    private void MedicalRecordsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MedicalRecordsActionPerformed
        MedicalRecords records = new MedicalRecords();
        records.setVisible(true);
        this.dispose();

        // TODO add your handling code here:
    }//GEN-LAST:event_MedicalRecordsActionPerformed

    private void ServicesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ServicesActionPerformed
        Services services = new Services();
        services.setVisible(true);
        this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_ServicesActionPerformed

    private void PaymentsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PaymentsActionPerformed
        Payments payments = new Payments();
        payments.setVisible(true);
        this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_PaymentsActionPerformed

    private void DashboardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DashboardActionPerformed
        Dashboard dashboard = new Dashboard();
        dashboard.setVisible(true);
        this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_DashboardActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton11ActionPerformed

    private void StaffActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StaffActionPerformed
        Staff staff = new Staff();
        staff.setVisible(true);
        this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_StaffActionPerformed

    private void DoctorsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DoctorsActionPerformed
        Doctors doctors = new Doctors();
        doctors.setVisible(true);
        this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_DoctorsActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        searchArchive();
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void ArchiveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ArchiveActionPerformed

        // TODO add your handling code here:
    }//GEN-LAST:event_ArchiveActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        searchArchive();
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void FilterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FilterActionPerformed
        searchArchive();
        // TODO add your handling code here:
    }//GEN-LAST:event_FilterActionPerformed

    private void SortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SortActionPerformed
        sortArchive();

        // TODO add your handling code here:
    }//GEN-LAST:event_SortActionPerformed

    private void OrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OrderActionPerformed
        sortArchive();
        // TODO add your handling code here:
    }//GEN-LAST:event_OrderActionPerformed

    private void UserAccountsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UserAccountsActionPerformed
        UserAccounts accounts = new UserAccounts();
        accounts.setVisible(true);
        this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_UserAccountsActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Archive().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Appointments;
    private javax.swing.JButton Archive;
    private javax.swing.JTable ArchiveTable;
    private javax.swing.JButton Dashboard;
    private javax.swing.JButton Doctors;
    private javax.swing.JComboBox<String> Filter;
    private javax.swing.JButton MedicalRecords;
    private javax.swing.JComboBox<String> Order;
    private javax.swing.JButton Patients;
    private javax.swing.JButton Payments;
    private javax.swing.JButton Services;
    private javax.swing.JComboBox<String> Sort;
    private javax.swing.JButton Staff;
    private javax.swing.JButton UserAccounts;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
