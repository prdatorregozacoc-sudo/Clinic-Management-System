import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class Staff extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Staff.class.getName());
    private Connection conn;
    private PreparedStatement pst;
    private ResultSet rs;

    private TableRowSorter<DefaultTableModel> sorter;
    private int editingStaffId = -1;
    /**
     * Creates new form Staff
     */
    public Staff() {

    initComponents();
    if (!UserSession.isAdmin()) {

        JOptionPane.showMessageDialog(
                null,
                "Access Denied! Admin only.");

        throw new SecurityException(
                "Only Admin can access Staff.");
}
    getContentPane().setLayout(null);

    setupStaffActions();

    setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);

    designSearchBar();
    designStaffTable();
    designStaffDetailsPanel();

    connectDatabase();
    loadStaff();

    DefaultTableModel model =
            (DefaultTableModel) StaffTable.getModel();

    sorter = new TableRowSorter<>(model);
    StaffTable.setRowSorter(sorter);
    
    Filter.setModel(
        new javax.swing.DefaultComboBoxModel<>(
                new String[]{
                        "FILTER BY: ALL",
                        "Active",
                        "Inactive"
                }
        )
);

    jButton5.addActionListener(
            e -> clearStaffFields()
    );

    jButton6.addActionListener(
            e -> saveStaff()
    );

    // Prevent search field from being selected by default
    getContentPane().setFocusable(true);

    addWindowListener(new java.awt.event.WindowAdapter() {
        @Override
        public void windowOpened(java.awt.event.WindowEvent evt) {
            getContentPane().requestFocusInWindow();
        }
    });
    addComponentListener(new java.awt.event.ComponentAdapter() {
        @Override
        public void componentResized(java.awt.event.ComponentEvent evt) {
                fixStaffLayout();
        }
});

java.awt.EventQueue.invokeLater(() -> fixStaffLayout());
}
private java.awt.Image originalStaffBackground;

private void fixStaffSidebar() {

        int width = getContentPane().getWidth();
        int height = getContentPane().getHeight();

        if (width <= 0 || height <= 0) {
                return;
        }

        double scaleX = width / 1920.0;
        double scaleY = height / 1080.0;
        double fontScale = Math.min(scaleX, scaleY);

        javax.swing.JButton[] buttons = {
                Dashboard,
                Patients,
                Doctors,
                Appointments,
                MedicalRecords,
                Services,
                Payments,
                Staff,
                UserAccounts,
                UserAccounts1,
                jButton1
        };

        // Dashboard reference positions
        int[] positionsY = {
                390, 450, 500, 560, 620,
                690, 750, 800, 830, 890, 990
        };

        int[] heights = {
                60, 60, 70, 70, 70,
                50, 40, 52, 80, 80, 60
        };

        int fontSize = Math.max(
                18,
                (int) Math.round(24 * fontScale)
        );

        for (int i = 0; i < buttons.length; i++) {

                javax.swing.JButton button = buttons[i];

                button.setBounds(
                        (int) (60 * scaleX),
                        (int) (positionsY[i] * scaleY),
                        (int) (260 * scaleX),
                        (int) (heights[i] * scaleY)
                );

                button.setFont(new java.awt.Font(
                        "Segoe UI",
                        java.awt.Font.BOLD,
                        fontSize
                ));

                button.setHorizontalAlignment(
                        javax.swing.SwingConstants.LEFT
                );

                button.setFocusPainted(false);
        }

        // Staff is the active page
        Staff.setForeground(new java.awt.Color(0, 102, 51));
}

private void fixStaffLayout() {

        int width = getContentPane().getWidth();
        int height = getContentPane().getHeight();

        if (width <= 0 || height <= 0) {
                return;
        }

        // =====================================
        // 1. RESPONSIVE BACKGROUND
        // =====================================

        if (originalStaffBackground == null
                && jLabel1.getIcon() instanceof javax.swing.ImageIcon) {

                originalStaffBackground =
                        ((javax.swing.ImageIcon) jLabel1.getIcon()).getImage();
        }

        if (originalStaffBackground != null) {

                java.awt.Image image =
                        originalStaffBackground.getScaledInstance(
                                width,
                                height,
                                java.awt.Image.SCALE_SMOOTH
                        );

                jLabel1.setIcon(new javax.swing.ImageIcon(image));
        }

        jLabel1.setBounds(0, 0, width, height);

        getContentPane().setComponentZOrder(
                jLabel1,
                getContentPane().getComponentCount() - 1
        );

            int sidebarWidth = Math.max(210, (int) (width * 0.205));

        // =====================================
        // 3. MAIN CONTENT AND TITLE
        // =====================================

        int contentX = sidebarWidth + 20;
        int contentWidth = width - contentX - 18;
        

        if (contentWidth <= 0) {
                return;
        }

        jButton11.setBounds(
                contentX,
                40,
                Math.min(360, contentWidth),
                65
        );

        jButton11.setFont(new java.awt.Font(
                "Segoe UI",
                java.awt.Font.BOLD,
                width < 1400 ? 30 : 40
        ));

        // =====================================
        // 4. SEARCH AND FILTER CONTROLS
        // =====================================

        int searchY = Math.max(
        115,
        Math.min(150, height / 5 - 15)
);

 int searchHeight = 42;
int gap = 8;

int iconWidth = 42;
int filterWidth = 160;
int sortWidth = 190;
int orderWidth = 145;

// Search width based on 1920x1080 reference
int searchWidth = (int) (720 * width / 1920.0);

// Total width of search icon and dropdowns
int controlsWidth = iconWidth + filterWidth
        + sortWidth + orderWidth + gap * 4;

// Prevent controls from exceeding available space
searchWidth = Math.max(
        100,
        Math.min(searchWidth, contentWidth - controlsWidth)
);

// SEARCH BAR
jTextField1.setBounds(
        contentX,
        searchY,
        searchWidth,
        searchHeight
);

int nextX = contentX + searchWidth + gap;

// SEARCH ICON
jButton3.setBounds(
        nextX,
        searchY,
        iconWidth,
        searchHeight
);

nextX += iconWidth + gap;

// FILTER
Filter.setBounds(
        nextX,
        searchY,
        filterWidth,
        searchHeight
);

nextX += filterWidth + gap;

// SORT
Sort.setBounds(
        nextX,
        searchY,
        sortWidth,
        searchHeight
);

nextX += sortWidth + gap;

// ORDER
Order.setBounds(
        nextX,
        searchY,
        orderWidth,
        searchHeight
);
        // Resize search icon
        java.net.URL iconURL =
                getClass().getResource(
                        "/images/icons8-search-47.png"
                );

        if (iconURL != null) {

                java.awt.Image searchIcon =
                        new javax.swing.ImageIcon(iconURL)
                                .getImage()
                                .getScaledInstance(
                                        28,
                                        28,
                                        java.awt.Image.SCALE_SMOOTH
                                );

                jButton3.setIcon(
                        new javax.swing.ImageIcon(searchIcon)
                );
        }

        // =====================================
        // 5. TABLE AND STAFF DETAILS
        // =====================================

        int tableY = searchY + searchHeight + 16;

        int detailsHeight = Math.min(
                245,
                Math.max(205, (int) (height * 0.28))
        );

        int detailsY = height - detailsHeight - 12;

        int tableHeight = Math.max(
                120,
                detailsY - tableY - 14
        );

        jPanel2.setBounds(
                contentX,
                tableY,
                contentWidth,
                tableHeight
        );

        jPanel2.setLayout(null);

        jScrollPane1.setBounds(
                0,
                0,
                contentWidth,
                tableHeight
        );

        jPanel1.setBounds(
                contentX,
                detailsY,
                contentWidth,
                detailsHeight
        );

        jPanel1.setLayout(null);

        jPanel1.setBackground(
                new java.awt.Color(222, 246, 236)
        );

        jPanel1.setBorder(
                javax.swing.BorderFactory.createLineBorder(
                        new java.awt.Color(0, 102, 51),
                        2
                )
        );

        // =====================================
        // 6. TABLE COLUMN WIDTHS
        // =====================================

        StaffTable.setAutoResizeMode(
                javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS
        );

        int[] columnWidths = {
                75,   // Staff ID
                110,  // First Name
                110,  // Last Name
                110,  // Position
                125,  // Contact Number
                190,  // Email
                165,  // Date Added
                95,   // Status
                175   // Action
        };

        javax.swing.table.TableColumnModel columns =
                StaffTable.getColumnModel();

        for (int i = 0;
                i < columns.getColumnCount()
                && i < columnWidths.length;
                i++) {

                columns.getColumn(i).setPreferredWidth(
                        columnWidths[i]
                );
        }

        if (columns.getColumnCount() > 8) {

                columns.getColumn(8).setMinWidth(160);
                columns.getColumn(8).setPreferredWidth(175);
        }

        jScrollPane1.setHorizontalScrollBarPolicy(
                javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED
        );

        jScrollPane1.setVerticalScrollBarPolicy(
                javax.swing.JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED
        );

        // =====================================
        // 7. RESPONSIVE STAFF DETAILS PANEL
        // =====================================

        int padding = 20;
        int columnGap = 16;

        int columnWidth =
                (contentWidth - padding * 2 - columnGap * 2) / 3;

        int x1 = padding;
        int x2 = x1 + columnWidth + columnGap;
        int x3 = x2 + columnWidth + columnGap;

        int row1 = 60;
        int row2 = 105;
        int row3 = 150;

        int fieldHeight = 34;

        // Staff Details title
        jLabel2.setBounds(22, 10, 250, 32);

        jLabel2.setFont(new java.awt.Font(
                "Segoe UI",
                java.awt.Font.BOLD,
                18
        ));

        // =====================================
        // COLUMN 1: FIRST NAME, LAST NAME
        // =====================================

        int labelWidth1 = 95;

        jLabel3.setBounds(
                x1, row1, labelWidth1, fieldHeight
        );

        jTextField8.setBounds(
                x1 + labelWidth1,
                row1,
                columnWidth - labelWidth1,
                fieldHeight
        );

        jLabel4.setBounds(
                x1, row2, labelWidth1, fieldHeight
        );

        jTextField7.setBounds(
                x1 + labelWidth1,
                row2,
                columnWidth - labelWidth1,
                fieldHeight
        );

        // =====================================
        // COLUMN 2: POSITION, CONTACT NUMBER
        // =====================================

        int labelWidth2 = 120;

        jLabel5.setBounds(
                x2, row1, labelWidth2, fieldHeight
        );

        jTextField9.setBounds(
                x2 + labelWidth2,
                row1,
                columnWidth - labelWidth2,
                fieldHeight
        );

        jLabel10.setBounds(
                x2, row2, labelWidth2, fieldHeight
        );

        jTextField2.setBounds(
                x2 + labelWidth2,
                row2,
                columnWidth - labelWidth2,
                fieldHeight
        );

        // =====================================
        // COLUMN 3: EMAIL
        // =====================================

        int labelWidth3 = 65;

        jLabel11.setBounds(
                x3, row1, labelWidth3, fieldHeight
        );

        jTextField3.setBounds(
                x3 + labelWidth3,
                row1,
                columnWidth - labelWidth3,
                fieldHeight
        );

        // STATUS LABEL
jLabel12.setBounds(
        x3, row2, labelWidth3, fieldHeight
);

// STATUS COMBO BOX
jComboBox1.setBounds(
        x3 + labelWidth3,
        row2,
        columnWidth - labelWidth3,
        fieldHeight
);
        // =====================================
        // 8. CLEAR AND SAVE BUTTONS
        // =====================================

int actionButtonWidth = 105;
int actionButtonHeight = 35;
int actionButtonGap = 12;

int buttonY = detailsHeight - 48;

int saveX = contentWidth - actionButtonWidth - 22;
int clearX = saveX - actionButtonWidth - actionButtonGap;

jButton5.setBounds(
        clearX, buttonY, actionButtonWidth, actionButtonHeight
);

jButton6.setBounds(
        saveX, buttonY, actionButtonWidth, actionButtonHeight
);

        // =====================================
        // 9. REFRESH LAYOUT
        // =====================================
fixStaffSidebar();
        jPanel2.revalidate();
        jPanel2.repaint();

        jPanel1.revalidate();
        jPanel1.repaint();

        getContentPane().revalidate();
        getContentPane().repaint();
}
private void setupStaffActions() {

        DefaultTableModel model = new DefaultTableModel(
                new Object[][]{},
                new String[]{
                        "Staff ID", "First Name", "Last Name",
                        "Position", "Contact Number", "Email",
                        "Date Added", "Status", "Action"
                }
        ) {
                @Override
                public boolean isCellEditable(int row, int column) {
                        return column == 8;
                }
        };

        StaffTable.setModel(model);

        javax.swing.table.TableColumn action =
                StaffTable.getColumnModel().getColumn(8);

        action.setCellRenderer(new StaffActionRenderer());
        action.setCellEditor(new StaffActionEditor());
        action.setPreferredWidth(170);
        action.setMinWidth(150);
}

private void styleStaffButton(
        javax.swing.JButton button,
        java.awt.Color color) {

        button.setForeground(java.awt.Color.WHITE);
        button.setFont(new java.awt.Font(
                "Segoe UI", java.awt.Font.BOLD, 11));

        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setContentAreaFilled(false);
        button.setOpaque(false);
        button.setMargin(new java.awt.Insets(0, 0, 0, 0));

        button.setPreferredSize(new java.awt.Dimension(
                button.getText().equals("Edit") ? 58 : 78, 26));

        button.setUI(new javax.swing.plaf.basic.BasicButtonUI() {
                @Override
                public void paint(
                        java.awt.Graphics g,
                        javax.swing.JComponent c) {

                        java.awt.Graphics2D g2 =
                                (java.awt.Graphics2D) g.create();

                        g2.setRenderingHint(
                                java.awt.RenderingHints.KEY_ANTIALIASING,
                                java.awt.RenderingHints.VALUE_ANTIALIAS_ON);

                        java.awt.Color top;
                        java.awt.Color bottom;

                        if (button.getText().equals("Edit")) {
                                top = new java.awt.Color(35, 175, 105);
                                bottom = new java.awt.Color(0, 125, 65);
                        } else {
                                top = new java.awt.Color(255, 100, 100);
                                bottom = new java.awt.Color(210, 40, 40);
                        }

                        g2.setPaint(new java.awt.GradientPaint(
                                0, 0, top,
                                0, c.getHeight(), bottom));

                        g2.fillRoundRect(
                                0, 0,
                                c.getWidth() - 1,
                                c.getHeight() - 1,
                                8, 8);

                        g2.dispose();
                        super.paint(g, c);
                }
        });
}

private class StaffActionRenderer extends javax.swing.JPanel
        implements javax.swing.table.TableCellRenderer {

        private final javax.swing.JButton edit =
                new javax.swing.JButton("Edit");

        private final javax.swing.JButton remove =
                new javax.swing.JButton("Remove");

        StaffActionRenderer() {

                setLayout(new java.awt.FlowLayout(
                        java.awt.FlowLayout.CENTER, 8, 5));

                setOpaque(false);

                styleStaffButton(edit, new java.awt.Color(0, 102, 51));
                styleStaffButton(remove, new java.awt.Color(190, 40, 40));

                add(edit);
                add(remove);
        }

        @Override
        public java.awt.Component getTableCellRendererComponent(
                javax.swing.JTable table, Object value,
                boolean selected, boolean focus,
                int row, int column) {

                return this;
        }
}

private class StaffActionEditor
        extends javax.swing.AbstractCellEditor
        implements javax.swing.table.TableCellEditor {

        private final javax.swing.JPanel panel =
                new javax.swing.JPanel(new java.awt.FlowLayout(
                        java.awt.FlowLayout.CENTER, 8, 5));

        private final javax.swing.JButton edit =
                new javax.swing.JButton("Edit");

        private final javax.swing.JButton remove =
                new javax.swing.JButton("Remove");

        private int selectedRow;

        StaffActionEditor() {

                panel.setOpaque(false);

                styleStaffButton(edit, new java.awt.Color(0, 102, 51));
                styleStaffButton(remove, new java.awt.Color(190, 40, 40));

                panel.add(edit);
                panel.add(remove);

                // WORKING EDIT BUTTON
                edit.addActionListener(e -> {
                        int row = selectedRow;
                        fireEditingStopped();
                        editStaff(row);
                });

                // WORKING REMOVE BUTTON
                remove.addActionListener(e -> {
                        int row = selectedRow;
                        fireEditingStopped();
                        removeStaff(row);
                });
        }

        @Override
        public java.awt.Component getTableCellEditorComponent(
                javax.swing.JTable table, Object value,
                boolean selected, int row, int column) {

                selectedRow = row;
                return panel;
        }

        @Override
        public Object getCellEditorValue() {
                return "";
        }
}

private void editStaff(int row) {

        if (row < 0 || row >= StaffTable.getRowCount()) {
                return;
        }

        int modelRow = StaffTable.convertRowIndexToModel(row);
        javax.swing.table.TableModel model = StaffTable.getModel();

        editingStaffId = Integer.parseInt(
                model.getValueAt(modelRow, 0).toString());

        jTextField8.setText(
                String.valueOf(model.getValueAt(modelRow, 1)));

        jTextField7.setText(
                String.valueOf(model.getValueAt(modelRow, 2)));

        jTextField9.setText(
                String.valueOf(model.getValueAt(modelRow, 3)));

        Object contact = model.getValueAt(modelRow, 4);
        jTextField2.setText(
                contact == null ? "" : contact.toString());

        Object email = model.getValueAt(modelRow, 5);
        jTextField3.setText(
                email == null ? "" : email.toString());
Object status = model.getValueAt(modelRow, 7);

jComboBox1.setSelectedItem(
        status == null ? "Active" : status.toString()
);
        jButton6.setText("Update");
}

private void removeStaff(int row) {

        if (row < 0 || row >= StaffTable.getRowCount()) {
                return;
        }

        int modelRow = StaffTable.convertRowIndexToModel(row);

        int staffId = Integer.parseInt(
                StaffTable.getModel()
                        .getValueAt(modelRow, 0).toString());

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Move this staff member to Archive?",
                "Confirm Remove",
                JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION) {
                return;
        }

        if (conn == null) {
                JOptionPane.showMessageDialog(
                        this, "Database is not connected.");
                return;
        }

        String sql = "UPDATE Staff SET status = 'Archived' "
                + "WHERE staff_id = ? AND status <> 'Archived'";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setInt(1, staffId);

                if (ps.executeUpdate() > 0) {
                        JOptionPane.showMessageDialog(
                                this, "Staff archived successfully!");

                        clearStaffFields();
                        loadStaff();
                } else {
                        JOptionPane.showMessageDialog(
                                this, "Staff member not found.");
                }

        } catch (SQLException ex) {
                JOptionPane.showMessageDialog(
                        this,
                        "Failed to archive staff:\n"
                        + ex.getMessage());
        }
}


          private void connectDatabase() {

        try {

            Class.forName(
                    "com.mysql.cj.jdbc.Driver"
            );

            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/ClinicManagementSystem",
                    "root",
                    ""
            );

            System.out.println(
                    "Staff Database Connected!"
            );

        } catch (ClassNotFoundException | SQLException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Database Connection Failed!\n"
                    + e.getMessage()
            );
        }
    }
              private void loadStaff() {

        if (conn == null) {
            return;
        }

        DefaultTableModel model =
                (DefaultTableModel) StaffTable.getModel();

        model.setRowCount(0);

  String sql =
        "SELECT staff_id, first_name, last_name, "
        + "position, contact_number, email, "
        + "date_added, status "
        + "FROM Staff "
        + "WHERE status <> 'Archived' "
        + "ORDER BY staff_id ASC";
        try {

            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();

            while (rs.next()) {

                Object[] row = {
                    rs.getInt("staff_id"),
                    rs.getString("first_name"),
                    rs.getString("last_name"),
                    rs.getString("position"),
                    rs.getString("contact_number"),
                    rs.getString("email"),
                    rs.getTimestamp("date_added"),
                    rs.getString("status"),
""
                };

                model.addRow(row);
            }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Failed to load staff!\n"
                    + e.getMessage()
            );
        }
    }
 

private void saveStaff() {

        String firstName = jTextField8.getText().trim();
        String lastName = jTextField7.getText().trim();
        String position = jTextField9.getText().trim();
        String contact = jTextField2.getText().trim();
        String email = jTextField3.getText().trim();

        String status = jComboBox1.getSelectedItem().toString();

        if (firstName.isEmpty() || lastName.isEmpty()
                || position.isEmpty()) {

                JOptionPane.showMessageDialog(
                        this,
                        "Please enter First Name, Last Name, and Position.");
                return;
        }

        if (conn == null) {
                JOptionPane.showMessageDialog(
                        this, "Database is not connected.");
                return;
        }

        boolean editing = editingStaffId != -1;

        String sql;

        if (editing) {
                sql = "UPDATE Staff SET first_name = ?, "
                        + "last_name = ?, position = ?, "
                        + "contact_number = ?, email = ?, status = ? "
                        + "WHERE staff_id = ? AND status <> 'Archived'";
        } else {
                sql = "INSERT INTO Staff "
                        + "(first_name, last_name, position, "
                        + "contact_number, email, status) "
                        + "VALUES (?, ?, ?, ?, ?, ?)";
        }

        try (PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setString(1, firstName);
                ps.setString(2, lastName);
                ps.setString(3, position);
                ps.setString(4, contact);
                ps.setString(5, email);
                ps.setString(6, status);

                if (editing) {
                        ps.setInt(7, editingStaffId);
                }

                int affected = ps.executeUpdate();

                if (affected > 0) {
                        JOptionPane.showMessageDialog(
                                this,
                                editing
                                        ? "Staff updated successfully!"
                                        : "Staff added successfully!");

                        clearStaffFields();
                        loadStaff();

                } else {
                        JOptionPane.showMessageDialog(
                                this, "Staff record was not updated.");
                }

        } catch (SQLException ex) {
                JOptionPane.showMessageDialog(
                        this,
                        "Failed to save staff:\n" + ex.getMessage());
        }
}

                      private void clearStaffFields() {

        jTextField8.setText("");
        jTextField7.setText("");
        jTextField9.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jComboBox1.setSelectedItem("Active");

        StaffTable.clearSelection();

        jTextField8.requestFocusInWindow();
        editingStaffId = -1;
jButton6.setText("Save");
    }
                      
private void designSearchBar() {

    String placeholder = "Search staff by name or position...";

    jTextField1.setFont(
            new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 16)
    );

    jTextField1.setForeground(
            new java.awt.Color(130, 130, 130)
    );

    jTextField1.setText(placeholder);

    jTextField1.addFocusListener(
            new java.awt.event.FocusAdapter() {

                @Override
                public void focusGained(
                        java.awt.event.FocusEvent evt) {

                    if (jTextField1.getText().equals(placeholder)) {
                        jTextField1.setText("");
                        jTextField1.setForeground(
                                new java.awt.Color(40, 40, 40)
                        );
                    }
                }

                @Override
                public void focusLost(
                        java.awt.event.FocusEvent evt) {

                    if (jTextField1.getText().trim().isEmpty()) {
                        jTextField1.setText(placeholder);
                        jTextField1.setForeground(
                                new java.awt.Color(130, 130, 130)
                        );
                    }
                }
            }
    );
}

private void designStaffDetailsPanel() {

    jPanel1.setBackground(
            new java.awt.Color(222, 246, 236)
    );

    jPanel1.setBorder(
            javax.swing.BorderFactory.createLineBorder(
                    new java.awt.Color(0, 102, 51),
                    2
            )
    );

    jPanel1.revalidate();
    jPanel1.repaint();
}



private void designStaffTable() {

        // TABLE APPEARANCE
        StaffTable.setFont(
                new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 14)
        );

        StaffTable.setRowHeight(38);
        StaffTable.setBackground(java.awt.Color.WHITE);
        StaffTable.setForeground(new java.awt.Color(40, 40, 40));

        StaffTable.setSelectionBackground(
                new java.awt.Color(222, 246, 236)
        );

        StaffTable.setSelectionForeground(
                new java.awt.Color(0, 102, 51)
        );

        StaffTable.setGridColor(
                new java.awt.Color(220, 235, 228)
        );

        StaffTable.setShowHorizontalLines(true);
        StaffTable.setShowVerticalLines(false);

        StaffTable.setIntercellSpacing(
                new java.awt.Dimension(0, 1)
        );

        // GREEN HEADER
        javax.swing.table.JTableHeader header =
                StaffTable.getTableHeader();

        header.setPreferredSize(
                new java.awt.Dimension(
                        header.getPreferredSize().width, 38
                )
        );

        header.setReorderingAllowed(false);

        javax.swing.table.DefaultTableCellRenderer headerRenderer =
                new javax.swing.table.DefaultTableCellRenderer();

        headerRenderer.setBackground(
                new java.awt.Color(0, 102, 51)
        );

        headerRenderer.setForeground(java.awt.Color.WHITE);

        headerRenderer.setFont(
                new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 14)
        );

        headerRenderer.setHorizontalAlignment(
                javax.swing.SwingConstants.CENTER
        );

        headerRenderer.setOpaque(true);

        // GREEN HEADER FOR ALL 9 COLUMNS
        for (int i = 0; i < StaffTable.getColumnCount(); i++) {

                StaffTable.getColumnModel()
                        .getColumn(i)
                        .setHeaderRenderer(headerRenderer);
        }

        // CENTER TABLE CONTENT EXCEPT ACTION
        javax.swing.table.DefaultTableCellRenderer center =
                new javax.swing.table.DefaultTableCellRenderer();

        center.setHorizontalAlignment(
                javax.swing.SwingConstants.CENTER
        );

        for (int i = 0;
                i < StaffTable.getColumnCount() - 1;
                i++) {

                StaffTable.getColumnModel()
                        .getColumn(i)
                        .setCellRenderer(center);
        }

        // ALWAYS-VISIBLE EDIT AND REMOVE BUTTONS
        javax.swing.table.TableColumn action =
                StaffTable.getColumnModel().getColumn(8);

        action.setCellRenderer(new StaffActionRenderer());
        action.setCellEditor(new StaffActionEditor());

        action.setPreferredWidth(170);
        action.setMinWidth(150);

        StaffTable.setAutoResizeMode(
                javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS
        );

        jScrollPane1.getViewport().setBackground(
                java.awt.Color.WHITE
        );

        header.repaint();
        StaffTable.repaint();
}




private void searchStaff() {

        if (sorter == null) {
                return;
        }

        String searchText = jTextField1.getText().trim();

        if (searchText.equalsIgnoreCase(
                "Search staff by name or position...")) {
                searchText = "";
        }

        String selectedFilter =
                Filter.getSelectedItem() == null
                ? "FILTER BY: ALL"
                : Filter.getSelectedItem().toString().trim();

        java.util.List<
                javax.swing.RowFilter<DefaultTableModel, Integer>>
                filters = new java.util.ArrayList<>();

        // FILTER BY STAFF STATUS
        if (selectedFilter.equalsIgnoreCase("Active")
                || selectedFilter.equalsIgnoreCase("Inactive")) {

                filters.add(
                        javax.swing.RowFilter.regexFilter(
                                "(?i)^"
                                + java.util.regex.Pattern.quote(selectedFilter)
                                + "$",
                                7
                        )
                );
        }

        // SEARCH STAFF INFORMATION
        if (!searchText.isEmpty()) {

                String pattern = "(?i)"
                        + java.util.regex.Pattern.quote(searchText);

                filters.add(
                        javax.swing.RowFilter.regexFilter(
                                pattern,
                                0, 1, 2, 3, 4, 5
                        )
                );
        }

        // APPLY FILTER AND SEARCH
        if (filters.isEmpty()) {

                sorter.setRowFilter(null);

        } else {

                sorter.setRowFilter(
                        javax.swing.RowFilter.andFilter(filters)
                );
        }
}

private void sortStaff() {

    if (sorter == null) {
        return;
    }

    String selectedSort =
            Sort.getSelectedItem().toString();

    String selectedOrder =
            Order.getSelectedItem().toString();

    int column;

    switch (selectedSort) {

        case "Staff ID":
            column = 0;
            break;

        case "First Name":
            column = 1;
            break;

        case "Last Name":
            column = 2;
            break;

        case "Date Added":
            column = 6;
            break;

        default:
            sorter.setSortKeys(null);
            return;
    }

    javax.swing.SortOrder direction =
            javax.swing.SortOrder.ASCENDING;

    if ("DESCENDING".equals(selectedOrder)) {
        direction = javax.swing.SortOrder.DESCENDING;
    }

    java.util.List<javax.swing.RowSorter.SortKey> sortKeys =
            new java.util.ArrayList<>();

    sortKeys.add(
            new javax.swing.RowSorter.SortKey(
                    column,
                    direction
            )
    );

    sorter.setSortKeys(sortKeys);
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        Patients = new javax.swing.JButton();
        Appointments = new javax.swing.JButton();
        MedicalRecords = new javax.swing.JButton();
        Services = new javax.swing.JButton();
        Payments = new javax.swing.JButton();
        Dashboard = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        UserAccounts = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        StaffTable = new javax.swing.JTable();
        Doctors = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        Staff = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jTextField9 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        Filter = new javax.swing.JComboBox<>();
        Order = new javax.swing.JComboBox<>();
        Sort = new javax.swing.JComboBox<>();
        UserAccounts1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton1.setForeground(new java.awt.Color(204, 0, 0));
        jButton1.setText("Log Out");
        jButton1.setBorderPainted(false);
        jButton1.setContentAreaFilled(false);
        jButton1.setDefaultCapable(false);
        jButton1.setFocusPainted(false);
        jButton1.setFocusable(false);
        jButton1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton1.addActionListener(this::jButton1ActionPerformed);
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 990, 260, 60));

        Patients.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Patients.setForeground(new java.awt.Color(255, 255, 255));
        Patients.setText("Patients");
        Patients.setBorderPainted(false);
        Patients.setContentAreaFilled(false);
        Patients.setDefaultCapable(false);
        Patients.setFocusPainted(false);
        Patients.setFocusable(false);
        Patients.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Patients.addActionListener(this::PatientsActionPerformed);
        getContentPane().add(Patients, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 450, 260, 60));

        Appointments.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Appointments.setForeground(new java.awt.Color(255, 255, 255));
        Appointments.setText("Appointments");
        Appointments.setBorderPainted(false);
        Appointments.setContentAreaFilled(false);
        Appointments.setDefaultCapable(false);
        Appointments.setFocusPainted(false);
        Appointments.setFocusable(false);
        Appointments.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Appointments.addActionListener(this::AppointmentsActionPerformed);
        getContentPane().add(Appointments, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 560, 260, 70));

        MedicalRecords.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        MedicalRecords.setForeground(new java.awt.Color(255, 255, 255));
        MedicalRecords.setText("Medical Records");
        MedicalRecords.setBorderPainted(false);
        MedicalRecords.setContentAreaFilled(false);
        MedicalRecords.setDefaultCapable(false);
        MedicalRecords.setFocusPainted(false);
        MedicalRecords.setFocusable(false);
        MedicalRecords.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        MedicalRecords.addActionListener(this::MedicalRecordsActionPerformed);
        getContentPane().add(MedicalRecords, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 620, 260, 70));

        Services.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Services.setForeground(new java.awt.Color(255, 255, 255));
        Services.setText("Services");
        Services.setBorderPainted(false);
        Services.setContentAreaFilled(false);
        Services.setDefaultCapable(false);
        Services.setFocusPainted(false);
        Services.setFocusable(false);
        Services.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Services.addActionListener(this::ServicesActionPerformed);
        getContentPane().add(Services, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 690, 260, 50));

        Payments.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Payments.setForeground(new java.awt.Color(255, 255, 255));
        Payments.setText("Payments");
        Payments.setBorderPainted(false);
        Payments.setContentAreaFilled(false);
        Payments.setDefaultCapable(false);
        Payments.setFocusPainted(false);
        Payments.setFocusable(false);
        Payments.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Payments.addActionListener(this::PaymentsActionPerformed);
        getContentPane().add(Payments, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 750, 260, 40));

        Dashboard.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Dashboard.setForeground(new java.awt.Color(255, 255, 255));
        Dashboard.setText("Dashboard");
        Dashboard.setBorderPainted(false);
        Dashboard.setContentAreaFilled(false);
        Dashboard.setDefaultCapable(false);
        Dashboard.setFocusPainted(false);
        Dashboard.setFocusable(false);
        Dashboard.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Dashboard.addActionListener(this::DashboardActionPerformed);
        getContentPane().add(Dashboard, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 380, 260, 80));

        jButton11.setFont(new java.awt.Font("Segoe UI", 1, 40)); // NOI18N
        jButton11.setText("Staff");
        jButton11.setBorderPainted(false);
        jButton11.setContentAreaFilled(false);
        jButton11.setDefaultCapable(false);
        jButton11.setFocusPainted(false);
        jButton11.setFocusable(false);
        jButton11.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton11.addActionListener(this::jButton11ActionPerformed);
        getContentPane().add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 40, 360, -1));

        UserAccounts.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        UserAccounts.setForeground(new java.awt.Color(255, 255, 255));
        UserAccounts.setText("User Accounts");
        UserAccounts.setBorderPainted(false);
        UserAccounts.setContentAreaFilled(false);
        UserAccounts.setDefaultCapable(false);
        UserAccounts.setFocusPainted(false);
        UserAccounts.setFocusable(false);
        UserAccounts.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        UserAccounts.addActionListener(this::UserAccountsActionPerformed);
        getContentPane().add(UserAccounts, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 830, 260, 80));

        jPanel2.setBackground(new java.awt.Color(222, 246, 236));

        StaffTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Staff ID", "First Name", "Last Name", "Position", "Contact Number", "Email"
            }
        ));
        StaffTable.setFocusCycleRoot(true);
        StaffTable.setGridColor(new java.awt.Color(231, 250, 250));
        StaffTable.setShowGrid(true);
        StaffTable.setSurrendersFocusOnKeystroke(true);
        jScrollPane1.setViewportView(StaffTable);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1474, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 514, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 230, 1480, 520));

        Doctors.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Doctors.setForeground(new java.awt.Color(255, 255, 255));
        Doctors.setText("Doctors");
        Doctors.setBorderPainted(false);
        Doctors.setContentAreaFilled(false);
        Doctors.setDefaultCapable(false);
        Doctors.setFocusPainted(false);
        Doctors.setFocusable(false);
        Doctors.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Doctors.addActionListener(this::DoctorsActionPerformed);
        getContentPane().add(Doctors, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 500, 260, 70));

        jTextField1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jTextField1.setText("Search staff by name or position..");
        jTextField1.addActionListener(this::jTextField1ActionPerformed);
        getContentPane().add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 160, 720, 50));

        Staff.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Staff.setForeground(new java.awt.Color(0, 102, 51));
        Staff.setText("Staff");
        Staff.setDefaultCapable(false);
        Staff.setFocusPainted(false);
        Staff.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Staff.addActionListener(this::StaffActionPerformed);
        getContentPane().add(Staff, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 800, 260, 40));

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-search-47.png"))); // NOI18N
        jButton3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 51)));
        jButton3.setBorderPainted(false);
        jButton3.addActionListener(this::jButton3ActionPerformed);
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 160, -1, -1));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 102, 51));
        jLabel2.setText("Staff Details");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("First Name");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Last Name");

        jButton5.setBackground(new java.awt.Color(240, 250, 244));
        jButton5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton5.setForeground(new java.awt.Color(0, 102, 51));
        jButton5.setText("Clear");

        jButton6.setBackground(new java.awt.Color(0, 102, 51));
        jButton6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.setText("Save");

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel10.setText("Contact Number");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setText("Position");

        jLabel11.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel11.setText("Email");

        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel12.setText("Status");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Active", "Inactive" }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jLabel2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jButton5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton6))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(jLabel5)
                                                .addGap(43, 43, 43)
                                                .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(jLabel4)
                                                .addGap(27, 27, 27)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jTextField7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel10)
                                    .addComponent(jLabel11)
                                    .addComponent(jLabel12))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jTextField3, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
                                    .addComponent(jTextField2)
                                    .addComponent(jComboBox1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addGap(8, 8, 8)))
                .addGap(688, 688, 688))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(jLabel3))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel10))
                            .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addGap(44, 44, 44))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel4))
                            .addComponent(jTextField3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel5)
                                .addComponent(jLabel12)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 780, 1470, 210));

        Filter.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Filter.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "FILTER BY: ALL", "Active", "Inactive", " " }));
        Filter.addActionListener(this::FilterActionPerformed);
        getContentPane().add(Filter, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 160, 120, 50));

        Order.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Order.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ORDER", "ASCENDING", "DESCENDING" }));
        Order.addActionListener(this::OrderActionPerformed);
        getContentPane().add(Order, new org.netbeans.lib.awtextra.AbsoluteConstraints(1420, 160, 100, 50));

        Sort.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Sort.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SORT BY: DEFAULT", "Staff ID", "First Name", "Last Name", "Date Added" }));
        Sort.addActionListener(this::SortActionPerformed);
        getContentPane().add(Sort, new org.netbeans.lib.awtextra.AbsoluteConstraints(1310, 160, 100, 50));

        UserAccounts1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        UserAccounts1.setForeground(new java.awt.Color(255, 255, 255));
        UserAccounts1.setText("Archive");
        UserAccounts1.setBorderPainted(false);
        UserAccounts1.setContentAreaFilled(false);
        UserAccounts1.setDefaultCapable(false);
        UserAccounts1.setFocusPainted(false);
        UserAccounts1.setFocusable(false);
        UserAccounts1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        UserAccounts1.addActionListener(this::UserAccounts1ActionPerformed);
        getContentPane().add(UserAccounts1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 890, 260, 80));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Dashgh.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1930, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void PatientsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PatientsActionPerformed
    Patients patients = new Patients();
    patients.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_PatientsActionPerformed

    private void AppointmentsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AppointmentsActionPerformed
    Appointments appointments = new Appointments();
    appointments.setVisible(true);
    this.dispose();          // TODO add your handling code here:
    }//GEN-LAST:event_AppointmentsActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton11ActionPerformed

    private void DoctorsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DoctorsActionPerformed
    Doctors doctors = new Doctors();
    doctors.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_DoctorsActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
           searchStaff();
 // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
            searchStaff();
// TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void PaymentsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PaymentsActionPerformed
    Payments payments = new Payments();
    payments.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_PaymentsActionPerformed

    private void DashboardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DashboardActionPerformed
    Dashboard dashboard = new Dashboard();
    dashboard.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_DashboardActionPerformed

    private void MedicalRecordsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MedicalRecordsActionPerformed
    MedicalRecords records = new MedicalRecords();
    records.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_MedicalRecordsActionPerformed

    private void ServicesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ServicesActionPerformed
    Services services = new Services();
    services.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_ServicesActionPerformed

    private void StaffActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StaffActionPerformed
    Staff staff = new Staff();
    staff.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_StaffActionPerformed

    private void UserAccountsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UserAccountsActionPerformed
    UserAccounts accounts = new UserAccounts();
    accounts.setVisible(true);
    this.dispose();
        // TODO add your handling code here:
    }//GEN-LAST:event_UserAccountsActionPerformed

    private void FilterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FilterActionPerformed
        searchStaff();
        // TODO add your handling code here:
    }//GEN-LAST:event_FilterActionPerformed

    private void SortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SortActionPerformed
        sortStaff();

        // TODO add your handling code here:
    }//GEN-LAST:event_SortActionPerformed

    private void OrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OrderActionPerformed
        sortStaff();
        // TODO add your handling code here:
    }//GEN-LAST:event_OrderActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    UserSession.logout();
    SignIn logout = new SignIn();
    logout.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void UserAccounts1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UserAccounts1ActionPerformed
        Archive archive = new Archive();
        archive.setVisible(true);
        this.dispose();       // TODO add your handling code here:
    }//GEN-LAST:event_UserAccounts1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Staff().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Appointments;
    private javax.swing.JButton Dashboard;
    private javax.swing.JButton Doctors;
    private javax.swing.JComboBox<String> Filter;
    private javax.swing.JButton MedicalRecords;
    private javax.swing.JComboBox<String> Order;
    private javax.swing.JButton Patients;
    private javax.swing.JButton Payments;
    private javax.swing.JButton Services;
    private javax.swing.JComboBox<String> Sort;
    private javax.swing.JButton Staff;
    private javax.swing.JTable StaffTable;
    private javax.swing.JButton UserAccounts;
    private javax.swing.JButton UserAccounts1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    // End of variables declaration//GEN-END:variables
}
