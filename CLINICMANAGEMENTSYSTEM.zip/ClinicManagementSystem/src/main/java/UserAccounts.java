import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class UserAccounts extends javax.swing.JFrame {
        private Connection conn;
    private PreparedStatement pst;
    private ResultSet rs;

    private TableRowSorter<DefaultTableModel> sorter;
    private int editingUserId = -1;
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(UserAccounts.class.getName());


private void searchUserAccounts() {

        if (sorter == null) {
                return;
        }

        String searchText = jTextField1.getText().trim();

        if (searchText.equalsIgnoreCase(
                "Search by username or staff name...")) {
                searchText = "";
        }

        String selectedFilter = Filter.getSelectedItem() == null
                ? "FILTER BY: ALL"
                : Filter.getSelectedItem().toString().trim();

        java.util.List<javax.swing.RowFilter<DefaultTableModel, Integer>>
                filters = new java.util.ArrayList<>();

        // FILTER BY STATUS
        if (selectedFilter.equalsIgnoreCase("Active")
                || selectedFilter.equalsIgnoreCase("Inactive")) {

                filters.add(
                        javax.swing.RowFilter.regexFilter(
                                "(?i)^"
                                + java.util.regex.Pattern.quote(selectedFilter)
                                + "$",
                                5
                        )
                );
        }

        // SEARCH USER ACCOUNTS
        if (!searchText.isEmpty()) {

                String safeText =
                        java.util.regex.Pattern.quote(searchText);

                filters.add(
        javax.swing.RowFilter.regexFilter(
                "(?i)" + safeText,
                0, 1, 2, 4, 5, 6
        )
);
        }

        // APPLY FILTERS
        if (filters.isEmpty()) {
                sorter.setRowFilter(null);
        } else {
                sorter.setRowFilter(
                        javax.swing.RowFilter.andFilter(filters)
                );
        }
}
 
private void sortUserAccounts() {

        if (sorter == null) {
                return;
        }

        String selectedSort =
                Sort.getSelectedItem().toString();

        String selectedOrder =
                Order.getSelectedItem().toString();

        int column;

        switch (selectedSort) {

                case "User ID":
                        column = 0;
                        break;

                case "Staff ID":
                        column = 1;
                        break;

                case "Username":
                        column = 2;
                        break;

case "Role":
        column = 4;
        break;

case "Date Created":
        column = 6;
        break;
                default:
                        sorter.setSortKeys(null);
                        return;
        }

        javax.swing.SortOrder direction =
                javax.swing.SortOrder.ASCENDING;

        if ("DESCENDING".equalsIgnoreCase(selectedOrder)) {
                direction = javax.swing.SortOrder.DESCENDING;
        }

        java.util.List<javax.swing.RowSorter.SortKey> sortKeys =
                new java.util.ArrayList<>();

        sortKeys.add(
                new javax.swing.RowSorter.SortKey(
                        column,
                        direction
                )
        );

        sorter.setSortKeys(sortKeys);
}

private void designSearchBar() {
    String placeholder = "Search by username or staff name...";

    jTextField1.setFont(
            new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 16)
    );

    jTextField1.setForeground(
            new java.awt.Color(130, 130, 130)
    );

    jTextField1.setText(placeholder);

    jTextField1.addFocusListener(
            new java.awt.event.FocusAdapter() {

                @Override
                public void focusGained(java.awt.event.FocusEvent evt) {
                    if (jTextField1.getText().equals(placeholder)) {
                        jTextField1.setText("");
                        jTextField1.setForeground(
                                new java.awt.Color(40, 40, 40)
                        );
                    }
                }

                @Override
                public void focusLost(java.awt.event.FocusEvent evt) {
                    if (jTextField1.getText().trim().isEmpty()) {
                        jTextField1.setText(placeholder);
                        jTextField1.setForeground(
                                new java.awt.Color(130, 130, 130)
                        );
                    }
                }
            }
    );
}

private void designAccountDetailsPanel() {
    jPanel1.setBackground(
            new java.awt.Color(222, 246, 236)
    );

    jPanel1.setBorder(
            javax.swing.BorderFactory.createLineBorder(
                    new java.awt.Color(0, 102, 51), 2
            )
    );

    jPanel1.revalidate();
    jPanel1.repaint();
}

private void fixUserAccountsHeader() {

    javax.swing.table.JTableHeader header =
            UserAccountsTable.getTableHeader();

    header.setDefaultRenderer(
            new javax.swing.table.DefaultTableCellRenderer() {

                @Override
                public java.awt.Component getTableCellRendererComponent(
                        javax.swing.JTable table,
                        Object value,
                        boolean isSelected,
                        boolean hasFocus,
                        int row,
                        int column) {

                    javax.swing.JLabel label =
                            (javax.swing.JLabel) super
                                    .getTableCellRendererComponent(
                                            table, value, isSelected,
                                            hasFocus, row, column
                                    );

                    label.setBackground(
                            new java.awt.Color(0, 102, 51)
                    );

                    label.setForeground(java.awt.Color.WHITE);
                    label.setOpaque(true);

                    label.setFont(
                            new java.awt.Font(
                                    "Segoe UI",
                                    java.awt.Font.BOLD,
                                    14
                            )
                    );

                    label.setHorizontalAlignment(
                            javax.swing.SwingConstants.CENTER
                    );

                    return label;
                }
            }
    );

    header.setPreferredSize(
            new java.awt.Dimension(
                    header.getPreferredSize().width, 38
            )
    );

    header.repaint();
}


private void designUserAccountsTable() {

        UserAccountsTable.setFont(
                new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 14)
        );

        UserAccountsTable.setRowHeight(38);
        UserAccountsTable.setBackground(java.awt.Color.WHITE);
        UserAccountsTable.setForeground(
                new java.awt.Color(40, 40, 40)
        );

        UserAccountsTable.setSelectionBackground(
                new java.awt.Color(222, 246, 236)
        );

        UserAccountsTable.setSelectionForeground(
                new java.awt.Color(0, 102, 51)
        );

        UserAccountsTable.setGridColor(
                new java.awt.Color(220, 235, 228)
        );

        UserAccountsTable.setShowHorizontalLines(true);
        UserAccountsTable.setShowVerticalLines(false);

        // GREEN HEADER
        javax.swing.table.JTableHeader header =
                UserAccountsTable.getTableHeader();

        header.setPreferredSize(
                new java.awt.Dimension(
                        header.getPreferredSize().width, 38
                )
        );

        header.setReorderingAllowed(false);

        javax.swing.table.DefaultTableCellRenderer headerRenderer =
                new javax.swing.table.DefaultTableCellRenderer();

        headerRenderer.setBackground(
                new java.awt.Color(0, 102, 51)
        );

        headerRenderer.setForeground(java.awt.Color.WHITE);

        headerRenderer.setFont(
                new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 14)
        );

        headerRenderer.setHorizontalAlignment(
                javax.swing.SwingConstants.CENTER
        );

        headerRenderer.setOpaque(true);

        for (int i = 0;
                i < UserAccountsTable.getColumnCount();
                i++) {

                UserAccountsTable.getColumnModel()
                        .getColumn(i)
                        .setHeaderRenderer(headerRenderer);
        }

        // CENTER DATA EXCEPT ACTION COLUMN
        javax.swing.table.DefaultTableCellRenderer center =
                new javax.swing.table.DefaultTableCellRenderer();

        center.setHorizontalAlignment(
                javax.swing.SwingConstants.CENTER
        );

        for (int i = 0;
                i < UserAccountsTable.getColumnCount() - 1;
                i++) {

                UserAccountsTable.getColumnModel()
                        .getColumn(i)
                        .setCellRenderer(center);
        }

        // EDIT AND REMOVE BUTTONS
        javax.swing.table.TableColumn action =
               UserAccountsTable.getColumnModel().getColumn(7);

        action.setCellRenderer(new UserActionRenderer());
        action.setCellEditor(new UserActionEditor());
        action.setPreferredWidth(170);
        action.setMinWidth(150);

        UserAccountsTable.setAutoResizeMode(
                javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS
        );

        jScrollPane1.getViewport().setBackground(
                java.awt.Color.WHITE
        );

        header.repaint();
        UserAccountsTable.repaint();
}
private void resizeSearchIcon() {

        javax.swing.ImageIcon originalIcon =
                new javax.swing.ImageIcon(
                        getClass().getResource(
                                "/images/icons8-search-47.png"
                        )
                );

        java.awt.Image resizedImage =
                originalIcon.getImage().getScaledInstance(
                        22, 22,
                        java.awt.Image.SCALE_SMOOTH
                );

        jButton3.setIcon(
                new javax.swing.ImageIcon(resizedImage)
        );

        jButton3.setHorizontalAlignment(
                javax.swing.SwingConstants.CENTER
        );

        jButton3.setVerticalAlignment(
                javax.swing.SwingConstants.CENTER
        );

        jButton3.setMargin(
                new java.awt.Insets(0, 0, 0, 0)
        );
}

public UserAccounts() {
 if (!UserSession.isAdmin()) {

        JOptionPane.showMessageDialog(
                null,
                "Access Denied! Admin only.");

        throw new SecurityException(
                "Only Admin can access User Accounts.");
}
initComponents();

// Use the main Account Details panel
jPanel1.setLayout(null);

// Hide the duplicate account panel
jPanel3.setVisible(false);

// Move Role and Status controls to the main panel
jPanel1.add(jLabel11);
jPanel1.add(jLabel12);
jPanel1.add(jComboBox1);

resizeSearchIcon();
getContentPane().setLayout(null);

setupUserAccountActions();

    setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);

    designSearchBar();
    designUserAccountsTable();
    fixUserAccountsHeader();
    designAccountDetailsPanel();

DefaultTableModel model =
        (DefaultTableModel) UserAccountsTable.getModel();
    connectDatabase();
    loadUserAccounts();

    sorter = new TableRowSorter<>(model);
    UserAccountsTable.setRowSorter(sorter);
    Filter.setModel(
        new javax.swing.DefaultComboBoxModel<>(
                new String[]{
                        "FILTER BY: ALL",
                        "Active",
                        "Inactive"
                }
        )
);

    jButton5.addActionListener(
            e -> clearAccountFields()
    );

    jButton6.addActionListener(
            e -> saveUserAccount()
    );

    // Prevent automatic focus on the search field
    getContentPane().setFocusable(true);

    addWindowListener(new java.awt.event.WindowAdapter() {
        @Override
        public void windowOpened(java.awt.event.WindowEvent evt) {
            getContentPane().requestFocusInWindow();
        }
    });
            addComponentListener(new java.awt.event.ComponentAdapter() {
                @Override
                public void componentResized(java.awt.event.ComponentEvent evt) {
                        fixUserAccountsLayout();
                }
        });

        java.awt.EventQueue.invokeLater(() -> fixUserAccountsLayout());
}
    
private java.awt.Image originalUserAccountsBackground;

private void fixUserAccountsSidebar() {

        int width = getContentPane().getWidth();
        int height = getContentPane().getHeight();

        if (width <= 0 || height <= 0) {
                return;
        }

        double scaleX = width / 1920.0;
        double scaleY = height / 1080.0;

        javax.swing.JButton[] buttons = {
                Dashboard,
                Patients,
                Doctors,
                Appointments,
                MedicalRecords,
                Services,
                Payments,
                Staff,
                UserAccounts,
                UserAccounts1,
                jButton1
        };

        // Dashboard reference positions
        int[] positionsY = {
                380, 450, 500, 560, 620,
                690, 750, 800, 840, 890, 990
        };

        int[] heights = {
                80, 60, 70, 70, 70,
                50, 40, 40, 60, 80, 60
        };

        int fontSize = Math.max(
                18,
                (int) Math.round(
                        24 * Math.min(scaleX, scaleY)
                )
        );

        for (int i = 0; i < buttons.length; i++) {

                javax.swing.JButton button = buttons[i];

                button.setBounds(
                        (int) (60 * scaleX),
                        (int) (positionsY[i] * scaleY),
                        (int) (260 * scaleX),
                        (int) (heights[i] * scaleY)
                );

                button.setFont(new java.awt.Font(
                        "Segoe UI",
                        java.awt.Font.BOLD,
                        fontSize
                ));

                button.setHorizontalAlignment(
                        javax.swing.SwingConstants.LEFT
                );

                button.setFocusPainted(false);
        }

        // Keep User Accounts highlighted
        UserAccounts.setForeground(
                new java.awt.Color(0, 102, 51)
        );

        // Keep Log Out red
        jButton1.setForeground(
                new java.awt.Color(204, 0, 0)
        );
}

private void fixUserAccountsLayout() {

        int width = getContentPane().getWidth();
        int height = getContentPane().getHeight();

        if (width <= 0 || height <= 0) {
                return;
        }

        // 1. RESPONSIVE BACKGROUND
        if (originalUserAccountsBackground == null
                && jLabel1.getIcon() instanceof javax.swing.ImageIcon) {

                originalUserAccountsBackground =
                        ((javax.swing.ImageIcon) jLabel1.getIcon()).getImage();
        }

        if (originalUserAccountsBackground != null) {
                java.awt.Image image =
                        originalUserAccountsBackground.getScaledInstance(
                                width, height,
                                java.awt.Image.SCALE_SMOOTH
                        );

                jLabel1.setIcon(new javax.swing.ImageIcon(image));
        }

        jLabel1.setBounds(0, 0, width, height);

        getContentPane().setComponentZOrder(
                jLabel1,
                getContentPane().getComponentCount() - 1
        );

        // 2. RESPONSIVE SIDEBAR
        int sidebarWidth = Math.max(210, (int) (width * 0.205));

        // 3. MAIN CONTENT AND TITLE
        int contentX = sidebarWidth + 20;
        int contentWidth = width - contentX - 18;

        if (contentWidth <= 0) {
                return;
        }

        jButton11.setBounds(
                contentX,
                40,
                Math.min(390, contentWidth),
                65
        );

        jButton11.setFont(new java.awt.Font(
                "Segoe UI",
                java.awt.Font.BOLD,
                width < 1400 ? 30 : 40
        ));

// 4. SEARCH AND FILTER CONTROLS

// Move controls slightly upward
int searchY = Math.max(
        115,
        Math.min(150, height / 5 - 15)
);

int searchHeight = 42;
int controlGap = 8;

int iconWidth = 42;
int filterWidth = 160;
int sortWidth = 190;
int orderWidth = 145;

// Reference search width: 720px at 1920 resolution
int searchWidth = (int) (720 * width / 1920.0);

// Total width required by controls
int controlsWidth = iconWidth + filterWidth
        + sortWidth + orderWidth + controlGap * 4;

// Prevent controls from extending beyond the content area
searchWidth = Math.max(
        100,
        Math.min(searchWidth, contentWidth - controlsWidth)
);

// SEARCH BAR
jTextField1.setBounds(
        contentX,
        searchY,
        searchWidth,
        searchHeight
);

int nextX = contentX + searchWidth + controlGap;

// SEARCH ICON
jButton3.setBounds(
        nextX,
        searchY,
        iconWidth,
        searchHeight
);

nextX += iconWidth + controlGap;

// FILTER
Filter.setBounds(
        nextX,
        searchY,
        filterWidth,
        searchHeight
);

nextX += filterWidth + controlGap;

// SORT
Sort.setBounds(
        nextX,
        searchY,
        sortWidth,
        searchHeight
);

nextX += sortWidth + controlGap;

// ORDER
Order.setBounds(
        nextX,
        searchY,
        orderWidth,
        searchHeight
);
        // 5. TABLE AND ACCOUNT DETAILS
        int tableY = searchY + searchHeight + 16;

        int detailsHeight = Math.min(
                245,
                Math.max(205, (int) (height * 0.28))
        );

        int detailsY = height - detailsHeight - 12;

        int tableHeight = Math.max(
                120,
                detailsY - tableY - 14
        );

        jPanel2.setBounds(
                contentX,
                tableY,
                contentWidth,
                tableHeight
        );

        jPanel2.setLayout(null);

        jScrollPane1.setBounds(
                0,
                0,
                contentWidth,
                tableHeight
        );

        jPanel1.setBounds(
                contentX,
                detailsY,
                contentWidth,
                detailsHeight
        );

        jPanel1.setLayout(null);

        jPanel1.setBackground(
                new java.awt.Color(222, 246, 236)
        );

        jPanel1.setBorder(
                javax.swing.BorderFactory.createLineBorder(
                        new java.awt.Color(0, 102, 51),
                        2
                )
        );

        // 6. RESPONSIVE TABLE COLUMNS
        UserAccountsTable.setAutoResizeMode(
                javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS
        );

      int[] columnWidths = {
        75,   // User ID
        75,   // Staff ID
        150,  // Username
        120,  // Password
        135,  // Role
        95,   // Status
        180,  // Date Created
        175   // Action
};

        javax.swing.table.TableColumnModel columns =
                UserAccountsTable.getColumnModel();

        for (int i = 0;
                i < columns.getColumnCount()
                && i < columnWidths.length;
                i++) {

                columns.getColumn(i).setPreferredWidth(
                        columnWidths[i]
                );
        }

if (columns.getColumnCount() > 7) {
        columns.getColumn(7).setMinWidth(160);
        columns.getColumn(7).setPreferredWidth(175);
}

        jScrollPane1.setHorizontalScrollBarPolicy(
                javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED
        );

        jScrollPane1.setVerticalScrollBarPolicy(
                javax.swing.JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED
        );

        // 7. RESPONSIVE ACCOUNT DETAILS PANEL
        int padding = 20;
        int columnGap = 16;

        int columnWidth =
                (contentWidth - padding * 2 - columnGap * 2) / 3;

        int x1 = padding;
        int x2 = x1 + columnWidth + columnGap;
        int x3 = x2 + columnWidth + columnGap;

        int row1 = 60;
        int row2 = 105;
        int row3 = 150;

        int fieldHeight = 34;

        jLabel2.setBounds(22, 10, 250, 32);

        jLabel2.setFont(new java.awt.Font(
                "Segoe UI", java.awt.Font.BOLD, 18
        ));

        // COLUMN 1: STAFF ID AND USERNAME
        int labelWidth1 = 95;

        jLabel3.setBounds(
                x1, row1, labelWidth1, fieldHeight
        );

        jTextField8.setBounds(
                x1 + labelWidth1,
                row1,
                columnWidth - labelWidth1,
                fieldHeight
        );

        jLabel4.setBounds(
                x1, row2, labelWidth1, fieldHeight
        );

        jTextField7.setBounds(
                x1 + labelWidth1,
                row2,
                columnWidth - labelWidth1,
                fieldHeight
        );

        // COLUMN 2: PASSWORD AND ROLE
        int labelWidth2 = 95;

        jLabel5.setBounds(
                x2, row1, labelWidth2, fieldHeight
        );

        jTextField9.setBounds(
                x2 + labelWidth2,
                row1,
                columnWidth - labelWidth2,
                fieldHeight
        );

// ROLE LABEL AND TEXT FIELD
jLabel11.setBounds(
        x2, row2, labelWidth2, fieldHeight
);

jTextField4.setBounds(
        x2 + labelWidth2,
        row2,
        columnWidth - labelWidth2,
        fieldHeight
);

// STATUS LABEL AND COMBO BOX
int labelWidth3 = 95;

jLabel12.setBounds(
        x3, row1, labelWidth3, fieldHeight
);

jComboBox1.setBounds(
        x3 + labelWidth3,
        row1,
        columnWidth - labelWidth3,
        fieldHeight
);
        // 8. CLEAR AND SAVE BUTTONS
        int actionButtonWidth = 105;
        int actionButtonHeight = 35;
        int actionButtonGap = 12;

        int buttonY = detailsHeight - 48;

        int saveX = contentWidth - actionButtonWidth - 22;
        int clearX = saveX - actionButtonWidth - actionButtonGap;

        jButton5.setBounds(
                clearX,
                buttonY,
                actionButtonWidth,
                actionButtonHeight
        );

        jButton6.setBounds(
                saveX,
                buttonY,
                actionButtonWidth,
                actionButtonHeight
        );

        // 9. REFRESH
        fixUserAccountsSidebar();
        jPanel2.revalidate();
        jPanel2.repaint();

        jPanel1.revalidate();
        jPanel1.repaint();

        getContentPane().revalidate();
        getContentPane().repaint();
}


private void setupUserAccountActions() {

        DefaultTableModel model = new DefaultTableModel(
                new Object[][]{},
                new String[]{
                        "User ID",
                        "Staff ID",
                        "Username",
                        "Password",
                        "Role",
                        "Status",
                        "Date Created",
                        "Action"
                }
        ) {
                @Override
                public boolean isCellEditable(int row, int column) {
                        return column == 7;
                }
        };

        UserAccountsTable.setModel(model);

        javax.swing.table.TableColumn action =
                UserAccountsTable.getColumnModel().getColumn(7);

        action.setCellRenderer(new UserActionRenderer());
        action.setCellEditor(new UserActionEditor());
        action.setPreferredWidth(170);
        action.setMinWidth(150);
}

private void styleUserButton(javax.swing.JButton button) {

        button.setForeground(java.awt.Color.WHITE);
        button.setFont(new java.awt.Font(
                "Segoe UI", java.awt.Font.BOLD, 11));

        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setContentAreaFilled(false);
        button.setOpaque(false);
        button.setMargin(new java.awt.Insets(0, 0, 0, 0));

        button.setPreferredSize(new java.awt.Dimension(
                button.getText().equals("Edit") ? 58 : 78, 26));

        button.setUI(new javax.swing.plaf.basic.BasicButtonUI() {
                @Override
                public void paint(java.awt.Graphics g,
                        javax.swing.JComponent c) {

                        java.awt.Graphics2D g2 =
                                (java.awt.Graphics2D) g.create();

                        g2.setRenderingHint(
                                java.awt.RenderingHints.KEY_ANTIALIASING,
                                java.awt.RenderingHints.VALUE_ANTIALIAS_ON);

                        boolean isEdit =
                                button.getText().equals("Edit");

                        java.awt.Color top = isEdit
                                ? new java.awt.Color(35, 175, 105)
                                : new java.awt.Color(255, 100, 100);

                        java.awt.Color bottom = isEdit
                                ? new java.awt.Color(0, 125, 65)
                                : new java.awt.Color(210, 40, 40);

                        g2.setPaint(new java.awt.GradientPaint(
                                0, 0, top,
                                0, c.getHeight(), bottom));

                        g2.fillRoundRect(0, 0,
                                c.getWidth() - 1,
                                c.getHeight() - 1, 8, 8);

                        g2.dispose();
                        super.paint(g, c);
                }
        });
}

private class UserActionRenderer extends javax.swing.JPanel
        implements javax.swing.table.TableCellRenderer {

        private final javax.swing.JButton edit =
                new javax.swing.JButton("Edit");

        private final javax.swing.JButton remove =
                new javax.swing.JButton("Remove");

        UserActionRenderer() {
                setLayout(new java.awt.FlowLayout(
                        java.awt.FlowLayout.CENTER, 8, 5));
                setOpaque(false);

                styleUserButton(edit);
                styleUserButton(remove);

                add(edit);
                add(remove);
        }

        @Override
        public java.awt.Component getTableCellRendererComponent(
                javax.swing.JTable table, Object value,
                boolean selected, boolean focus,
                int row, int column) {

                return this;
        }
}

private class UserActionEditor
        extends javax.swing.AbstractCellEditor
        implements javax.swing.table.TableCellEditor {

        private final javax.swing.JPanel panel =
                new javax.swing.JPanel(new java.awt.FlowLayout(
                        java.awt.FlowLayout.CENTER, 8, 5));

        private final javax.swing.JButton edit =
                new javax.swing.JButton("Edit");

        private final javax.swing.JButton remove =
                new javax.swing.JButton("Remove");

        private int selectedRow;

        UserActionEditor() {
                panel.setOpaque(false);

                styleUserButton(edit);
                styleUserButton(remove);

                panel.add(edit);
                panel.add(remove);

                edit.addActionListener(e -> {
                        int row = selectedRow;
                        fireEditingStopped();
                        editUserAccount(row);
                });

                remove.addActionListener(e -> {
                        int row = selectedRow;
                        fireEditingStopped();
                        removeUserAccount(row);
                });
        }

        @Override
        public java.awt.Component getTableCellEditorComponent(
                javax.swing.JTable table, Object value,
                boolean selected, int row, int column) {

                selectedRow = row;
                return panel;
        }

        @Override
        public Object getCellEditorValue() {
                return "";
        }
}

private void editUserAccount(int row) {

        if (row < 0 || row >= UserAccountsTable.getRowCount()) {
                return;
        }

        int modelRow =
                UserAccountsTable.convertRowIndexToModel(row);

        javax.swing.table.TableModel model =
                UserAccountsTable.getModel();

        editingUserId = Integer.parseInt(
                model.getValueAt(modelRow, 0).toString()
        );

        Object staff = model.getValueAt(modelRow, 1);

        jTextField8.setText(
                staff == null ? "" : staff.toString()
        );

        jTextField7.setText(
                String.valueOf(model.getValueAt(modelRow, 2))
        );

// ROLE
jTextField4.setText(
        String.valueOf(model.getValueAt(modelRow, 4))
);

// STATUS
Object statusValue = model.getValueAt(modelRow, 5);

jComboBox1.setSelectedItem(
        statusValue == null
                ? "Active"
                : statusValue.toString()
);
        // Keep the existing password unchanged
        jTextField9.setText("");

        jButton6.setText("Update");
}

private void removeUserAccount(int row) {

        if (row < 0 || row >= UserAccountsTable.getRowCount()) {
                return;
        }

        int modelRow =
                UserAccountsTable.convertRowIndexToModel(row);

        int userId = Integer.parseInt(
                UserAccountsTable.getModel()
                        .getValueAt(modelRow, 0).toString()
        );

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Move this user account to Archive?",
                "Confirm Remove",
                JOptionPane.YES_NO_OPTION
        );

        if (confirm != JOptionPane.YES_OPTION) {
                return;
        }

        if (conn == null) {
                JOptionPane.showMessageDialog(
                        this, "Database is not connected."
                );
                return;
        }

        String sql =
                "UPDATE UserAccount "
                + "SET status = 'Archived' "
                + "WHERE user_id = ? AND status <> 'Archived'";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setInt(1, userId);

                if (ps.executeUpdate() > 0) {

                        JOptionPane.showMessageDialog(
                                this,
                                "User account archived successfully!"
                        );

                        clearAccountFields();
                        loadUserAccounts();

                } else {

                        JOptionPane.showMessageDialog(
                                this, "Account not found."
                        );
                }

        } catch (SQLException e) {

                JOptionPane.showMessageDialog(
                        this,
                        "Failed to archive account:\n"
                        + e.getMessage()
                );
        }
}

private void connectDatabase() {
    try {
        Class.forName("com.mysql.cj.jdbc.Driver");

        conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/ClinicManagementSystem",
                "root",
                ""
        );

        System.out.println("Database connected successfully!");

    } catch (ClassNotFoundException | SQLException e) {
        JOptionPane.showMessageDialog(
                this,
                "Database connection failed!\n" + e.getMessage()
        );
    }
}




private void loadUserAccounts() {

        if (conn == null) {
                return;
        }

        DefaultTableModel model =
                (DefaultTableModel) UserAccountsTable.getModel();

        model.setRowCount(0);

        String sql =
                "SELECT user_id, staff_id, username, "
                + "CASE WHEN password IS NULL OR password = '' "
                + "THEN '(Not set)' ELSE '••••••••' END "
                + "AS password_display, "
                + "role, status, date_created "
                + "FROM UserAccount "
                + "WHERE status <> 'Archived' "
                + "ORDER BY user_id ASC";

        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet result = ps.executeQuery()) {

                while (result.next()) {

                        Object[] row = {
                                result.getInt("user_id"),
                                result.getObject("staff_id"),
                                result.getString("username"),
                                result.getString("password_display"),
                                result.getString("role"),
                                result.getString("status"),
                                result.getTimestamp("date_created"),
                                ""
                        };

                        model.addRow(row);
                }

        } catch (SQLException e) {

                JOptionPane.showMessageDialog(
                        this,
                        "Failed to load user accounts!\n"
                        + e.getMessage()
                );
        }
}




private void saveUserAccount() {

        String staffText = jTextField8.getText().trim();
        String username = jTextField7.getText().trim();
        String password = jTextField9.getText().trim();
        String role = jTextField4.getText().trim();

        Object selectedStatus = jComboBox1.getSelectedItem();

        String status = selectedStatus == null
                ? "" : selectedStatus.toString();

        boolean editing = editingUserId != -1;

        if (staffText.isEmpty() || username.isEmpty()
                || role.isEmpty() || status.isEmpty()) {

                JOptionPane.showMessageDialog(
                        this, "Please complete all required fields.");
                return;
        }

        if (!editing && password.isEmpty()) {
                JOptionPane.showMessageDialog(
                        this, "Please enter a password.");
                return;
        }

        if (conn == null) {
                JOptionPane.showMessageDialog(
                        this, "Database is not connected.");
                return;
        }

        try {

                int staffId = Integer.parseInt(staffText);

                String checkStaff =
                        "SELECT staff_id FROM Staff "
                        + "WHERE staff_id = ? AND status <> 'Archived'";

                try (PreparedStatement check =
                        conn.prepareStatement(checkStaff)) {

                        check.setInt(1, staffId);

                        try (ResultSet result = check.executeQuery()) {

                                if (!result.next()) {
                                        JOptionPane.showMessageDialog(
                                                this,
                                                "Staff ID does not exist or is archived.");
                                        return;
                                }
                        }
                }

                String sql;

                if (editing) {

                        if (password.isEmpty()) {

                                sql = "UPDATE UserAccount SET "
                                        + "staff_id=?, username=?, "
                                        + "role=?, status=? "
                                        + "WHERE user_id=? "
                                        + "AND status <> 'Archived'";

                        } else {

                                sql = "UPDATE UserAccount SET "
                                        + "staff_id=?, username=?, "
                                        + "role=?, status=?, password=? "
                                        + "WHERE user_id=? "
                                        + "AND status <> 'Archived'";
                        }

                } else {

                        sql = "INSERT INTO UserAccount "
                                + "(staff_id, username, password, "
                                + "role, status) "
                                + "VALUES (?, ?, ?, ?, ?)";
                }

                try (PreparedStatement ps =
                        conn.prepareStatement(sql)) {

                        ps.setInt(1, staffId);
                        ps.setString(2, username);

                        if (editing) {

                                ps.setString(3, role);
                                ps.setString(4, status);

                                if (password.isEmpty()) {
                                        ps.setInt(5, editingUserId);
                                } else {
                                        ps.setString(5, password);
                                        ps.setInt(6, editingUserId);
                                }

                        } else {

                                ps.setString(3, password);
                                ps.setString(4, role);
                                ps.setString(5, status);
                        }

                        int affected = ps.executeUpdate();

                        if (affected > 0) {

                                JOptionPane.showMessageDialog(
                                        this,
                                        editing
                                                ? "Account updated successfully!"
                                                : "Account created successfully!");

                                clearAccountFields();
                                loadUserAccounts();

                        } else {

                                JOptionPane.showMessageDialog(
                                        this,
                                        "Account was not updated.");
                        }
                }

        } catch (NumberFormatException e) {

                JOptionPane.showMessageDialog(
                        this, "Staff ID must be a number.");

        } catch (SQLException e) {

                if (e.getErrorCode() == 1062) {

                        JOptionPane.showMessageDialog(
                                this, "Username already exists.");

                } else {

                        JOptionPane.showMessageDialog(
                                this,
                                "Failed to save account:\n"
                                + e.getMessage());
                }
        }
}
private void clearAccountFields() {

        jTextField8.setText("");
        jTextField7.setText("");
        jTextField9.setText("");
        jTextField4.setText("");

        jComboBox1.setSelectedItem("Active");

        editingUserId = -1;
        jButton6.setText("Save");

        UserAccountsTable.clearSelection();
        jTextField8.requestFocusInWindow();
}                      
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        Patients = new javax.swing.JButton();
        Appointments = new javax.swing.JButton();
        MedicalRecords = new javax.swing.JButton();
        Services = new javax.swing.JButton();
        Payments = new javax.swing.JButton();
        Dashboard = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        Staff = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        UserAccountsTable = new javax.swing.JTable();
        Doctors = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        UserAccounts = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jTextField9 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jTextField10 = new javax.swing.JTextField();
        jTextField11 = new javax.swing.JTextField();
        jTextField12 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jTextField4 = new javax.swing.JTextField();
        Filter = new javax.swing.JComboBox<>();
        Sort = new javax.swing.JComboBox<>();
        Order = new javax.swing.JComboBox<>();
        UserAccounts1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton1.setForeground(new java.awt.Color(204, 0, 0));
        jButton1.setText("Log Out");
        jButton1.setBorderPainted(false);
        jButton1.setContentAreaFilled(false);
        jButton1.setDefaultCapable(false);
        jButton1.setFocusPainted(false);
        jButton1.setFocusable(false);
        jButton1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton1.addActionListener(this::jButton1ActionPerformed);
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 990, 260, 60));

        Patients.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Patients.setForeground(new java.awt.Color(255, 255, 255));
        Patients.setText("Patients");
        Patients.setBorderPainted(false);
        Patients.setContentAreaFilled(false);
        Patients.setDefaultCapable(false);
        Patients.setFocusPainted(false);
        Patients.setFocusable(false);
        Patients.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Patients.addActionListener(this::PatientsActionPerformed);
        getContentPane().add(Patients, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 450, 260, 60));

        Appointments.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Appointments.setForeground(new java.awt.Color(255, 255, 255));
        Appointments.setText("Appointments");
        Appointments.setBorderPainted(false);
        Appointments.setContentAreaFilled(false);
        Appointments.setDefaultCapable(false);
        Appointments.setFocusPainted(false);
        Appointments.setFocusable(false);
        Appointments.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Appointments.addActionListener(this::AppointmentsActionPerformed);
        getContentPane().add(Appointments, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 560, 260, 70));

        MedicalRecords.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        MedicalRecords.setForeground(new java.awt.Color(255, 255, 255));
        MedicalRecords.setText("Medical Records");
        MedicalRecords.setBorderPainted(false);
        MedicalRecords.setContentAreaFilled(false);
        MedicalRecords.setDefaultCapable(false);
        MedicalRecords.setFocusPainted(false);
        MedicalRecords.setFocusable(false);
        MedicalRecords.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        MedicalRecords.addActionListener(this::MedicalRecordsActionPerformed);
        getContentPane().add(MedicalRecords, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 620, 260, 70));

        Services.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Services.setForeground(new java.awt.Color(255, 255, 255));
        Services.setText("Services");
        Services.setBorderPainted(false);
        Services.setContentAreaFilled(false);
        Services.setDefaultCapable(false);
        Services.setFocusPainted(false);
        Services.setFocusable(false);
        Services.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Services.addActionListener(this::ServicesActionPerformed);
        getContentPane().add(Services, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 690, 260, 50));

        Payments.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Payments.setForeground(new java.awt.Color(255, 255, 255));
        Payments.setText("Payments");
        Payments.setBorderPainted(false);
        Payments.setContentAreaFilled(false);
        Payments.setDefaultCapable(false);
        Payments.setFocusPainted(false);
        Payments.setFocusable(false);
        Payments.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Payments.addActionListener(this::PaymentsActionPerformed);
        getContentPane().add(Payments, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 750, 260, 40));

        Dashboard.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Dashboard.setForeground(new java.awt.Color(255, 255, 255));
        Dashboard.setText("Dashboard");
        Dashboard.setBorderPainted(false);
        Dashboard.setContentAreaFilled(false);
        Dashboard.setDefaultCapable(false);
        Dashboard.setFocusPainted(false);
        Dashboard.setFocusable(false);
        Dashboard.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Dashboard.addActionListener(this::DashboardActionPerformed);
        getContentPane().add(Dashboard, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 380, 260, 80));

        jButton11.setFont(new java.awt.Font("Segoe UI", 1, 40)); // NOI18N
        jButton11.setText("User Accounts");
        jButton11.setBorderPainted(false);
        jButton11.setContentAreaFilled(false);
        jButton11.setDefaultCapable(false);
        jButton11.setFocusPainted(false);
        jButton11.setFocusable(false);
        jButton11.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton11.addActionListener(this::jButton11ActionPerformed);
        getContentPane().add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 40, 360, -1));

        Staff.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Staff.setForeground(new java.awt.Color(255, 255, 255));
        Staff.setText("Staff");
        Staff.setBorderPainted(false);
        Staff.setContentAreaFilled(false);
        Staff.setDefaultCapable(false);
        Staff.setFocusPainted(false);
        Staff.setFocusable(false);
        Staff.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Staff.addActionListener(this::StaffActionPerformed);
        getContentPane().add(Staff, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 800, 260, 40));

        jPanel2.setBackground(new java.awt.Color(222, 246, 236));

        UserAccountsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "User ID", "Staff ID", "Username", "Password", "Role", "Date Created"
            }
        ));
        UserAccountsTable.setFocusCycleRoot(true);
        UserAccountsTable.setGridColor(new java.awt.Color(231, 250, 250));
        UserAccountsTable.setShowGrid(true);
        UserAccountsTable.setSurrendersFocusOnKeystroke(true);
        jScrollPane1.setViewportView(UserAccountsTable);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1474, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 544, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 230, 1480, 550));

        Doctors.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Doctors.setForeground(new java.awt.Color(255, 255, 255));
        Doctors.setText("Doctors");
        Doctors.setBorderPainted(false);
        Doctors.setContentAreaFilled(false);
        Doctors.setDefaultCapable(false);
        Doctors.setFocusPainted(false);
        Doctors.setFocusable(false);
        Doctors.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Doctors.addActionListener(this::DoctorsActionPerformed);
        getContentPane().add(Doctors, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 500, 260, 70));

        jTextField1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jTextField1.setText("Search user account...");
        jTextField1.addActionListener(this::jTextField1ActionPerformed);
        getContentPane().add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 160, 720, 50));

        UserAccounts.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        UserAccounts.setForeground(new java.awt.Color(0, 102, 51));
        UserAccounts.setText("User Accounts");
        UserAccounts.setDefaultCapable(false);
        UserAccounts.setFocusPainted(false);
        UserAccounts.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        UserAccounts.addActionListener(this::UserAccountsActionPerformed);
        getContentPane().add(UserAccounts, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 840, 260, 60));

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-search-47.png"))); // NOI18N
        jButton3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 51)));
        jButton3.setBorderPainted(false);
        jButton3.addActionListener(this::jButton3ActionPerformed);
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 160, -1, -1));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 102, 51));
        jLabel2.setText("Account Details");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Staff");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Username");

        jButton5.setBackground(new java.awt.Color(240, 250, 244));
        jButton5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton5.setForeground(new java.awt.Color(0, 102, 51));
        jButton5.setText("Clear");

        jButton6.setBackground(new java.awt.Color(0, 102, 51));
        jButton6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.setText("Save");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setText("Password");

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel12.setText("Status");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 102, 51));
        jLabel6.setText("Account Details");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setText("Staff");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel8.setText("Username");

        jButton7.setBackground(new java.awt.Color(240, 250, 244));
        jButton7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton7.setForeground(new java.awt.Color(0, 102, 51));
        jButton7.setText("Clear");

        jButton8.setBackground(new java.awt.Color(0, 102, 51));
        jButton8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton8.setForeground(new java.awt.Color(255, 255, 255));
        jButton8.setText("Save");

        jLabel11.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel11.setText("Role");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel9.setText("Password");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Active", "Inactive" }));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jLabel6))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jLabel7))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTextField11, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
                            .addComponent(jTextField10)
                            .addComponent(jTextField12, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(38, 38, 38)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jButton7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton8))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel11)
                                .addGap(18, 18, 18)
                                .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel12)
                                .addGap(18, 18, 18)
                                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(798, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addGap(25, 25, 25)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9))
                        .addContainerGap())
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel12)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(19, 19, 19))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))))))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jLabel2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jLabel3))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTextField8, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
                            .addComponent(jTextField7)
                            .addComponent(jTextField9, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(356, 356, 356)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jButton5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton6))
                            .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(536, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addContainerGap(46, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(19, 19, 19))))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 790, 1480, 210));

        Filter.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Filter.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "FILTER BY: ALL", "Active", "Inactive", " " }));
        Filter.addActionListener(this::FilterActionPerformed);
        getContentPane().add(Filter, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 160, 120, 50));

        Sort.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Sort.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SORT BY: DEFAULT", "User ID", "Staff ID", "Username", "Role", "Date Created" }));
        Sort.addActionListener(this::SortActionPerformed);
        getContentPane().add(Sort, new org.netbeans.lib.awtextra.AbsoluteConstraints(1310, 160, 100, 50));

        Order.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Order.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ORDER", "ASCENDING", "DESCENDING" }));
        Order.addActionListener(this::OrderActionPerformed);
        getContentPane().add(Order, new org.netbeans.lib.awtextra.AbsoluteConstraints(1420, 160, 100, 50));

        UserAccounts1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        UserAccounts1.setForeground(new java.awt.Color(255, 255, 255));
        UserAccounts1.setText("Archive");
        UserAccounts1.setBorderPainted(false);
        UserAccounts1.setContentAreaFilled(false);
        UserAccounts1.setDefaultCapable(false);
        UserAccounts1.setFocusPainted(false);
        UserAccounts1.setFocusable(false);
        UserAccounts1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        UserAccounts1.addActionListener(this::UserAccounts1ActionPerformed);
        getContentPane().add(UserAccounts1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 890, 260, 80));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Dashgh.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1930, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void PatientsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PatientsActionPerformed
    Patients patients = new Patients();
    patients.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_PatientsActionPerformed

    private void AppointmentsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AppointmentsActionPerformed
    Appointments appointments = new Appointments();
    appointments.setVisible(true);
    this.dispose();          // TODO add your handling code here:
    }//GEN-LAST:event_AppointmentsActionPerformed

    private void PaymentsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PaymentsActionPerformed
    Payments payments = new Payments();
    payments.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_PaymentsActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton11ActionPerformed

    private void DoctorsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DoctorsActionPerformed
    Doctors doctors = new Doctors();
    doctors.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_DoctorsActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
           searchUserAccounts();
 // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
            searchUserAccounts();
// TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void DashboardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DashboardActionPerformed
    Dashboard dashboard = new Dashboard();
    dashboard.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_DashboardActionPerformed

    private void MedicalRecordsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MedicalRecordsActionPerformed
    MedicalRecords records = new MedicalRecords();
    records.setVisible(true);
    this.dispose();

        // TODO add your handling code here:
    }//GEN-LAST:event_MedicalRecordsActionPerformed

    private void ServicesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ServicesActionPerformed
    Services services = new Services();
    services.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_ServicesActionPerformed

    private void StaffActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StaffActionPerformed
    Staff staff = new Staff();
    staff.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_StaffActionPerformed

    private void UserAccountsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UserAccountsActionPerformed
    UserAccounts accounts = new UserAccounts();
    accounts.setVisible(true);
    this.dispose();
        // TODO add your handling code here:
    }//GEN-LAST:event_UserAccountsActionPerformed

    private void FilterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FilterActionPerformed
        searchUserAccounts();
        // TODO add your handling code here:
    }//GEN-LAST:event_FilterActionPerformed

    private void SortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SortActionPerformed
        sortUserAccounts();

        // TODO add your handling code here:
    }//GEN-LAST:event_SortActionPerformed

    private void OrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OrderActionPerformed
        sortUserAccounts();
        // TODO add your handling code here:
    }//GEN-LAST:event_OrderActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    UserSession.logout();
        SignIn logout = new SignIn();
    logout.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void UserAccounts1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UserAccounts1ActionPerformed
        Archive archive = new Archive();
        archive.setVisible(true);
        this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_UserAccounts1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new UserAccounts().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Appointments;
    private javax.swing.JButton Dashboard;
    private javax.swing.JButton Doctors;
    private javax.swing.JComboBox<String> Filter;
    private javax.swing.JButton MedicalRecords;
    private javax.swing.JComboBox<String> Order;
    private javax.swing.JButton Patients;
    private javax.swing.JButton Payments;
    private javax.swing.JButton Services;
    private javax.swing.JComboBox<String> Sort;
    private javax.swing.JButton Staff;
    private javax.swing.JButton UserAccounts;
    private javax.swing.JButton UserAccounts1;
    private javax.swing.JTable UserAccountsTable;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    // End of variables declaration//GEN-END:variables
}
