import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class Appointments extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Appointments.class.getName());
        private Connection conn;
        private PreparedStatement pst;
        private ResultSet rs;
        private TableRowSorter<DefaultTableModel> sorter;
        private int editingAppointmentId = -1;
        

    /**
     * Creates new form Appointments
     */
    public Appointments() {
        initComponents();
        getContentPane().setLayout(null);

jPanel2.setLayout(new java.awt.BorderLayout());
jPanel2.add(jScrollPane1, java.awt.BorderLayout.CENTER);
        
        disableAppointmentsTableEditing();

        jPanel1.setLayout(null);
        setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
        designSearchBar();
designAppointmentsTable();
fixAppointmentsHeader();
addActionColumn();
configureActionColumn();

makeAppointmentsResponsive();

connectDatabase();

loadPatientsComboBox();
loadDoctorsComboBox();
loadServicesComboBox();

loadAppointments();

        DefaultTableModel model =
                (DefaultTableModel) AppointmentsTable.getModel();

        sorter = new TableRowSorter<>(model);
        AppointmentsTable.setRowSorter(sorter);

        jButton5.addActionListener(e -> clearAppointmentForm());
        jButton6.addActionListener(e -> saveAppointment());
        getContentPane().setFocusable(true);
getContentPane().requestFocusInWindow();

    }
    private void scaleAppointmentSearchIcon() {

        java.net.URL url = getClass().getResource(
                "/images/icons8-search-47.png"
        );

        if (url == null) {
                return;
        }

        javax.swing.ImageIcon icon =
                new javax.swing.ImageIcon(url);

        int size = Math.min(
                jButton3.getWidth(),
                jButton3.getHeight()
        );

        // Same 60% icon scaling as Doctors
        size = Math.max(16, (int) (size * 0.60));

        java.awt.Image image =
                icon.getImage().getScaledInstance(
                        size,
                        size,
                        java.awt.Image.SCALE_SMOOTH
                );

        jButton3.setIcon(
                new javax.swing.ImageIcon(image)
        );

        jButton3.setHorizontalAlignment(
                javax.swing.SwingConstants.CENTER
        );

        jButton3.setVerticalAlignment(
                javax.swing.SwingConstants.CENTER
        );

        jButton3.setIconTextGap(0);
}
private void filterAppointments() {

        if (sorter == null) {
                return;
        }

        String selected =
                Filter.getSelectedItem().toString();

        if (selected.equals("FILTER BY: ALL")) {
                sorter.setRowFilter(null);
        } else {
                sorter.setRowFilter(
                        javax.swing.RowFilter.regexFilter(
                                "(?i)^" + selected + "$", 7
                        )
                );
        }
}
    
private void scaleAppointmentsBackground() {

    int width = getContentPane().getWidth();
    int height = getContentPane().getHeight();

    if (width <= 0 || height <= 0) {
        return;
    }

    java.net.URL imageURL = getClass().getResource(
            "/images/Dashgh.png"
    );

    if (imageURL == null) {
        System.out.println("Appointments background not found!");
        return;
    }

    javax.swing.ImageIcon original =
            new javax.swing.ImageIcon(imageURL);

    java.awt.Image scaledImage =
            original.getImage().getScaledInstance(
                    width,
                    height,
                    java.awt.Image.SCALE_SMOOTH
            );

    jLabel1.setIcon(
            new javax.swing.ImageIcon(scaledImage)
    );

    jLabel1.setBounds(0, 0, width, height);

    // Keep the background behind all components
    getContentPane().setComponentZOrder(
            jLabel1,
            getContentPane().getComponentCount() - 1
    );

    jLabel1.repaint();
}

private void disableAppointmentsTableEditing() {

        DefaultTableModel model =
                (DefaultTableModel) AppointmentsTable.getModel();

        model.setColumnCount(8);

        AppointmentsTable.setModel(
                new DefaultTableModel(
                        new Object[][]{},
                        new String[]{
                                "Appointment ID",
                                "Patient ID",
                                "Doctor ID",
                                "Service ID",
                                "Appointment Date",
                                "Appointment Time",
                                "Notes",
                                "Status",
                                "Action"
                        }
                ) {
                        @Override
                        public boolean isCellEditable(int row, int column) {
                                return column == 8;
                        }
                }
        );

        AppointmentsTable.setSurrendersFocusOnKeystroke(false);
}

private void saveAppointment() {

    if (PatientComboBox.getSelectedIndex() == 0) {

        JOptionPane.showMessageDialog(
                this,
                "Please select a patient."
        );

        return;
    }

    if (DoctorComboBox.getSelectedIndex() == 0) {

        JOptionPane.showMessageDialog(
                this,
                "Please select a doctor."
        );

        return;
    }

    if (ServiceComboBox.getSelectedIndex() == 0) {

        JOptionPane.showMessageDialog(
                this,
                "Please select a service."
        );

        return;
    }

    String dateText =
            jTextField5.getText().trim();

    String timeText =
            jTextField6.getText().trim();

    String notes =
            jTextArea1.getText().trim();

    String status =
            jComboBox1.getSelectedItem().toString();

    if (dateText.isEmpty()
            || timeText.isEmpty()) {

        JOptionPane.showMessageDialog(
                this,
                "Please enter the appointment date and time."
        );

        return;
    }

    try {

        String patientSelection =
                PatientComboBox
                        .getSelectedItem()
                        .toString();

        String doctorSelection =
                DoctorComboBox
                        .getSelectedItem()
                        .toString();

        String serviceSelection =
                ServiceComboBox
                        .getSelectedItem()
                        .toString();

        int patientId =
                Integer.parseInt(
                        patientSelection
                                .split(" - ")[0]
                );

        int doctorId =
                Integer.parseInt(
                        doctorSelection
                                .split(" - ")[0]
                );

        int serviceId =
                Integer.parseInt(
                        serviceSelection
                                .split(" - ")[0]
                );

        java.sql.Date appointmentDate =
                java.sql.Date.valueOf(dateText);

        if (timeText.matches("\\d{2}:\\d{2}")) {
            timeText += ":00";
        }

        java.sql.Time appointmentTime =
                java.sql.Time.valueOf(timeText);

        // =========================
        // NEW APPOINTMENT
        // =========================
        if (editingAppointmentId == -1) {

            String sql =
                    "INSERT INTO Appointments "
                    + "(patient_id, doctor_id, service_id, "
                    + "appointment_date, appointment_time, "
                    + "notes, status) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?)";

            pst = conn.prepareStatement(sql);

            pst.setInt(1, patientId);
            pst.setInt(2, doctorId);
            pst.setInt(3, serviceId);
            pst.setDate(4, appointmentDate);
            pst.setTime(5, appointmentTime);
            pst.setString(6, notes);
            pst.setString(7, status);

            pst.executeUpdate();

            JOptionPane.showMessageDialog(
                    this,
                    "Appointment saved successfully!"
            );

        } else {

            // =========================
            // UPDATE APPOINTMENT
            // =========================

            String sql =
                    "UPDATE Appointments SET "
                    + "patient_id = ?, "
                    + "doctor_id = ?, "
                    + "service_id = ?, "
                    + "appointment_date = ?, "
                    + "appointment_time = ?, "
                    + "notes = ?, "
                    + "status = ? "
                    + "WHERE appointment_id = ?";

            pst = conn.prepareStatement(sql);

            pst.setInt(1, patientId);
            pst.setInt(2, doctorId);
            pst.setInt(3, serviceId);
            pst.setDate(4, appointmentDate);
            pst.setTime(5, appointmentTime);
            pst.setString(6, notes);
            pst.setString(7, status);
            pst.setInt(8, editingAppointmentId);

            pst.executeUpdate();

            JOptionPane.showMessageDialog(
                    this,
                    "Appointment updated successfully!"
            );
        }

        clearAppointmentForm();
        loadAppointments();

    } catch (IllegalArgumentException e) {

        JOptionPane.showMessageDialog(
                this,
                "Invalid date or time.\n"
                + "Date format: YYYY-MM-DD\n"
                + "Time format: HH:MM"
        );

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "Failed to save appointment!\n"
                + e.getMessage()
        );
    }
}
private void clearAppointmentForm() {

    editingAppointmentId = -1;

    PatientComboBox.setSelectedIndex(0);
    DoctorComboBox.setSelectedIndex(0);
    ServiceComboBox.setSelectedIndex(0);

    jTextField5.setText("");
    jTextField6.setText("");
    jTextArea1.setText("");

    jComboBox1.setSelectedItem("Scheduled");

    jButton6.setText("Save");

    PatientComboBox.requestFocus();
}
private void searchAppointments() {

        String searchText = jTextField1.getText().trim();

        if (searchText.isEmpty()
                || searchText.equals(
                        "Search appointment by patient, doctor, or date..."
                )) {

                sorter.setRowFilter(null);
                return;
        }

        String selectedFilter =
                Filter.getSelectedItem().toString();

        int column = -1;

        switch (selectedFilter) {

                case "Patient ID":
                        column = 1;
                        break;

                case "Doctor ID":
                        column = 2;
                        break;

                case "Service ID":
                        column = 3;
                        break;

                case "Status":
                        column = 7;
                        break;
        
        }

        if (column == -1) {

                sorter.setRowFilter(
                        javax.swing.RowFilter.regexFilter(
                                "(?i)" + searchText
                        )
                );

        } else {

                sorter.setRowFilter(
                        javax.swing.RowFilter.regexFilter(
                                "(?i)" + searchText,
                                column
                        )
                );
        }
}
private void sortAppointments() {

        String selectedSort =
                Sort.getSelectedItem().toString();

        String selectedOrder =
                Order.getSelectedItem().toString();

        int column = -1;

         switch (selectedSort) {

                case "ID":
                        column = 0;
                        break;

                case "Date":
                        column = 4;
                        break;

                case "Time":
                        column = 5;
                        break;
        }

        if (column == -1) {
                return;
        }

        javax.swing.SortOrder order =
                javax.swing.SortOrder.ASCENDING;

        if (selectedOrder.equals("DESCENDING")) {

                order =
                        javax.swing.SortOrder.DESCENDING;
        }

        java.util.List<
                javax.swing.RowSorter.SortKey> sortKeys =
                new java.util.ArrayList<>();

        sortKeys.add(
                new javax.swing.RowSorter.SortKey(
                        column,
                        order
                )
        );

        sorter.setSortKeys(sortKeys);
}
private void connectDatabase() {

        try {

                Class.forName(
                        "com.mysql.cj.jdbc.Driver"
                );

                conn = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/ClinicManagementSystem",
                        "root",
                        ""
                );

                System.out.println(
                        "Appointments Database Connected!"
                );

        } catch (ClassNotFoundException | SQLException e) {

                JOptionPane.showMessageDialog(
                        this,
                        "Database Connection Failed!\n"
                        + e.getMessage()
                );
        }
}
private void loadPatientsComboBox() {

    PatientComboBox.removeAllItems();
    PatientComboBox.addItem("Select Patient");

    String sql =
            "SELECT patient_id, first_name, last_name "
            + "FROM Patients "
            + "WHERE status = 'Active' "
            + "ORDER BY first_name, last_name";

    try (PreparedStatement ps = conn.prepareStatement(sql);
         ResultSet result = ps.executeQuery()) {

        while (result.next()) {

            int id = result.getInt("patient_id");
            String firstName = result.getString("first_name");
            String lastName = result.getString("last_name");

            PatientComboBox.addItem(
                    id + " - " + firstName + " " + lastName
            );
        }

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "Failed to load patients!\n"
                + e.getMessage()
        );
    }
}

private void loadDoctorsComboBox() {

    DoctorComboBox.removeAllItems();
    DoctorComboBox.addItem("Select Doctor");

    String sql =
            "SELECT doctor_id, first_name, last_name "
            + "FROM Doctors "
            + "WHERE status = 'Available' "
            + "ORDER BY first_name, last_name";

    try (PreparedStatement ps = conn.prepareStatement(sql);
         ResultSet result = ps.executeQuery()) {

        while (result.next()) {

            int id = result.getInt("doctor_id");
            String firstName = result.getString("first_name");
            String lastName = result.getString("last_name");

            DoctorComboBox.addItem(
                    id + " - Dr. "
                    + firstName + " " + lastName
            );
        }

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "Failed to load doctors!\n"
                + e.getMessage()
        );
    }
}

private void loadServicesComboBox() {

    ServiceComboBox.removeAllItems();
    ServiceComboBox.addItem("Select Service");

    String sql =
            "SELECT service_id, service_name "
            + "FROM Services "
            + "ORDER BY service_name";

    try (PreparedStatement ps = conn.prepareStatement(sql);
         ResultSet result = ps.executeQuery()) {

        while (result.next()) {

            int id = result.getInt("service_id");
            String serviceName =
                    result.getString("service_name");

            ServiceComboBox.addItem(
                    id + " - " + serviceName
            );
        }

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "Failed to load services!\n"
                + e.getMessage()
        );
    }
}
private void loadAppointments() {

        if (conn == null) {
                return;
        }

        DefaultTableModel model =
                (DefaultTableModel)
                AppointmentsTable.getModel();

        // Remove the sample blank rows
        model.setRowCount(0);

         String sql =
                  "SELECT appointment_id, patient_id, "
                   + "doctor_id, service_id, "
                   + "appointment_date, appointment_time, "
                + "notes, status "
+ "FROM Appointments "
+ "WHERE status <> 'Archived' "
+ "ORDER BY appointment_id ASC";        try {

                pst = conn.prepareStatement(sql);
                rs = pst.executeQuery();

                while (rs.next()) {

                        Object[] row = {

                                rs.getInt(
                                        "appointment_id"
                                ),

                                rs.getInt(
                                        "patient_id"
                                ),

                                rs.getInt(
                                        "doctor_id"
                                ),

                                rs.getInt(
                                        "service_id"
                                ),

                                rs.getDate(
                                        "appointment_date"
                                ),

                                rs.getTime(
                                        "appointment_time"
                                ),

                                rs.getString(
                                        "notes"
                                ),
                                rs.getString(
                                        "status")

                        };

                        model.addRow(row);
                }

        } catch (SQLException e) {

                JOptionPane.showMessageDialog(
                        this,
                        "Failed to load appointments!\n"
                        + e.getMessage()
                );
        }
}
private void addActionColumn() {

    DefaultTableModel model =
            (DefaultTableModel) AppointmentsTable.getModel();

    if (model.findColumn("Action") == -1) {
        model.addColumn("Action");
    }
}
private void configureActionColumn() {

    int actionColumn =
            AppointmentsTable.getColumnModel()
                    .getColumnIndex("Action");

    AppointmentsTable.getColumnModel()
            .getColumn(actionColumn)
            .setCellRenderer(new AppointmentActionRenderer());

    AppointmentsTable.getColumnModel()
            .getColumn(actionColumn)
            .setCellEditor(new AppointmentActionEditor());

    AppointmentsTable.getColumnModel()
            .getColumn(actionColumn)
            .setPreferredWidth(180);
}
private class AppointmentActionRenderer
        extends javax.swing.JPanel
        implements javax.swing.table.TableCellRenderer {

    private final javax.swing.JButton editButton;
    private final javax.swing.JButton cancelButton;

    public AppointmentActionRenderer() {

        setLayout(new java.awt.FlowLayout(
                java.awt.FlowLayout.CENTER,
                5,
                3
        ));

        editButton = new javax.swing.JButton("Edit");
        cancelButton = new javax.swing.JButton("Remove");

        editButton.setBackground(
                new java.awt.Color(0, 102, 51)
        );
        editButton.setForeground(java.awt.Color.WHITE);

        cancelButton.setBackground(
                new java.awt.Color(204, 0, 0)
        );
        cancelButton.setForeground(java.awt.Color.WHITE);

        editButton.setFocusPainted(false);
        cancelButton.setFocusPainted(false);

        add(editButton);
        add(cancelButton);
    }

    @Override
    public java.awt.Component getTableCellRendererComponent(
            javax.swing.JTable table,
            Object value,
            boolean isSelected,
            boolean hasFocus,
            int row,
            int column) {

        if (isSelected) {
            setBackground(table.getSelectionBackground());
        } else {
            setBackground(java.awt.Color.WHITE);
        }

        return this;
    }
}
private class AppointmentActionEditor
        extends javax.swing.AbstractCellEditor
        implements javax.swing.table.TableCellEditor {

    private final javax.swing.JPanel panel;
    private final javax.swing.JButton editButton;
    private final javax.swing.JButton cancelButton;

    private int currentRow;

    public AppointmentActionEditor() {

        panel = new javax.swing.JPanel(
                new java.awt.FlowLayout(
                        java.awt.FlowLayout.CENTER,
                        5,
                        3
                )
        );

        editButton = new javax.swing.JButton("Edit");
        cancelButton = new javax.swing.JButton("Cancel");

        editButton.setBackground(
                new java.awt.Color(0, 102, 51)
        );
        editButton.setForeground(java.awt.Color.WHITE);

        cancelButton.setBackground(
                new java.awt.Color(204, 0, 0)
        );
        cancelButton.setForeground(java.awt.Color.WHITE);

        editButton.setFocusPainted(false);
        cancelButton.setFocusPainted(false);

        editButton.addActionListener(e -> {

            fireEditingStopped();
            editAppointment(currentRow);
        });

cancelButton.addActionListener(e -> {

        int row = currentRow;
        fireEditingStopped();
        removeAppointment(row);
});

        panel.add(editButton);
        panel.add(cancelButton);
    }

    @Override
    public java.awt.Component getTableCellEditorComponent(
            javax.swing.JTable table,
            Object value,
            boolean isSelected,
            int row,
            int column) {

        currentRow = row;

        panel.setBackground(
                table.getSelectionBackground()
        );

        return panel;
    }

    @Override
    public Object getCellEditorValue() {
        return "";
    }
}
private void removeAppointment(int viewRow) {

        if (viewRow < 0 || viewRow >= AppointmentsTable.getRowCount()) {
                return;
        }

        int row = AppointmentsTable.convertRowIndexToModel(viewRow);

        DefaultTableModel model =
                (DefaultTableModel) AppointmentsTable.getModel();

        int appointmentId = Integer.parseInt(
                model.getValueAt(row, 0).toString()
        );

        int choice = JOptionPane.showConfirmDialog(
                this,
                "Move Appointment #" + appointmentId + " to Archive?",
                "Confirm Remove",
                JOptionPane.YES_NO_OPTION
        );

        if (choice != JOptionPane.YES_OPTION) {
                return;
        }

        String sql =
                "UPDATE Appointments "
                + "SET status = 'Archived' "
                + "WHERE appointment_id = ? "
                + "AND status <> 'Archived'";

        try {

                if (conn == null || conn.isClosed()) {
                        connectDatabase();
                }

                try (PreparedStatement ps = conn.prepareStatement(sql)) {

                        ps.setInt(1, appointmentId);

                        int updated = ps.executeUpdate();

                        if (updated > 0) {

                                JOptionPane.showMessageDialog(
                                        this,
                                        "Appointment moved to Archive successfully!"
                                );

                                loadAppointments();
                                clearAppointmentForm();

                        } else {

                                JOptionPane.showMessageDialog(
                                        this,
                                        "Appointment could not be archived."
                                );
                        }
                }

        } catch (SQLException e) {

                JOptionPane.showMessageDialog(
                        this,
                        "Failed to archive appointment!\n"
                        + e.getMessage()
                );
        }
}
private void editAppointment(int viewRow) {

    int row =
            AppointmentsTable.convertRowIndexToModel(viewRow);

    DefaultTableModel model =
            (DefaultTableModel) AppointmentsTable.getModel();

    editingAppointmentId =
            Integer.parseInt(
                    model.getValueAt(row, 0).toString()
            );

    int patientId =
            Integer.parseInt(
                    model.getValueAt(row, 1).toString()
            );

    int doctorId =
            Integer.parseInt(
                    model.getValueAt(row, 2).toString()
            );

    int serviceId =
            Integer.parseInt(
                    model.getValueAt(row, 3).toString()
            );

    // Select Patient
    selectComboBoxById(
            PatientComboBox,
            patientId
    );

    // Select Doctor
    selectComboBoxById(
            DoctorComboBox,
            doctorId
    );

    // Select Service
    selectComboBoxById(
            ServiceComboBox,
            serviceId
    );

    // Date
    jTextField5.setText(
            model.getValueAt(row, 4).toString()
    );

    // Time
    jTextField6.setText(
            model.getValueAt(row, 5).toString()
    );

    // Notes
    Object notes =
            model.getValueAt(row, 6);

    jTextArea1.setText(
            notes == null ? "" : notes.toString()
    );

    // Status
    jComboBox1.setSelectedItem(
            model.getValueAt(row, 7).toString()
    );

    // Change Save button to Update
    jButton6.setText("Update");
}
private void selectComboBoxById(
        javax.swing.JComboBox<String> comboBox,
        int id) {

    String idText = id + " - ";

    for (int i = 0; i < comboBox.getItemCount(); i++) {

        String item = comboBox.getItemAt(i);

        if (item != null
                && item.startsWith(idText)) {

            comboBox.setSelectedIndex(i);
            return;
        }
    }
}
private void designSearchBar() {

        String placeholder =
                "Search appointment by patient, doctor, or date...";

        // Match Doctors search field
        jTextField1.setFont(
                new java.awt.Font(
                        "Segoe UI",
                        java.awt.Font.PLAIN,
                        12
                )
        );

        jTextField1.setForeground(
                new java.awt.Color(120, 120, 120)
        );

       

        jTextField1.addFocusListener(
                new java.awt.event.FocusAdapter() {

                        @Override
                        public void focusGained(
                                java.awt.event.FocusEvent evt) {

                                if (jTextField1.getText().equals(placeholder)) {

                                        jTextField1.setText("");

                                        jTextField1.setForeground(
                                                new java.awt.Color(40, 40, 40)
                                        );
                                }
                        }

                        @Override
                        public void focusLost(
                                java.awt.event.FocusEvent evt) {

                                if (jTextField1.getText().trim().isEmpty()) {

                                        jTextField1.setText(placeholder);

                                        jTextField1.setForeground(
                                                new java.awt.Color(120, 120, 120)
                                        );
                                }
                        }
                }
        );

     

        jButton3.setFocusPainted(false);
        jButton3.setContentAreaFilled(true);
}
private void makeAppointmentsResponsive() {

    addComponentListener(new java.awt.event.ComponentAdapter() {
        @Override
        public void componentResized(java.awt.event.ComponentEvent evt) {
            positionAppointments();
        }
    });

    java.awt.EventQueue.invokeLater(() -> positionAppointments());
}



private void fixAppointmentsSidebar() {

        int width = getContentPane().getWidth();
        int height = getContentPane().getHeight();

        if (width <= 0 || height <= 0) {
                return;
        }

        double scaleX = width / 1920.0;
        double scaleY = height / 1080.0;

        javax.swing.JButton[] buttons = {
                Dashboard,
                Patients,
                Doctors,
                Appointments,
                MedicalRecords,
                Services,
                Payments,
                Staff,
                UserAccounts,
                UserAccounts1,
                jButton1
        };

        int[] positionsY = {
                390, 445, 500, 555, 610,
                665, 720, 775, 830, 885, 955
        };
int buttonX = (int) (60 * scaleX);
int buttonWidth = (int) (260 * scaleX);
int buttonHeight = (int) (60 * scaleY);

        int fontSize = Math.max(
                18,
                (int) (24 * Math.min(scaleX, scaleY))
        );

        for (int i = 0; i < buttons.length; i++) {

                javax.swing.JButton button = buttons[i];

                button.setBounds(
                        buttonX,
                        (int) (positionsY[i] * scaleY),
                        buttonWidth,
                        buttonHeight
                );

                button.setFont(
                        new java.awt.Font(
                                "Segoe UI",
                                java.awt.Font.BOLD,
                                fontSize
                        )
                );

                button.setHorizontalAlignment(
                        javax.swing.SwingConstants.LEFT
                );

                button.setFocusPainted(false);
        }
}

private void positionAppointments() {

    int width = getContentPane().getWidth();
    int height = getContentPane().getHeight();

    if (width <= 0 || height <= 0) {
        return;
    }

    // =====================================
    // LEFT SIDEBAR BUTTONS
    // =====================================


        // =====================================
        // LEFT SIDEBAR BUTTONS
        // =====================================

        int sidebarWidth = Math.max(210, (int) (width * 0.205));
        int buttonX = Math.max(20, (int) (sidebarWidth * 0.19));
        int buttonWidth = sidebarWidth - buttonX - 18;

        javax.swing.JButton[] sidebarButtons = {
                Dashboard,
                Patients,
                Doctors,
                Appointments,
                MedicalRecords,
                Services,
                Payments,
                Staff,
                UserAccounts,
                UserAccounts1,
                jButton1
        };

        int navStartY = Math.max(
                205,
                Math.min(280, height / 3)
        );

        int availableHeight = height - navStartY - 12;

        int buttonHeight = Math.min(
                40,
                Math.max(24,
                        (availableHeight - 30) / sidebarButtons.length)
        );

        int buttonGap = Math.max(
                2,
                (availableHeight - buttonHeight * sidebarButtons.length)
                        / (sidebarButtons.length - 1)
        );

        int navY = navStartY;

        for (javax.swing.JButton button : sidebarButtons) {

                button.setBounds(
                        buttonX,
                        navY,
                        buttonWidth,
                        buttonHeight
                );

                button.setFont(
                        new java.awt.Font(
                                "Segoe UI",
                                java.awt.Font.BOLD,
                                height < 800 ? 14 : 17
                        )
                );

                button.setHorizontalAlignment(
                        javax.swing.SwingConstants.LEFT
                );

                navY += buttonHeight + buttonGap;
        }


    // =====================================
    // MAIN CONTENT AREA
    // =====================================
int contentX = sidebarWidth + 20;
int rightMargin = 18;
    int contentWidth = width - contentX - rightMargin;

    if (contentWidth <= 0) {
        return;
    }

    // =====================================
    // APPOINTMENTS TITLE
    // =====================================

    jButton11.setBounds(
            contentX,
            40,
            Math.min(350, contentWidth),
            60
    );


// =====================================
// SEARCH BAR AND CONTROLS
// Matches Patients and Doctors
// Reference resolution: 1920 x 1080
// =====================================

double scaleX = width / 1920.0;
double scaleY = height / 1080.0;

int searchY = (int) (160 * scaleY);
int searchHeight = (int) (50 * scaleY);

int searchX = (int) (400 * scaleX);
int searchWidth = (int) (720 * scaleX);

// SEARCH FIELD
jTextField1.setBounds(
        searchX,
        searchY,
        searchWidth,
        searchHeight
);

// SEARCH BUTTON
jButton3.setBounds(
        (int) (1120 * scaleX),
        searchY,
        (int) (50 * scaleX),
        searchHeight
);
scaleAppointmentSearchIcon();

// FILTER
Filter.setBounds(
        (int) (1180 * scaleX),
        searchY,
        (int) (130 * scaleX),
        searchHeight
);

// SORT - wider to display SORT BY: DEFAULT
Sort.setBounds(
        (int) (1320 * scaleX),
        searchY,
        (int) (200 * scaleX),
        searchHeight
);

// ORDER - moved right to prevent overlap
Order.setBounds(
        (int) (1530 * scaleX),
        searchY,
        (int) (160 * scaleX),
        searchHeight

);

// MATCH REFERENCE FONT
java.awt.Font controlFont =
        new java.awt.Font(
                "Segoe UI",
                java.awt.Font.BOLD,
                Math.max(11, (int) (14 * Math.min(scaleX, scaleY)))
        );

Filter.setFont(controlFont);
Sort.setFont(controlFont);
Order.setFont(controlFont);

jTextField1.setFont(
        new java.awt.Font(
                "Segoe UI",
                java.awt.Font.PLAIN,
                Math.max(12, (int) (16 * Math.min(scaleX, scaleY)))
        )
);
    // =====================================
    // APPOINTMENTS TABLE
    // =====================================

    int tableY = searchY + searchHeight + 16;

int detailsHeight = Math.min(
        285,
        Math.max(255, (int) (height * 0.36))
);

int bottomSpace = 12;
int panelGap = 12;

    int detailsY = height - detailsHeight - bottomSpace;

    int tableHeight = Math.max(
            120,
            detailsY - tableY - panelGap
    );

    jPanel2.setBounds(
            contentX,
            tableY,
            contentWidth,
            tableHeight
    );

    // BorderLayout manages the scroll pane
    jScrollPane1.revalidate();

    AppointmentsTable.setAutoResizeMode(
            javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS
    );

    try {
        javax.swing.table.TableColumn action =
                AppointmentsTable.getColumn("Action");

        action.setMinWidth(140);
        action.setPreferredWidth(155);

    } catch (IllegalArgumentException ignored) {
    }

    // =====================================
    // APPOINTMENTS DETAILS PANEL
    // =====================================

    jPanel1.setBounds(
            contentX,
            detailsY,
            contentWidth,
            detailsHeight
    );

    resizeAppointmentDetails();

    // =====================================
    // RESPONSIVE BACKGROUND
    // =====================================

    scaleAppointmentsBackground();
    
    // Match Patients and Doctors sidebar
fixAppointmentsSidebar();

    jPanel2.revalidate();
    jPanel2.repaint();

    jPanel1.revalidate();
    jPanel1.repaint();

    getContentPane().revalidate();
    getContentPane().repaint();
}

private void resizeAppointmentDetails() {

    int width = jPanel1.getWidth();

    if (width <= 0) {
        return;
    }

    jPanel1.setLayout(null);
    jPanel1.setOpaque(true);

    jPanel1.setBackground(
            new java.awt.Color(245, 252, 248)
    );

    jPanel1.setBorder(
            javax.swing.BorderFactory.createLineBorder(
                    new java.awt.Color(0, 102, 51), 2
            )
    );

    // PANEL TITLE
    jLabel2.setBounds(25, 12, 300, 35);

    jLabel2.setFont(
            new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 18)
    );

    jLabel2.setForeground(
            new java.awt.Color(0, 102, 51)
    );

    // THREE RESPONSIVE COLUMNS
    int margin = 25;
    int columnGap = 18;

    int columnWidth = (width - margin * 2 - columnGap * 2) / 3;

    int leftX = margin;
    int middleX = leftX + columnWidth + columnGap;
    int rightX = middleX + columnWidth + columnGap;

    int labelWidth = 75;
    int fieldHeight = 34;
    int fieldWidth = columnWidth - labelWidth - 10;

    int row1 = 60;
    int row2 = 108;
    int row3 = 156;

    // LEFT COLUMN: PATIENT, DOCTOR, SERVICE
    jLabel3.setBounds(
            leftX, row1, labelWidth, fieldHeight
    );

    PatientComboBox.setBounds(
            leftX + labelWidth,
            row1,
            fieldWidth,
            fieldHeight
    );

    jLabel4.setBounds(
            leftX, row2, labelWidth, fieldHeight
    );

    DoctorComboBox.setBounds(
            leftX + labelWidth,
            row2,
            fieldWidth,
            fieldHeight
    );

    jLabel5.setBounds(
            leftX, row3, labelWidth, fieldHeight
    );

    ServiceComboBox.setBounds(
            leftX + labelWidth,
            row3,
            fieldWidth,
            fieldHeight
    );

    // MIDDLE COLUMN: DATE, TIME, STATUS
    jLabel7.setBounds(
            middleX, row1, labelWidth, fieldHeight
    );

    jTextField5.setBounds(
            middleX + labelWidth,
            row1,
            fieldWidth,
            fieldHeight
    );

    jLabel8.setBounds(
            middleX, row2, labelWidth, fieldHeight
    );

    jTextField6.setBounds(
            middleX + labelWidth,
            row2,
            fieldWidth,
            fieldHeight
    );

    jLabel9.setBounds(
            middleX, row3, labelWidth, fieldHeight
    );

    jComboBox1.setBounds(
            middleX + labelWidth,
            row3,
            fieldWidth,
            fieldHeight
    );

    // RIGHT COLUMN: NOTES
    jLabel10.setBounds(
            rightX, row1, 60, fieldHeight
    );

    int notesX = rightX + 65;
    int notesWidth = Math.max(100, width - notesX - margin);

    jScrollPane2.setBounds(
            notesX,
            row1,
            notesWidth,
            112
    );

    // CLEAR AND SAVE BUTTONS
    int buttonWidth = 100;
    int buttonHeight = 36;
    int buttonGap = 12;
int buttonY = jPanel1.getHeight() - buttonHeight - 18;
    int saveX = width - margin - buttonWidth;
    int clearX = saveX - buttonWidth - buttonGap;

    jButton5.setBounds(
            clearX,
            buttonY,
            buttonWidth,
            buttonHeight
    );

    jButton6.setBounds(
            saveX,
            buttonY,
            buttonWidth,
            buttonHeight
    );

    jPanel1.revalidate();
    jPanel1.repaint();
}

private void fixAppointmentsHeader() {

    javax.swing.table.JTableHeader header =
            AppointmentsTable.getTableHeader();

    header.setDefaultRenderer(
            new javax.swing.table.DefaultTableCellRenderer() {

                @Override
                public java.awt.Component getTableCellRendererComponent(
                        javax.swing.JTable table,
                        Object value,
                        boolean isSelected,
                        boolean hasFocus,
                        int row,
                        int column) {

                    javax.swing.JLabel label =
                            (javax.swing.JLabel) super
                                    .getTableCellRendererComponent(
                                            table, value, isSelected,
                                            hasFocus, row, column
                                    );

                    label.setBackground(
                            new java.awt.Color(0, 102, 51)
                    );

                    label.setForeground(java.awt.Color.WHITE);
                    label.setOpaque(true);

                    label.setFont(
                            new java.awt.Font(
                                    "Segoe UI",
                                    java.awt.Font.BOLD,
                                    14
                            )
                    );

                    label.setHorizontalAlignment(
                            javax.swing.SwingConstants.CENTER
                    );

                    return label;
                }
            }
    );

    header.setPreferredSize(
            new java.awt.Dimension(
                    header.getPreferredSize().width, 38
            )
    );

    header.repaint();
}

private void designAppointmentsTable() {

        // =========================
        // TABLE BODY
        // =========================
        AppointmentsTable.setFont(
                new java.awt.Font(
                        "Segoe UI",
                        java.awt.Font.PLAIN,
                        14
                )
        );

        AppointmentsTable.setRowHeight(38);

        AppointmentsTable.setBackground(
                java.awt.Color.WHITE
        );

        AppointmentsTable.setForeground(
                new java.awt.Color(40, 40, 40)
        );

        // Light green when a row is selected
        AppointmentsTable.setSelectionBackground(
                new java.awt.Color(222, 246, 236)
        );

        AppointmentsTable.setSelectionForeground(
                new java.awt.Color(0, 102, 51)
        );

        AppointmentsTable.setGridColor(
                new java.awt.Color(220, 235, 228)
        );

        AppointmentsTable.setShowHorizontalLines(true);
        AppointmentsTable.setShowVerticalLines(false);

        AppointmentsTable.setIntercellSpacing(
                new java.awt.Dimension(0, 1)
        );


        // =========================
        // GREEN HEADER
        // =========================
        javax.swing.table.JTableHeader header =
                AppointmentsTable.getTableHeader();

        header.setPreferredSize(
                new java.awt.Dimension(
                        header.getPreferredSize().width,
                        38
                )
        );

        header.setReorderingAllowed(false);


        javax.swing.table.DefaultTableCellRenderer headerRenderer =
                new javax.swing.table.DefaultTableCellRenderer();

        headerRenderer.setBackground(
                new java.awt.Color(0, 102, 51)
        );

        headerRenderer.setForeground(
                java.awt.Color.WHITE
        );

        headerRenderer.setFont(
                new java.awt.Font(
                        "Segoe UI",
                        java.awt.Font.BOLD,
                        14
                )
        );

        headerRenderer.setHorizontalAlignment(
                javax.swing.SwingConstants.CENTER
        );

        headerRenderer.setOpaque(true);


        // Apply green design to every column
        for (int i = 0;
                i < AppointmentsTable.getColumnCount();
                i++) {

                AppointmentsTable.getColumnModel()
                        .getColumn(i)
                        .setHeaderRenderer(headerRenderer);
        }


        // =========================
        // CENTER TABLE CONTENT
        // =========================
        javax.swing.table.DefaultTableCellRenderer center =
                new javax.swing.table.DefaultTableCellRenderer();

        center.setHorizontalAlignment(
                javax.swing.SwingConstants.CENTER
        );

        for (int i = 0;
                i < AppointmentsTable.getColumnCount();
                i++) {

                AppointmentsTable.getColumnModel()
                        .getColumn(i)
                        .setCellRenderer(center);
        }


        // =========================
        // WHITE EMPTY AREA
        // =========================
        jScrollPane1.getViewport().setBackground(
                java.awt.Color.WHITE
        );

        AppointmentsTable.getTableHeader().repaint();
        AppointmentsTable.repaint();
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        Patients = new javax.swing.JButton();
        MedicalRecords = new javax.swing.JButton();
        Services = new javax.swing.JButton();
        Payments = new javax.swing.JButton();
        Staff = new javax.swing.JButton();
        Dashboard = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        UserAccounts = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        AppointmentsTable = new javax.swing.JTable();
        Doctors = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        Appointments = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jTextField6 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        PatientComboBox = new javax.swing.JComboBox<>();
        DoctorComboBox = new javax.swing.JComboBox<>();
        ServiceComboBox = new javax.swing.JComboBox<>();
        Filter = new javax.swing.JComboBox<>();
        Sort = new javax.swing.JComboBox<>();
        Order = new javax.swing.JComboBox<>();
        UserAccounts1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton1.setForeground(new java.awt.Color(204, 0, 0));
        jButton1.setText("Log Out");
        jButton1.setBorderPainted(false);
        jButton1.setContentAreaFilled(false);
        jButton1.setDefaultCapable(false);
        jButton1.setFocusPainted(false);
        jButton1.setFocusable(false);
        jButton1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton1.addActionListener(this::jButton1ActionPerformed);
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 990, 260, 60));

        Patients.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Patients.setForeground(new java.awt.Color(255, 255, 255));
        Patients.setText("Patients");
        Patients.setBorderPainted(false);
        Patients.setContentAreaFilled(false);
        Patients.setDefaultCapable(false);
        Patients.setFocusPainted(false);
        Patients.setFocusable(false);
        Patients.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Patients.addActionListener(this::PatientsActionPerformed);
        getContentPane().add(Patients, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 450, 260, 60));

        MedicalRecords.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        MedicalRecords.setForeground(new java.awt.Color(255, 255, 255));
        MedicalRecords.setText("Medical Records");
        MedicalRecords.setBorderPainted(false);
        MedicalRecords.setContentAreaFilled(false);
        MedicalRecords.setDefaultCapable(false);
        MedicalRecords.setFocusPainted(false);
        MedicalRecords.setFocusable(false);
        MedicalRecords.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        MedicalRecords.addActionListener(this::MedicalRecordsActionPerformed);
        getContentPane().add(MedicalRecords, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 610, 260, 90));

        Services.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Services.setForeground(new java.awt.Color(255, 255, 255));
        Services.setText("Services");
        Services.setBorderPainted(false);
        Services.setContentAreaFilled(false);
        Services.setDefaultCapable(false);
        Services.setFocusPainted(false);
        Services.setFocusable(false);
        Services.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Services.addActionListener(this::ServicesActionPerformed);
        getContentPane().add(Services, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 670, 260, 90));

        Payments.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Payments.setForeground(new java.awt.Color(255, 255, 255));
        Payments.setText("Payments");
        Payments.setBorderPainted(false);
        Payments.setContentAreaFilled(false);
        Payments.setDefaultCapable(false);
        Payments.setFocusPainted(false);
        Payments.setFocusable(false);
        Payments.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Payments.addActionListener(this::PaymentsActionPerformed);
        getContentPane().add(Payments, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 730, 260, 80));

        Staff.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Staff.setForeground(new java.awt.Color(255, 255, 255));
        Staff.setText("Staff");
        Staff.setBorderPainted(false);
        Staff.setContentAreaFilled(false);
        Staff.setDefaultCapable(false);
        Staff.setFocusPainted(false);
        Staff.setFocusable(false);
        Staff.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Staff.addActionListener(this::StaffActionPerformed);
        getContentPane().add(Staff, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 780, 260, 80));

        Dashboard.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Dashboard.setForeground(new java.awt.Color(255, 255, 255));
        Dashboard.setText("Dashboard");
        Dashboard.setBorderPainted(false);
        Dashboard.setContentAreaFilled(false);
        Dashboard.setDefaultCapable(false);
        Dashboard.setFocusPainted(false);
        Dashboard.setFocusable(false);
        Dashboard.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Dashboard.addActionListener(this::DashboardActionPerformed);
        getContentPane().add(Dashboard, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 380, 260, 80));

        jButton11.setFont(new java.awt.Font("Segoe UI", 1, 40)); // NOI18N
        jButton11.setText("Appointments");
        jButton11.setBorderPainted(false);
        jButton11.setContentAreaFilled(false);
        jButton11.setDefaultCapable(false);
        jButton11.setFocusPainted(false);
        jButton11.setFocusable(false);
        jButton11.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton11.addActionListener(this::jButton11ActionPerformed);
        getContentPane().add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 40, 360, -1));

        UserAccounts.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        UserAccounts.setForeground(new java.awt.Color(255, 255, 255));
        UserAccounts.setText("User Accounts");
        UserAccounts.setBorderPainted(false);
        UserAccounts.setContentAreaFilled(false);
        UserAccounts.setDefaultCapable(false);
        UserAccounts.setFocusPainted(false);
        UserAccounts.setFocusable(false);
        UserAccounts.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        UserAccounts.addActionListener(this::UserAccountsActionPerformed);
        getContentPane().add(UserAccounts, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 830, 260, 80));

        jPanel2.setBackground(new java.awt.Color(222, 246, 236));

        AppointmentsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Appointment ID", "Patient ID", "Doctor ID", "Service ID", "Appointment Date", "Appointment Time", "Notes", "Status"
            }
        ));
        AppointmentsTable.setFocusCycleRoot(true);
        AppointmentsTable.setGridColor(new java.awt.Color(231, 250, 250));
        AppointmentsTable.setShowGrid(true);
        AppointmentsTable.setSurrendersFocusOnKeystroke(true);
        jScrollPane1.setViewportView(AppointmentsTable);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1474, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 497, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 230, 1480, 500));

        Doctors.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Doctors.setForeground(new java.awt.Color(255, 255, 255));
        Doctors.setText("Doctors");
        Doctors.setBorderPainted(false);
        Doctors.setContentAreaFilled(false);
        Doctors.setDefaultCapable(false);
        Doctors.setFocusPainted(false);
        Doctors.setFocusable(false);
        Doctors.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Doctors.addActionListener(this::DoctorsActionPerformed);
        getContentPane().add(Doctors, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 500, 260, 70));

        jTextField1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jTextField1.setText("Search appointment by patient, doctor, or date...");
        jTextField1.addActionListener(this::jTextField1ActionPerformed);
        getContentPane().add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 160, 720, 50));

        Appointments.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Appointments.setForeground(new java.awt.Color(0, 102, 51));
        Appointments.setText("Appointments");
        Appointments.setDefaultCapable(false);
        Appointments.setFocusPainted(false);
        Appointments.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Appointments.addActionListener(this::AppointmentsActionPerformed);
        getContentPane().add(Appointments, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 570, 260, 50));

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-search-47.png"))); // NOI18N
        jButton3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 51)));
        jButton3.setBorderPainted(false);
        jButton3.addActionListener(this::jButton3ActionPerformed);
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 160, -1, -1));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 102, 51));
        jLabel2.setText("Appointments Details");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Patient");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Doctor");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setText("Service");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setText("Date");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel8.setText("Time");

        jButton5.setBackground(new java.awt.Color(240, 250, 244));
        jButton5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton5.setForeground(new java.awt.Color(0, 102, 51));
        jButton5.setText("Clear");

        jButton6.setBackground(new java.awt.Color(0, 102, 51));
        jButton6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.setText("Save");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel9.setText("Status");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Scheduled", "Pending", "Completed", "Cancelled" }));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel10.setText("Notes");

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane2.setViewportView(jTextArea1);

        PatientComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        DoctorComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        ServiceComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jLabel2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(PatientComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(DoctorComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ServiceComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(155, 155, 155)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addGap(33, 33, 33)
                                .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel9))
                                .addGap(24, 24, 24)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jTextField6)
                                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(53, 53, 53)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jButton5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton6)))))
                .addContainerGap(349, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(PatientComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(DoctorComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(ServiceComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel7)
                                    .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel10))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(8, 8, 8)
                                        .addComponent(jLabel8))))
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel9)
                                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 740, 1480, 250));

        Filter.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Filter.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "FILTER BY: ALL", "Scheduled", "Pending", "Completed", "Cancelled" }));
        Filter.addActionListener(this::FilterActionPerformed);
        getContentPane().add(Filter, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 160, 120, 50));

        Sort.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Sort.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SORT BY: DEFAULT", "ID", "Date", "Time" }));
        Sort.addActionListener(this::SortActionPerformed);
        getContentPane().add(Sort, new org.netbeans.lib.awtextra.AbsoluteConstraints(1310, 160, 150, 50));

        Order.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Order.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ORDER", "ASCENDING", "DESCENDING" }));
        Order.addActionListener(this::OrderActionPerformed);
        getContentPane().add(Order, new org.netbeans.lib.awtextra.AbsoluteConstraints(1470, 160, 100, 50));

        UserAccounts1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        UserAccounts1.setForeground(new java.awt.Color(255, 255, 255));
        UserAccounts1.setText("Archive");
        UserAccounts1.setBorderPainted(false);
        UserAccounts1.setContentAreaFilled(false);
        UserAccounts1.setDefaultCapable(false);
        UserAccounts1.setFocusPainted(false);
        UserAccounts1.setFocusable(false);
        UserAccounts1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        UserAccounts1.addActionListener(this::UserAccounts1ActionPerformed);
        getContentPane().add(UserAccounts1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 890, 260, 80));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Dashgh.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1930, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void PatientsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PatientsActionPerformed
    Patients patients = new Patients();
    patients.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_PatientsActionPerformed

    private void MedicalRecordsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MedicalRecordsActionPerformed
    MedicalRecords records = new MedicalRecords();
    records.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_MedicalRecordsActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton11ActionPerformed

    private void DoctorsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DoctorsActionPerformed
        Doctors doctors = new Doctors();
        doctors.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_DoctorsActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
                searchAppointments();

    }//GEN-LAST:event_jButton3ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
               searchAppointments();
 // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void ServicesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ServicesActionPerformed
    Services services = new Services();
    services.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_ServicesActionPerformed

    private void PaymentsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PaymentsActionPerformed
    Payments payments = new Payments();
    payments.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_PaymentsActionPerformed

    private void DashboardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DashboardActionPerformed
    Dashboard dashboard = new Dashboard();
    dashboard.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_DashboardActionPerformed

    private void AppointmentsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AppointmentsActionPerformed
    Appointments appointments = new Appointments();
    appointments.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_AppointmentsActionPerformed

    private void StaffActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StaffActionPerformed
    Staff staff = new Staff();
    staff.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_StaffActionPerformed

    private void UserAccountsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UserAccountsActionPerformed
    UserAccounts accounts = new UserAccounts();
    accounts.setVisible(true);
    this.dispose();
        // TODO add your handling code here:
    }//GEN-LAST:event_UserAccountsActionPerformed

    private void FilterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FilterActionPerformed
        filterAppointments();

        // TODO add your handling code here:
    }//GEN-LAST:event_FilterActionPerformed

    private void SortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SortActionPerformed
        sortAppointments();

        // TODO add your handling code here:
    }//GEN-LAST:event_SortActionPerformed

    private void OrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OrderActionPerformed
        sortAppointments();
        // TODO add your handling code here:
    }//GEN-LAST:event_OrderActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    UserSession.logout();
    SignIn logout = new SignIn();
    logout.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void UserAccounts1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UserAccounts1ActionPerformed
        Archive archive = new Archive();
        archive.setVisible(true);
        this.dispose();     // TODO add your handling code here:
    }//GEN-LAST:event_UserAccounts1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Appointments().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Appointments;
    private javax.swing.JTable AppointmentsTable;
    private javax.swing.JButton Dashboard;
    private javax.swing.JComboBox<String> DoctorComboBox;
    private javax.swing.JButton Doctors;
    private javax.swing.JComboBox<String> Filter;
    private javax.swing.JButton MedicalRecords;
    private javax.swing.JComboBox<String> Order;
    private javax.swing.JComboBox<String> PatientComboBox;
    private javax.swing.JButton Patients;
    private javax.swing.JButton Payments;
    private javax.swing.JComboBox<String> ServiceComboBox;
    private javax.swing.JButton Services;
    private javax.swing.JComboBox<String> Sort;
    private javax.swing.JButton Staff;
    private javax.swing.JButton UserAccounts;
    private javax.swing.JButton UserAccounts1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    // End of variables declaration//GEN-END:variables
}
