import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class MedicalRecords extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(MedicalRecords.class.getName());
        private Connection conn;
        private PreparedStatement pst;
        private ResultSet rs;

    private TableRowSorter<DefaultTableModel> sorter;
    private int editingRecordId = -1;
    private java.awt.Image originalMedicalBackground;

    /**
     * Creates new form MedicalRecords
     */
    public MedicalRecords() {

    initComponents();
    getContentPane().setLayout(null);

    setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
    setupMedicalRecordsActions();
    jComboBox1.setModel(
        new javax.swing.DefaultComboBoxModel<>(
                new String[]{"Active", "Inactive"}
        )
);


    designMedicalRecordsTable();
    designSearchBar();
    designMedicalRecordsPanel();

    connectDatabase();

    if (conn != null) {
        loadPatientsComboBox();
        loadDoctorsComboBox();

        PatientIDComboBox.addActionListener(
                e -> loadAppointmentsComboBox()
        );

        loadAppointmentsComboBox();
        loadMedicalRecords();
    }

    DefaultTableModel model =
            (DefaultTableModel) MedicalRecordsTable.getModel();

    sorter = new TableRowSorter<>(model);
    MedicalRecordsTable.setRowSorter(sorter);
    
    Filter.setModel(
        new javax.swing.DefaultComboBoxModel<>(
                new String[]{
                        "FILTER BY: ALL",
                        "Active",
                        "Inactive"
                }
        )
);
    
jTextField1.getDocument().addDocumentListener(
        new javax.swing.event.DocumentListener() {

            @Override
            public void insertUpdate(
                    javax.swing.event.DocumentEvent e) {
                searchMedicalRecords();
            }

            @Override
            public void removeUpdate(
                    javax.swing.event.DocumentEvent e) {
                searchMedicalRecords();
            }

            @Override
            public void changedUpdate(
                    javax.swing.event.DocumentEvent e) {
                searchMedicalRecords();
            }
        }
);


    jButton5.addActionListener(
            e -> clearMedicalRecordForm()
    );

    jButton6.addActionListener(
            e -> saveMedicalRecord()
    );
    
jPanel1.setLayout(null);

addComponentListener(
        new java.awt.event.ComponentAdapter() {
            @Override
            public void componentResized(
                    java.awt.event.ComponentEvent evt) {
                fixMedicalRecordsLayout();
            }
        }
);

java.awt.EventQueue.invokeLater(() -> {

        fixMedicalRecordsLayout();

        // Remove automatic focus from the search bar
        getContentPane().setFocusable(true);
        getContentPane().requestFocusInWindow();

        // Remove text selection
        jTextField1.select(0, 0);
});

}
    
private class MedicalActionRenderer extends javax.swing.JPanel
        implements javax.swing.table.TableCellRenderer {

        MedicalActionRenderer() {
                setLayout(new java.awt.FlowLayout(
                        java.awt.FlowLayout.CENTER, 5, 4));
                setBackground(java.awt.Color.WHITE);

                javax.swing.JButton edit = new javax.swing.JButton("Edit");
                javax.swing.JButton remove = new javax.swing.JButton("Remove");

                styleMedicalButton(edit, new java.awt.Color(0, 102, 51));
                styleMedicalButton(remove, new java.awt.Color(190, 40, 40));

                add(edit);
                add(remove);
        }

        @Override
        public java.awt.Component getTableCellRendererComponent(
                javax.swing.JTable table, Object value,
                boolean selected, boolean focus, int row, int column) {

                setBackground(java.awt.Color.WHITE);
                return this;
        }
}

private class MedicalActionEditor extends javax.swing.AbstractCellEditor
        implements javax.swing.table.TableCellEditor {

        private final javax.swing.JPanel panel =
                new javax.swing.JPanel(new java.awt.FlowLayout(
                        java.awt.FlowLayout.CENTER, 5, 4));

        private int currentRow;

        MedicalActionEditor() {
                panel.setBackground(java.awt.Color.WHITE);

                javax.swing.JButton edit = new javax.swing.JButton("Edit");
                javax.swing.JButton remove = new javax.swing.JButton("Remove");

                styleMedicalButton(edit, new java.awt.Color(0, 102, 51));
                styleMedicalButton(remove, new java.awt.Color(190, 40, 40));

                edit.addActionListener(e -> {
                        int row = currentRow;
                        fireEditingStopped();
                        editMedicalRecord(row);
                });

                remove.addActionListener(e -> {
                        int row = currentRow;
                        fireEditingStopped();
                        archiveMedicalRecord(row);
                });

                panel.add(edit);
                panel.add(remove);
        }

        @Override
        public java.awt.Component getTableCellEditorComponent(
                javax.swing.JTable table, Object value,
                boolean selected, int row, int column) {

                currentRow = table.convertRowIndexToModel(row);
                return panel;
        }

        @Override
        public Object getCellEditorValue() {
                return "";
        }
}

private void styleMedicalButton(
        javax.swing.JButton button, java.awt.Color color) {

        button.setBackground(color);
        button.setForeground(java.awt.Color.WHITE);
        button.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 11));
        button.setFocusPainted(false);
        button.setPreferredSize(new java.awt.Dimension(
                button.getText().equals("Edit") ? 58 : 78, 26));
}

private void selectMedicalCombo(
        javax.swing.JComboBox<String> combo, int id) {

        String prefix = id + " - ";

        for (int i = 0; i < combo.getItemCount(); i++) {
                String item = combo.getItemAt(i);

                if (item != null && item.startsWith(prefix)) {
                        combo.setSelectedIndex(i);
                        return;
                }
        }
}

private void editMedicalRecord(int row) {

        DefaultTableModel model =
                (DefaultTableModel) MedicalRecordsTable.getModel();

        editingRecordId = Integer.parseInt(
                model.getValueAt(row, 0).toString());

        selectMedicalCombo(PatientIDComboBox,
                Integer.parseInt(model.getValueAt(row, 1).toString()));

        selectMedicalCombo(DoctorIDComboBox,
                Integer.parseInt(model.getValueAt(row, 2).toString()));

        selectMedicalCombo(AppointmentIDComboBox,
                Integer.parseInt(model.getValueAt(row, 3).toString()));

        DiagnosisField.setText(String.valueOf(model.getValueAt(row, 4)));
        TreatmentField.setText(String.valueOf(model.getValueAt(row, 5)));

        Object remarks = model.getValueAt(row, 6);
        RemarksNotes.setText(remarks == null ? "" : remarks.toString());

      RecordField.setText(String.valueOf(model.getValueAt(row, 7)));

Object statusValue = model.getValueAt(row, 8);

jComboBox1.setSelectedItem(
        statusValue == null ? "Active" : statusValue.toString()
);

jButton6.setText("Update");
}

private void archiveMedicalRecord(int row) {

        DefaultTableModel model =
                (DefaultTableModel) MedicalRecordsTable.getModel();

        int id = Integer.parseInt(
                model.getValueAt(row, 0).toString());

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Move Medical Record #" + id + " to Archive?",
                "Confirm Archive",
                JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION) {
                return;
        }

        String sql = "UPDATE MedicalRecords "
                + "SET status = 'Archived' WHERE record_id = ?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setInt(1, id);
                ps.executeUpdate();

                if (editingRecordId == id) {
                        clearMedicalRecordForm();
                }

                loadMedicalRecords();

                JOptionPane.showMessageDialog(
                        this, "Medical record moved to Archive.");

        } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, e.getMessage());
        }
}


private void setupMedicalRecordsActions() {

        DefaultTableModel model = new DefaultTableModel(
                new Object[][]{},
                new String[]{
                        "Record ID", "Patient ID", "Doctor ID",
                        "Appointment ID", "Diagnosis", "Treatment",
                        "Remarks", "Record Date", "Status", "Action"
                }
        ) {
                @Override
                public boolean isCellEditable(int row, int column) {
                        return column == 9;
                }
        };

        MedicalRecordsTable.setModel(model);
        MedicalRecordsTable.setSurrendersFocusOnKeystroke(false);

        javax.swing.table.TableColumn action =
                MedicalRecordsTable.getColumnModel().getColumn(9);

        action.setPreferredWidth(170);
        action.setCellRenderer(new MedicalActionRenderer());
        action.setCellEditor(new MedicalActionEditor());
}


private void designMedicalRecordsPanel() {
    jPanel1.setBackground(new java.awt.Color(222, 246, 236));

    jPanel1.setBorder(
            javax.swing.BorderFactory.createLineBorder(
                    new java.awt.Color(0, 102, 51),
                    2
            )
    );
}

private void loadMedicalRecords() {

        if (conn == null) {
                return;
        }

        DefaultTableModel model =
                (DefaultTableModel) MedicalRecordsTable.getModel();

        model.setRowCount(0);

        String sql =
                "SELECT record_id, patient_id, doctor_id, "
                + "appointment_id, diagnosis, treatment, "
                + "remarks, record_date, status "
                + "FROM MedicalRecords "
                + "WHERE status IN ('Active', 'Inactive') "
                + "ORDER BY record_id ASC";

        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet result = ps.executeQuery()) {

                while (result.next()) {

                        model.addRow(new Object[]{
                                result.getInt("record_id"),
                                result.getInt("patient_id"),
                                result.getInt("doctor_id"),
                                result.getInt("appointment_id"),
                                result.getString("diagnosis"),
                                result.getString("treatment"),
                                result.getString("remarks"),
                                result.getDate("record_date"),
                                result.getString("status"),
                                ""
                        });
                }

        } catch (SQLException e) {
                JOptionPane.showMessageDialog(
                        this,
                        "Failed to load medical records:\n"
                        + e.getMessage()
                );
        }
}

            
private void connectDatabase() {
    try {
        Class.forName("com.mysql.cj.jdbc.Driver");

        conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/ClinicManagementSystem",
                "root",
                ""
        );

        System.out.println("Database connected successfully!");

    } catch (ClassNotFoundException | SQLException e) {
        JOptionPane.showMessageDialog(this,
                "Database connection failed:\n" + e.getMessage());
    }
}

private void loadPatientsComboBox() {
    PatientIDComboBox.removeAllItems();
    PatientIDComboBox.addItem("Select Patient");

    String sql = "SELECT patient_id, first_name, last_name "
            + "FROM Patients WHERE status <> 'Archived' "
            + "ORDER BY first_name, last_name";

    try (PreparedStatement ps = conn.prepareStatement(sql);
         ResultSet result = ps.executeQuery()) {

        while (result.next()) {
            PatientIDComboBox.addItem(
                    result.getInt("patient_id") + " - "
                    + result.getString("first_name") + " "
                    + result.getString("last_name")
            );
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, e.getMessage());
    }
}

private void loadDoctorsComboBox() {
    DoctorIDComboBox.removeAllItems();
    DoctorIDComboBox.addItem("Select Doctor");

    String sql = "SELECT doctor_id, first_name, last_name "
            + "FROM Doctors WHERE status <> 'Archived' "
            + "ORDER BY first_name, last_name";

    try (PreparedStatement ps = conn.prepareStatement(sql);
         ResultSet result = ps.executeQuery()) {

        while (result.next()) {
            DoctorIDComboBox.addItem(
                    result.getInt("doctor_id") + " - Dr. "
                    + result.getString("first_name") + " "
                    + result.getString("last_name")
            );
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, e.getMessage());
    }
}

private void loadAppointmentsComboBox() {
    AppointmentIDComboBox.removeAllItems();
    AppointmentIDComboBox.addItem("Select Appointment");

    if (PatientIDComboBox.getSelectedIndex() <= 0) {
        return;
    }

    String selectedPatient =
            PatientIDComboBox.getSelectedItem().toString();

    int patientId = Integer.parseInt(
            selectedPatient.split(" - ", 2)[0]
    );

    String sql = "SELECT appointment_id, appointment_date "
            + "FROM Appointments "
            + "WHERE patient_id = ? AND status <> 'Cancelled' "
            + "ORDER BY appointment_date DESC";

    try (PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setInt(1, patientId);

        try (ResultSet result = ps.executeQuery()) {
            while (result.next()) {
                AppointmentIDComboBox.addItem(
                        result.getInt("appointment_id") + " - "
                        + result.getDate("appointment_date")
                );
            }
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, e.getMessage());
    }
}



            


private void saveMedicalRecord() {

        if (conn == null) {
                JOptionPane.showMessageDialog(
                        this, "Database is not connected.");
                return;
        }

        if (PatientIDComboBox.getSelectedIndex() <= 0
                || DoctorIDComboBox.getSelectedIndex() <= 0
                || AppointmentIDComboBox.getSelectedIndex() <= 0) {

                JOptionPane.showMessageDialog(
                        this,
                        "Please select a patient, doctor, and appointment.");
                return;
        }

        String diagnosis = DiagnosisField.getText().trim();
        String treatment = TreatmentField.getText().trim();
        String remarks = RemarksNotes.getText().trim();
        String dateText = RecordField.getText().trim();
        String status = jComboBox1.getSelectedItem().toString();
        

        if (diagnosis.isEmpty() || dateText.isEmpty()) {
                JOptionPane.showMessageDialog(
                        this, "Diagnosis and record date are required.");
                return;
        }

        try {
                int patientId = Integer.parseInt(
                        PatientIDComboBox.getSelectedItem()
                                .toString().split(" - ", 2)[0]);

                int doctorId = Integer.parseInt(
                        DoctorIDComboBox.getSelectedItem()
                                .toString().split(" - ", 2)[0]);

                int appointmentId = Integer.parseInt(
                        AppointmentIDComboBox.getSelectedItem()
                                .toString().split(" - ", 2)[0]);

                java.sql.Date recordDate =
                        java.sql.Date.valueOf(dateText);

                boolean updating = editingRecordId != -1;

String sql = updating
        ? "UPDATE MedicalRecords SET "
        + "patient_id=?, doctor_id=?, appointment_id=?, "
        + "diagnosis=?, treatment=?, remarks=?, "
        + "record_date=?, status=? "
        + "WHERE record_id=? AND status <> 'Archived'"
        : "INSERT INTO MedicalRecords "
        + "(patient_id, doctor_id, appointment_id, "
        + "diagnosis, treatment, remarks, record_date, status) "
        + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                try (PreparedStatement ps = conn.prepareStatement(sql)) {

                        ps.setInt(1, patientId);
                        ps.setInt(2, doctorId);
                        ps.setInt(3, appointmentId);
                        ps.setString(4, diagnosis);
                        ps.setString(5, treatment);
                        ps.setString(6, remarks);
                       ps.setDate(7, recordDate);
ps.setString(8, status);

if (updating) {
        ps.setInt(9, editingRecordId);
}

                        int affected = ps.executeUpdate();

                        if (affected == 0) {
                                JOptionPane.showMessageDialog(
                                        this, "No active record was updated.");
                                return;
                        }
                }

                JOptionPane.showMessageDialog(
                        this,
                        updating
                                ? "Medical record updated successfully!"
                                : "Medical record saved successfully!"
                );

                clearMedicalRecordForm();
                loadMedicalRecords();

        } catch (IllegalArgumentException e) {
                JOptionPane.showMessageDialog(
                        this, "Invalid date. Use YYYY-MM-DD format.");

        } catch (SQLException e) {
                JOptionPane.showMessageDialog(
                        this, "Failed to save medical record:\n"
                        + e.getMessage());
        }
}



private void clearMedicalRecordForm() {
    editingRecordId = -1;
jButton6.setText("Save");

    PatientIDComboBox.setSelectedIndex(0);
    DoctorIDComboBox.setSelectedIndex(0);

    AppointmentIDComboBox.removeAllItems();
    AppointmentIDComboBox.addItem("Select Appointment");

    DiagnosisField.setText("");
    TreatmentField.setText("");
    RecordField.setText("");
    jComboBox1.setSelectedItem("Active");

    PatientIDComboBox.requestFocus();
}


private void searchMedicalRecords() {

        if (sorter == null) {
                return;
        }

        String searchText = jTextField1.getText().trim();

        if (searchText.equalsIgnoreCase(
                "Search medical records...")) {
                searchText = "";
        }

        String selectedFilter =
                Filter.getSelectedItem() == null
                ? "FILTER BY: ALL"
                : Filter.getSelectedItem().toString().trim();

        java.util.List<
                javax.swing.RowFilter<DefaultTableModel, Integer>>
                filters = new java.util.ArrayList<>();

        // FILTER BY STATUS
        if (selectedFilter.equalsIgnoreCase("Active")
                || selectedFilter.equalsIgnoreCase("Inactive")) {

                filters.add(
                        javax.swing.RowFilter.regexFilter(
                                "(?i)^"
                                + java.util.regex.Pattern.quote(selectedFilter)
                                + "$",
                                8
                        )
                );
        }

        // SEARCH MEDICAL RECORDS
        if (!searchText.isEmpty()) {

                String pattern = "(?i)"
                        + java.util.regex.Pattern.quote(searchText);

                filters.add(
                        javax.swing.RowFilter.regexFilter(
                                pattern,
                                0, 1, 2, 3, 4, 5, 6, 7, 8
                        )
                );
        }

        // APPLY SEARCH AND FILTER
        if (filters.isEmpty()) {

                sorter.setRowFilter(null);

        } else {

                sorter.setRowFilter(
                        javax.swing.RowFilter.andFilter(filters)
                );
        }
}

private void sortMedicalRecords() {

        if (sorter == null) {
                return;
        }

        String selectedSort =
                Sort.getSelectedItem().toString();

        String selectedOrder =
                Order.getSelectedItem().toString();

        if (selectedSort.equals("SORT BY: DEFAULT")) {
                sorter.setSortKeys(null);
                return;
        }

        int column = selectedSort.equals("Record Date") ? 7 : 0;

        javax.swing.SortOrder direction =
                selectedOrder.equals("DESCENDING")
                ? javax.swing.SortOrder.DESCENDING
                : javax.swing.SortOrder.ASCENDING;

        sorter.setSortKeys(
                java.util.Collections.singletonList(
                        new javax.swing.RowSorter.SortKey(
                                column,
                                direction
                        )
                )
        );

        sorter.sort();
}
private void fixMedicalRecordsSidebar() {

        int width = getContentPane().getWidth();
        int height = getContentPane().getHeight();

        if (width <= 0 || height <= 0) {
                return;
        }

        double scaleX = width / 1920.0;
        double scaleY = height / 1080.0;

        javax.swing.JButton[] buttons = {
                jButton10,      // Dashboard
                Patients,
                Doctors,
                Appointments,
                MedicalRecords,
                Services,
                Payments,
                Staff,
                UserAccounts,
                UserAccounts1,  // Archive
                jButton1        // Log Out
        };

        int[] positionsY = {
                390, 445, 500, 555, 610,
                665, 720, 775, 830, 885, 955
        };

        int buttonX = (int) (60 * scaleX);
        int buttonWidth = (int) (260 * scaleX);
        int buttonHeight = (int) (60 * scaleY);

        int fontSize = Math.max(
                18,
                (int) (24 * Math.min(scaleX, scaleY))
        );

        for (int i = 0; i < buttons.length; i++) {

                javax.swing.JButton button = buttons[i];

                button.setBounds(
                        buttonX,
                        (int) (positionsY[i] * scaleY),
                        buttonWidth,
                        buttonHeight
                );

                button.setFont(
                        new java.awt.Font(
                                "Segoe UI",
                                java.awt.Font.BOLD,
                                fontSize
                        )
                );

                button.setHorizontalAlignment(
                        javax.swing.SwingConstants.LEFT
                );

                button.setFocusPainted(false);
        }
}


private void fixMedicalRecordsLayout() {
    

    int width = getContentPane().getWidth();
    int height = getContentPane().getHeight();

    if (width <= 0 || height <= 0) {
        return;
    }

    // =====================================
    // 1. RESPONSIVE BACKGROUND
    // =====================================

    if (originalMedicalBackground == null
            && jLabel1.getIcon() instanceof javax.swing.ImageIcon) {

        originalMedicalBackground =
                ((javax.swing.ImageIcon) jLabel1.getIcon()).getImage();
    }

    if (originalMedicalBackground != null) {
        java.awt.Image scaledBackground =
                originalMedicalBackground.getScaledInstance(
                        width,
                        height,
                        java.awt.Image.SCALE_SMOOTH
                );

        jLabel1.setIcon(
                new javax.swing.ImageIcon(scaledBackground)
        );
    }

    jLabel1.setBounds(0, 0, width, height);

    // Keep the background behind all components
    getContentPane().setComponentZOrder(
            jLabel1,
            getContentPane().getComponentCount() - 1
    );


    // =====================================
    // 3. MAIN CONTENT
    // =====================================

// Match the Patients page's original 1920px layout
int contentX = (int) (width * 400.0 / 1920.0);
int contentWidth = width - contentX - 18;

    if (contentWidth <= 0) {
        return;
    }

    // Page title
    jButton11.setBounds(
            contentX,
            Math.max(40, (int) (height * 0.06)),
            Math.min(380, contentWidth),
            65
    );

    jButton11.setFont(
            new java.awt.Font(
                    "Segoe UI",
                    java.awt.Font.BOLD,
                    width < 1400 ? 32 : 40
            )
    );

 // =====================================
// 4. SEARCH BAR AND CONTROLS
// =====================================

int searchY = (int) (height * 160.0 / 1080.0);

int searchHeight = 42;
int gap = 8;

int searchIconWidth = 46;
int filterWidth = 160;
int sortWidth = 146;
int orderWidth = 168;

int searchWidth = (int) (720 * width / 1920.0);

searchWidth = Math.max(300, searchWidth);

jTextField1.setBounds(
        contentX,
        searchY,
        searchWidth,
        searchHeight
);

int x = contentX + searchWidth + 4;
jButton3.setBounds(
        x,
        searchY,
        searchIconWidth,
        searchHeight
);

x += searchIconWidth + gap;

Filter.setBounds(
        x,
        searchY,
        filterWidth,
        searchHeight
);

x += filterWidth + gap;

Sort.setBounds(
        x,
        searchY,
        sortWidth,
        searchHeight
);

x += sortWidth + gap;

Order.setBounds(
        x,
        searchY,
        orderWidth,
        searchHeight
);

// Search icon - same size as Doctors
java.net.URL iconURL =
        getClass().getResource("/images/icons8-search-47.png");

if (iconURL != null) {

        java.awt.Image image =
                new javax.swing.ImageIcon(iconURL)
                        .getImage()
                        .getScaledInstance(
                                24,
                                24,
                                java.awt.Image.SCALE_SMOOTH
                        );

        jButton3.setIcon(
                new javax.swing.ImageIcon(image)
        );
}
    // =====================================
    // 5. TABLE AND DETAILS PANEL
    // =====================================

   // Match the Patients page's table and details layout
int tableY = searchY + searchHeight + 16;

int detailsHeight = Math.min(
        300,
        Math.max(270, height / 3)
);

int detailsY = height - detailsHeight - 12;

int tableHeight = Math.max(
        150,
        detailsY - tableY - 10
);

// Table container
jPanel2.setBounds(
        contentX,
        tableY,
        contentWidth,
        tableHeight
);

// Same approach as fixPatientsTable()
jPanel2.setLayout(null);

jScrollPane1.setBounds(
        0,
        0,
        contentWidth,
        tableHeight
);

// Medical Records details
jPanel1.setBounds(
        contentX,
        detailsY,
        contentWidth,
        detailsHeight
);

    // =====================================
    // 6. RESPONSIVE TABLE COLUMNS
    // =====================================

MedicalRecordsTable.setAutoResizeMode(
        javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS
);

    int[] columnWidths = {
        80,   // Record ID
        85,   // Patient ID
        85,   // Doctor ID
        115,  // Appointment ID
        160,  // Diagnosis
        175,  // Treatment
        175,  // Remarks
        110,  // Record Date
        95,   // Status
        165   // Action
    };

    javax.swing.table.TableColumnModel columns =
            MedicalRecordsTable.getColumnModel();

    for (int i = 0;
            i < columns.getColumnCount()
            && i < columnWidths.length;
            i++) {

        columns.getColumn(i).setPreferredWidth(
                columnWidths[i]
        );
    }

    // Horizontal scrolling keeps all columns accessible
    jScrollPane1.setHorizontalScrollBarPolicy(
            javax.swing.JScrollPane
                    .HORIZONTAL_SCROLLBAR_AS_NEEDED
    );

    jScrollPane1.setVerticalScrollBarPolicy(
            javax.swing.JScrollPane
                    .VERTICAL_SCROLLBAR_AS_NEEDED
    );

    // =====================================
    // 7. MEDICAL RECORD DETAILS
    // =====================================

    jPanel1.setLayout(null);

    jPanel1.setBackground(
            new java.awt.Color(222, 246, 236)
    );

    jPanel1.setBorder(
            javax.swing.BorderFactory.createLineBorder(
                    new java.awt.Color(0, 102, 51),
                    2
            )
    );

    int padding = 22;
    int columnGap = 18;

    int columnWidth =
            (contentWidth - padding * 2 - columnGap * 2) / 3;

    int x1 = padding;
    int x2 = x1 + columnWidth + columnGap;
    int x3 = x2 + columnWidth + columnGap;

    int row1 = 65;
    int row2 = 110;
    int row3 = 155;

    int fieldHeight = 35;

    // Details heading
    jLabel2.setBounds(
            25, 12, 320, 35
    );

    jLabel2.setFont(
            new java.awt.Font(
                    "Segoe UI",
                    java.awt.Font.BOLD,
                    18
            )
    );

    // LEFT COLUMN
    jLabel3.setBounds(
            x1, row1, 110, fieldHeight
    );

    PatientIDComboBox.setBounds(
            x1 + 115,
            row1,
            columnWidth - 115,
            fieldHeight
    );

    jLabel4.setBounds(
            x1, row2, 110, fieldHeight
    );

    DoctorIDComboBox.setBounds(
            x1 + 115,
            row2,
            columnWidth - 115,
            fieldHeight
    );

    jLabel5.setBounds(
            x1, row3, 110, fieldHeight
    );

    AppointmentIDComboBox.setBounds(
            x1 + 115,
            row3,
            columnWidth - 115,
            fieldHeight
    );

    // MIDDLE COLUMN
    jLabel7.setBounds(
            x2, row1, 95, fieldHeight
    );

    DiagnosisField.setBounds(
            x2 + 100,
            row1,
            columnWidth - 100,
            fieldHeight
    );

    jLabel8.setBounds(
            x2, row2, 95, fieldHeight
    );

    TreatmentField.setBounds(
            x2 + 100,
            row2,
            columnWidth - 100,
            fieldHeight
    );

    jLabel6.setBounds(
            x2, row3, 95, fieldHeight
    );

    RecordField.setBounds(
            x2 + 100,
            row3,
            columnWidth - 100,
            fieldHeight
    );

 // RIGHT COLUMN

// Remarks label
jLabel10.setBounds(
        x3, row1, 70, fieldHeight
);

// Remarks text area
jScrollPane2.setBounds(
        x3 + 75,
        row1,
        columnWidth - 75,
        80
);

// Status label
jLabel9.setBounds(
        x3, row3, 70, fieldHeight
);

// Status combo box
jComboBox1.setBounds(
        x3 + 75,
        row3,
        columnWidth - 75,
        fieldHeight
);

    // Clear and Save buttons
    int buttonY = detailsHeight - 52;
    int rightEdge = x3 + columnWidth;

    jButton5.setBounds(
            rightEdge - 205,
            buttonY,
            95,
            35
    );

    jButton6.setBounds(
            rightEdge - 100,
            buttonY,
            95,
            35
    );

    // =====================================
    // 8. REFRESH
    // =====================================

    jPanel2.revalidate();
    jPanel2.repaint();

    jPanel1.revalidate();
    jPanel1.repaint();
    fixMedicalRecordsSidebar();

    

    getContentPane().revalidate();
    getContentPane().repaint();
}

private void designSearchBar() {

    String placeholder = "Search medical records...";

    jTextField1.setFont(
            new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 16)
    );

    jTextField1.setForeground(
            new java.awt.Color(130, 130, 130)
    );

    jTextField1.setText(placeholder);

    jTextField1.addFocusListener(
            new java.awt.event.FocusAdapter() {

                @Override
                public void focusGained(
                        java.awt.event.FocusEvent evt) {

                    if (jTextField1.getText().equals(placeholder)) {
                        jTextField1.setText("");
                        jTextField1.setForeground(
                                new java.awt.Color(40, 40, 40)
                        );
                    }
                }

                @Override
                public void focusLost(
                        java.awt.event.FocusEvent evt) {

                    if (jTextField1.getText().trim().isEmpty()) {
                        jTextField1.setText(placeholder);
                        jTextField1.setForeground(
                                new java.awt.Color(130, 130, 130)
                        );
                    }
                }
            }
    );
}


private void designMedicalRecordsTable() {

        MedicalRecordsTable.setFont(
                new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 14)
        );

        MedicalRecordsTable.setRowHeight(38);
        MedicalRecordsTable.setBackground(java.awt.Color.WHITE);
        MedicalRecordsTable.setForeground(
                new java.awt.Color(40, 40, 40)
        );

        MedicalRecordsTable.setSelectionBackground(
                new java.awt.Color(222, 246, 236)
        );

        MedicalRecordsTable.setSelectionForeground(
                new java.awt.Color(0, 102, 51)
        );

        MedicalRecordsTable.setGridColor(
                new java.awt.Color(220, 235, 228)
        );

        MedicalRecordsTable.setShowHorizontalLines(true);
        MedicalRecordsTable.setShowVerticalLines(false);

        MedicalRecordsTable.setIntercellSpacing(
                new java.awt.Dimension(0, 1)
        );

        javax.swing.table.DefaultTableCellRenderer center =
                new javax.swing.table.DefaultTableCellRenderer();

        center.setHorizontalAlignment(
                javax.swing.SwingConstants.CENTER
        );

        // GREEN TABLE HEADER
        javax.swing.table.JTableHeader header =
                MedicalRecordsTable.getTableHeader();

        header.setPreferredSize(
                new java.awt.Dimension(
                        header.getPreferredSize().width, 38
                )
        );

        header.setReorderingAllowed(false);

        javax.swing.table.DefaultTableCellRenderer headerRenderer =
                new javax.swing.table.DefaultTableCellRenderer();

        headerRenderer.setBackground(
                new java.awt.Color(0, 102, 51)
        );

        headerRenderer.setForeground(java.awt.Color.WHITE);

        headerRenderer.setFont(
                new java.awt.Font(
                        "Segoe UI", java.awt.Font.BOLD, 14
                )
        );

        headerRenderer.setHorizontalAlignment(
                javax.swing.SwingConstants.CENTER
        );

        headerRenderer.setOpaque(true);

        // Apply green header to ALL columns
        for (int i = 0;
                i < MedicalRecordsTable.getColumnCount();
                i++) {

                MedicalRecordsTable.getColumnModel()
                        .getColumn(i)
                        .setHeaderRenderer(headerRenderer);
        }

        // Center all columns except Action
        for (int i = 0;
                i < MedicalRecordsTable.getColumnCount() - 1;
                i++) {

                MedicalRecordsTable.getColumnModel()
                        .getColumn(i)
                        .setCellRenderer(center);
        }

        // Preserve Edit and Remove buttons
        javax.swing.table.TableColumn action =
                MedicalRecordsTable.getColumnModel()
                        .getColumn(9);

        action.setCellRenderer(new MedicalActionRenderer());
        action.setCellEditor(new MedicalActionEditor());
        action.setPreferredWidth(170);

        MedicalRecordsTable.setAutoResizeMode(
                javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS
        );

        jScrollPane1.getViewport().setBackground(
                java.awt.Color.WHITE
        );

        MedicalRecordsTable.getTableHeader().repaint();
        MedicalRecordsTable.repaint();
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        Patients = new javax.swing.JButton();
        Appointments = new javax.swing.JButton();
        Services = new javax.swing.JButton();
        Payments = new javax.swing.JButton();
        Staff = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        UserAccounts = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        MedicalRecordsTable = new javax.swing.JTable();
        Doctors = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        MedicalRecords = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        DiagnosisField = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        TreatmentField = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        RemarksNotes = new javax.swing.JTextArea();
        RecordField = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        PatientIDComboBox = new javax.swing.JComboBox<>();
        DoctorIDComboBox = new javax.swing.JComboBox<>();
        AppointmentIDComboBox = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        Sort = new javax.swing.JComboBox<>();
        Order = new javax.swing.JComboBox<>();
        Filter = new javax.swing.JComboBox<>();
        UserAccounts1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton1.setForeground(new java.awt.Color(204, 0, 0));
        jButton1.setText("Log Out");
        jButton1.setBorderPainted(false);
        jButton1.setContentAreaFilled(false);
        jButton1.setDefaultCapable(false);
        jButton1.setFocusPainted(false);
        jButton1.setFocusable(false);
        jButton1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton1.addActionListener(this::jButton1ActionPerformed);
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 990, 260, 60));

        Patients.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Patients.setForeground(new java.awt.Color(255, 255, 255));
        Patients.setText("Patients");
        Patients.setBorderPainted(false);
        Patients.setContentAreaFilled(false);
        Patients.setDefaultCapable(false);
        Patients.setFocusPainted(false);
        Patients.setFocusable(false);
        Patients.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Patients.addActionListener(this::PatientsActionPerformed);
        getContentPane().add(Patients, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 450, 260, 60));

        Appointments.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Appointments.setForeground(new java.awt.Color(255, 255, 255));
        Appointments.setText("Appointments");
        Appointments.setBorderPainted(false);
        Appointments.setContentAreaFilled(false);
        Appointments.setDefaultCapable(false);
        Appointments.setFocusPainted(false);
        Appointments.setFocusable(false);
        Appointments.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Appointments.addActionListener(this::AppointmentsActionPerformed);
        getContentPane().add(Appointments, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 560, 260, 70));

        Services.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Services.setForeground(new java.awt.Color(255, 255, 255));
        Services.setText("Services");
        Services.setBorderPainted(false);
        Services.setContentAreaFilled(false);
        Services.setDefaultCapable(false);
        Services.setFocusPainted(false);
        Services.setFocusable(false);
        Services.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Services.addActionListener(this::ServicesActionPerformed);
        getContentPane().add(Services, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 670, 260, 90));

        Payments.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Payments.setForeground(new java.awt.Color(255, 255, 255));
        Payments.setText("Payments");
        Payments.setBorderPainted(false);
        Payments.setContentAreaFilled(false);
        Payments.setDefaultCapable(false);
        Payments.setFocusPainted(false);
        Payments.setFocusable(false);
        Payments.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Payments.addActionListener(this::PaymentsActionPerformed);
        getContentPane().add(Payments, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 730, 260, 80));

        Staff.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Staff.setForeground(new java.awt.Color(255, 255, 255));
        Staff.setText("Staff");
        Staff.setBorderPainted(false);
        Staff.setContentAreaFilled(false);
        Staff.setDefaultCapable(false);
        Staff.setFocusPainted(false);
        Staff.setFocusable(false);
        Staff.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Staff.addActionListener(this::StaffActionPerformed);
        getContentPane().add(Staff, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 780, 260, 80));

        jButton10.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton10.setForeground(new java.awt.Color(255, 255, 255));
        jButton10.setText("Dashboard");
        jButton10.setBorderPainted(false);
        jButton10.setContentAreaFilled(false);
        jButton10.setDefaultCapable(false);
        jButton10.setFocusPainted(false);
        jButton10.setFocusable(false);
        jButton10.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton10.addActionListener(this::jButton10ActionPerformed);
        getContentPane().add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 380, 260, 80));

        jButton11.setFont(new java.awt.Font("Segoe UI", 1, 40)); // NOI18N
        jButton11.setText("Medical Records");
        jButton11.setBorderPainted(false);
        jButton11.setContentAreaFilled(false);
        jButton11.setDefaultCapable(false);
        jButton11.setFocusPainted(false);
        jButton11.setFocusable(false);
        jButton11.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton11.addActionListener(this::jButton11ActionPerformed);
        getContentPane().add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 40, 360, -1));

        UserAccounts.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        UserAccounts.setForeground(new java.awt.Color(255, 255, 255));
        UserAccounts.setText("User Accounts");
        UserAccounts.setBorderPainted(false);
        UserAccounts.setContentAreaFilled(false);
        UserAccounts.setDefaultCapable(false);
        UserAccounts.setFocusPainted(false);
        UserAccounts.setFocusable(false);
        UserAccounts.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        UserAccounts.addActionListener(this::UserAccountsActionPerformed);
        getContentPane().add(UserAccounts, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 830, 260, 80));

        jPanel2.setBackground(new java.awt.Color(222, 246, 236));

        MedicalRecordsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Record ID", "Patient ID", "Doctor ID", "Appointment ID", "Diagnosis", "Treatment", "Remarks", "Record Date"
            }
        ));
        MedicalRecordsTable.setFocusCycleRoot(true);
        MedicalRecordsTable.setGridColor(new java.awt.Color(231, 250, 250));
        MedicalRecordsTable.setShowGrid(true);
        MedicalRecordsTable.setSurrendersFocusOnKeystroke(true);
        jScrollPane1.setViewportView(MedicalRecordsTable);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1474, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 514, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 230, 1480, 520));

        Doctors.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Doctors.setForeground(new java.awt.Color(255, 255, 255));
        Doctors.setText("Doctors");
        Doctors.setBorderPainted(false);
        Doctors.setContentAreaFilled(false);
        Doctors.setDefaultCapable(false);
        Doctors.setFocusPainted(false);
        Doctors.setFocusable(false);
        Doctors.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Doctors.addActionListener(this::DoctorsActionPerformed);
        getContentPane().add(Doctors, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 500, 260, 70));

        jTextField1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jTextField1.setText("Search medical records...");
        jTextField1.addActionListener(this::jTextField1ActionPerformed);
        getContentPane().add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 160, 720, 50));

        MedicalRecords.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        MedicalRecords.setForeground(new java.awt.Color(0, 102, 51));
        MedicalRecords.setText("Medical Records");
        MedicalRecords.setDefaultCapable(false);
        MedicalRecords.setFocusPainted(false);
        MedicalRecords.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        MedicalRecords.addActionListener(this::MedicalRecordsActionPerformed);
        getContentPane().add(MedicalRecords, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 630, 260, 50));

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-search-47.png"))); // NOI18N
        jButton3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 51)));
        jButton3.setBorderPainted(false);
        jButton3.addActionListener(this::jButton3ActionPerformed);
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 160, -1, -1));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 102, 51));
        jLabel2.setText("Medical Records");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Patient ID");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Doctor ID");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setText("Appointment ID");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setText("Diagnosis");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel8.setText("Treatment");

        jButton5.setBackground(new java.awt.Color(240, 250, 244));
        jButton5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton5.setForeground(new java.awt.Color(0, 102, 51));
        jButton5.setText("Clear");

        jButton6.setBackground(new java.awt.Color(0, 102, 51));
        jButton6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.setText("Save");

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel10.setText("Remarks");

        RemarksNotes.setColumns(20);
        RemarksNotes.setRows(5);
        jScrollPane2.setViewportView(RemarksNotes);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel6.setText("Record Date");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel9.setText("Status");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Active", "Inactive", " " }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jLabel2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(PatientIDComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(AppointmentIDComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(DoctorIDComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(50, 50, 50)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel6)
                                    .addGap(331, 331, 331))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel8)
                                    .addGap(343, 343, 343)))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addGap(45, 45, 45)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(TreatmentField, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(DiagnosisField, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(RecordField, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jButton5)
                                .addGap(18, 18, 18)
                                .addComponent(jButton6))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel10)
                                    .addComponent(jLabel9))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jScrollPane2)
                                    .addComponent(jComboBox1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))
                .addContainerGap(339, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(PatientIDComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(DoctorIDComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(AppointmentIDComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6)
                            .addComponent(RecordField, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel7)
                                    .addComponent(DiagnosisField, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel10))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel8)
                                    .addComponent(TreatmentField, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, 17))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 770, 1480, 230));

        Sort.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Sort.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SORT BY: DEFAULT", "Record ID", "Record Date" }));
        Sort.addActionListener(this::SortActionPerformed);
        getContentPane().add(Sort, new org.netbeans.lib.awtextra.AbsoluteConstraints(1310, 160, 140, 50));

        Order.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Order.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ORDER", "ASCENDING", "DESCENDING" }));
        Order.addActionListener(this::OrderActionPerformed);
        getContentPane().add(Order, new org.netbeans.lib.awtextra.AbsoluteConstraints(1460, 160, 100, 50));

        Filter.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Filter.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "FILTER BY: ALL", "Active", "Inactive", " " }));
        Filter.addActionListener(this::FilterActionPerformed);
        getContentPane().add(Filter, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 160, 120, 50));

        UserAccounts1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        UserAccounts1.setForeground(new java.awt.Color(255, 255, 255));
        UserAccounts1.setText("Archive");
        UserAccounts1.setBorderPainted(false);
        UserAccounts1.setContentAreaFilled(false);
        UserAccounts1.setDefaultCapable(false);
        UserAccounts1.setFocusPainted(false);
        UserAccounts1.setFocusable(false);
        UserAccounts1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        UserAccounts1.addActionListener(this::UserAccounts1ActionPerformed);
        getContentPane().add(UserAccounts1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 890, 260, 80));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Dashgh.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1930, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void PatientsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PatientsActionPerformed
    Patients patients = new Patients();
    patients.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_PatientsActionPerformed

    private void AppointmentsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AppointmentsActionPerformed
    Appointments appointments = new Appointments();
    appointments.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_AppointmentsActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton11ActionPerformed

    private void DoctorsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DoctorsActionPerformed
    Doctors doctors = new Doctors();
    doctors.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_DoctorsActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        
        searchMedicalRecords();
// TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
                searchMedicalRecords();
// TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
    Dashboard dashboard = new Dashboard();
    dashboard.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton10ActionPerformed

    private void MedicalRecordsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MedicalRecordsActionPerformed
    MedicalRecords records = new MedicalRecords();
    records.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_MedicalRecordsActionPerformed

    private void ServicesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ServicesActionPerformed
    Services services = new Services();
    services.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_ServicesActionPerformed

    private void PaymentsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PaymentsActionPerformed
    Payments payments = new Payments();
    payments.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_PaymentsActionPerformed

    private void StaffActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StaffActionPerformed
    Staff staff = new Staff();
    staff.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_StaffActionPerformed

    private void UserAccountsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UserAccountsActionPerformed
    UserAccounts accounts = new UserAccounts();
    accounts.setVisible(true);
    this.dispose();
        // TODO add your handling code here:
    }//GEN-LAST:event_UserAccountsActionPerformed

    private void FilterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FilterActionPerformed
        searchMedicalRecords();


        // TODO add your handling code here:
    }//GEN-LAST:event_FilterActionPerformed

    private void SortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SortActionPerformed
        sortMedicalRecords();

        // TODO add your handling code here:
    }//GEN-LAST:event_SortActionPerformed

    private void OrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OrderActionPerformed
        sortMedicalRecords();
        // TODO add your handling code here:
    }//GEN-LAST:event_OrderActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    UserSession.logout();
    SignIn logout = new SignIn();
    logout.setVisible(true);
    this.dispose();    // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void UserAccounts1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UserAccounts1ActionPerformed
        Archive archive = new Archive();
        archive.setVisible(true);
        this.dispose();      // TODO add your handling code here:
    }//GEN-LAST:event_UserAccounts1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new MedicalRecords().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> AppointmentIDComboBox;
    private javax.swing.JButton Appointments;
    private javax.swing.JTextField DiagnosisField;
    private javax.swing.JComboBox<String> DoctorIDComboBox;
    private javax.swing.JButton Doctors;
    private javax.swing.JComboBox<String> Filter;
    private javax.swing.JButton MedicalRecords;
    private javax.swing.JTable MedicalRecordsTable;
    private javax.swing.JComboBox<String> Order;
    private javax.swing.JComboBox<String> PatientIDComboBox;
    private javax.swing.JButton Patients;
    private javax.swing.JButton Payments;
    private javax.swing.JTextField RecordField;
    private javax.swing.JTextArea RemarksNotes;
    private javax.swing.JButton Services;
    private javax.swing.JComboBox<String> Sort;
    private javax.swing.JButton Staff;
    private javax.swing.JTextField TreatmentField;
    private javax.swing.JButton UserAccounts;
    private javax.swing.JButton UserAccounts1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
