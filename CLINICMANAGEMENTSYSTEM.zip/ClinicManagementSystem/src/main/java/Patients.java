/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author NCGC
 */
public class Patients extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Patients.class.getName());
    private Connection conn;
    private PreparedStatement pst;
    private ResultSet rs;

    private javax.swing.table.TableRowSorter<
        javax.swing.table.TableModel
    > sorter;
    private int editingPatientId = -1;    

    /**
     * Creates new form Patients
     */
    public Patients() {
        initComponents();
        setupBirthDatePlaceholder();
        setFocusable(true);
        getContentPane().setFocusable(true);
        fixTopControls();        
        SaveButton.addActionListener(
            this::jButton6ActionPerformed
        );

        ClearButton.addActionListener(
            e -> cancelPatientEdit()
        );        
        
        addActionsColumn();
        // Search placeholder color
        SearchField.setForeground(
            new java.awt.Color(153, 153, 153)
        );

        // Search placeholder behavior
        SearchField.addFocusListener(
            new java.awt.event.FocusAdapter() {

                @Override
                public void focusGained(
                        java.awt.event.FocusEvent evt) {

                    if (SearchField.getText().equals(
                            "Search patient by name, contact, or ID.."
                    )) {

                        SearchField.setText("");

                        SearchField.setForeground(
                            new java.awt.Color(0, 0, 0)
                        );
                    }
                }

                @Override
                public void focusLost(
                        java.awt.event.FocusEvent evt) {

                    if (SearchField.getText().trim().isEmpty()) {

                        SearchField.setText(
                            "Search patient by name, contact, or ID.."
                        );

                        SearchField.setForeground(
                            new java.awt.Color(153, 153, 153)
                        );
                    }
                }
            }
        );

        // Design Patients table
        designPatientsTable();
        
        configureActionsColumn();

        connectDatabase();
        loadPatients();

        // Create table sorter
        sorter =
            new javax.swing.table.TableRowSorter<>(
                PatientsTable.getModel()
            );

        PatientsTable.setRowSorter(sorter);
        
        // Sort Patient ID numerically
        sorter.setComparator(
            0,
            (a, b) -> Integer.compare(
                Integer.parseInt(a.toString()),
                Integer.parseInt(b.toString())
            )
        );        

        // Press ENTER to search
        SearchField.addActionListener(
            e -> searchPatients()
        );

        setExtendedState(
            javax.swing.JFrame.MAXIMIZED_BOTH
        );

java.awt.EventQueue.invokeLater(() -> {

    getContentPane().setLayout(null);

    scalePatients();

    // Remove automatic focus from search field
    getContentPane().requestFocusInWindow();

    repaint();
});
        
    }
    
    // =========================================================
    // LOAD PATIENTS FROM DATABASE
    // =========================================================

private static final String BIRTH_DATE_HINT = "YYYY-MM-DD";

private void showBirthDatePlaceholder() {
    jTextField4.setText(BIRTH_DATE_HINT);
    jTextField4.setForeground(
            new java.awt.Color(150, 150, 150)
    );
}

private String getBirthDateValue() {
    String value = jTextField4.getText().trim();

    if (value.equals(BIRTH_DATE_HINT)) {
        return "";
    }

    return value;
}

private void setupBirthDatePlaceholder() {

    jTextField4.setFont(
            new java.awt.Font(
                    "Segoe UI", java.awt.Font.PLAIN, 14
            )
    );

    showBirthDatePlaceholder();

    jTextField4.addFocusListener(
            new java.awt.event.FocusAdapter() {

        @Override
        public void focusGained(
                java.awt.event.FocusEvent evt) {

            if (jTextField4.getText().equals(BIRTH_DATE_HINT)) {
                jTextField4.setText("");
            }

            jTextField4.setForeground(
                    new java.awt.Color(30, 30, 30)
            );
        }

        @Override
        public void focusLost(
                java.awt.event.FocusEvent evt) {

            if (jTextField4.getText().trim().isEmpty()) {
                showBirthDatePlaceholder();
            }
    
        }
    });
}


    private void loadPatients() {

        if (conn == null) {
            return;
        }

        DefaultTableModel model =
            (DefaultTableModel) PatientsTable.getModel();

        model.setRowCount(0);

 String sql =
    "SELECT patient_id, first_name, last_name, " +
    "birth_date, gender, contact_number, address, " +
    "date_added, status " +
    "FROM Patients " +
    "WHERE status <> 'Archived'";

        try {

            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();

            while (rs.next()) {

                Object[] row = {

                    rs.getInt("patient_id"),
                    rs.getString("first_name"),
                    rs.getString("last_name"),
                    rs.getDate("birth_date"),
                    rs.getString("gender"),
                    rs.getString("contact_number"),
                    rs.getString("address"),
                    rs.getTimestamp("date_added"),
                    rs.getString("status")
                };

                model.addRow(row);
            }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                this,
                "Failed to load patients!\n" +
                e.getMessage()
            );
        }
    }
    // =========================================================
    // DATABASE CONNECTION
    // =========================================================

    private void connectDatabase() {

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/ClinicManagementSystem",
                "root",
                ""
            );

            System.out.println("Database Connected!");

        } catch (ClassNotFoundException | SQLException e) {

            JOptionPane.showMessageDialog(
                this,
                "Database Connection Failed!\n" + e.getMessage()
            );
        }
    }
        private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {
            if (editingPatientId != -1) {

            updatePatient();
            return;
            }

        String firstName = jTextField2.getText().trim();
        String lastName = jTextField3.getText().trim();
        String birthDate = getBirthDateValue();
        String gender = jComboBox1.getSelectedItem().toString();
        String contact = jTextField5.getText().trim();
        String address = jTextField6.getText().trim();

        if (firstName.isEmpty() || lastName.isEmpty()) {

            JOptionPane.showMessageDialog(
                this,
                "Please enter the patient's first and last name."
            );

            return;
        }

        String sql =
            "INSERT INTO Patients " +
            "(first_name, last_name, birth_date, " +
            "contact_number, gender, address) " +
            "VALUES (?, ?, ?, ?, ?, ?)";

        try {

            pst = conn.prepareStatement(sql);

            pst.setString(1, firstName);
            pst.setString(2, lastName);

            if (birthDate.isEmpty()) {
                pst.setNull(3, java.sql.Types.DATE);
            } else {
                pst.setDate(
                    3,
                    java.sql.Date.valueOf(birthDate)
                );
            }

            pst.setString(4, contact);
            pst.setString(5, gender);
            pst.setString(6, address);

            pst.executeUpdate();

            JOptionPane.showMessageDialog(
                this,
                "Patient saved successfully!"
            );

            loadPatients();
            clearPatientFields();

        } catch (IllegalArgumentException e) {

            JOptionPane.showMessageDialog(
                this,
                "Birth Date must use YYYY-MM-DD.\nExample: 2005-10-25"
            );

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                this,
                "Failed to save patient!\n" + e.getMessage()
            );
        }
    }
    private void clearPatientFields() {
        jTextField2.setText("");
        jTextField3.setText("");
        showBirthDatePlaceholder();
        jTextField5.setText("");
        jTextField6.setText("");
        jComboBox2.setSelectedItem("Active");
        jComboBox1.setSelectedIndex(0);
    }       

    // =========================================================
    // SEARCH PATIENTS
    // =========================================================


private void searchPatients() {

        if (sorter == null) {
                return;
        }

        String searchText = SearchField.getText().trim();

        if (searchText.equals(
                "Search patient by name, contact, or ID..")) {
                searchText = "";
        }

        String selectedFilter =
                Filter.getSelectedItem().toString().trim();

        String pattern = "(?i)" +
                java.util.regex.Pattern.quote(searchText);

        java.util.List<javax.swing.RowFilter<Object, Object>>
                filters = new java.util.ArrayList<>();

        // Search by name, contact, or patient ID
        if (!searchText.isEmpty()) {

                filters.add(
                        javax.swing.RowFilter.regexFilter(
                                pattern, 0, 1, 2, 5, 6
                        )
                );
        }

        // Filter patients by status (column 8)
        if (selectedFilter.equalsIgnoreCase("Active")
                || selectedFilter.equalsIgnoreCase("Inactive")) {

                filters.add(
                        javax.swing.RowFilter.regexFilter(
                                "(?i)^" + selectedFilter + "$", 8
                        )
                );
        }

        if (filters.isEmpty()) {
                sorter.setRowFilter(null);
        } else {
                sorter.setRowFilter(
                        javax.swing.RowFilter.andFilter(filters)
                );
        }
}

    
    // =========================================================
    // SORT PATIENTS
    // =========================================================

    private void sortPatients() {

        String selectedSort =
            Sort.getSelectedItem().toString();

        String selectedOrder =
            Order.getSelectedItem().toString();

        int column = -1;

        switch (selectedSort) {

            case "First Name":
                column = 1;
                break;

            case "Last Name":
                column = 2;
                break;

            case "Patient ID":
                column = 0;
                break;

            case "Birth Date":
                column = 3;
                break;

            case "Gender":
                column = 4;
                break;
        }

        if (column == -1) {

            sorter.setSortKeys(null);
            return;
        }

        javax.swing.SortOrder order;

        if (selectedOrder.equals("DESCENDING")) {
            order =
                javax.swing.SortOrder.DESCENDING;

        } else {

            order =
                javax.swing.SortOrder.ASCENDING;
        }

        java.util.List<
            javax.swing.RowSorter.SortKey
        > sortKeys =
            new java.util.ArrayList<>();

        sortKeys.add(
            new javax.swing.RowSorter.SortKey(
                column,
                order
            )
        );

        sorter.setSortKeys(sortKeys);
        sorter.sort();
    }
    
private void fixPatientsSidebar() {

        int width = getContentPane().getWidth();
        int height = getContentPane().getHeight();

        double scaleX = width / 1920.0;
        double scaleY = height / 1080.0;

        javax.swing.JButton[] buttons = {
                Dashboard,
                Patients,
                Doctors,
                Appointments,
                MedicalRecords,
                Services,
                Payments,
                Staff,
                UserAccounts,
                Archive,
                jButton1
        };

        int[] positionsY = {
                390, 445, 500, 555, 610,
                665, 720, 775, 830, 885, 955
        };

        int buttonX = (int) (60 * scaleX);
        int buttonWidth = (int) (260 * scaleX);
        int buttonHeight = (int) (50 * scaleY);

        for (int i = 0; i < buttons.length; i++) {

                buttons[i].setBounds(
                        buttonX,
                        (int) (positionsY[i] * scaleY),
                        buttonWidth,
                        buttonHeight
                );

                buttons[i].setHorizontalAlignment(
                        javax.swing.SwingConstants.LEFT
                );
        }
}

    // =========================================================
    // PATIENTS RESPONSIVE SCALING
    // Original design resolution: 1920 x 1080
    // =========================================================
    private void fixTopControls() {

        Filter.setBounds(
            1180,
            160,
            130,
            50
        );

        Sort.setBounds(
            1320,
            160,
            150,
            50
        );

        Order.setBounds(
            1480,
            160,
            160,
            50
        );
    }
     private void scalePatients() {

        int screenWidth =
            getContentPane().getWidth();

        int screenHeight =
            getContentPane().getHeight();

        double scaleX =
            screenWidth / 1920.0;

        double scaleY =
            screenHeight / 1080.0;

        double fontScale =
            Math.min(scaleX, scaleY);

        for (java.awt.Component component :
                getContentPane().getComponents()) {

            java.awt.Rectangle b =
                component.getBounds();

            component.setBounds(
                (int) (b.x * scaleX),
                (int) (b.y * scaleY),
                (int) (b.width * scaleX),
                (int) (b.height * scaleY)
            );

            java.awt.Font font =
                component.getFont();

            if (font != null) {

                component.setFont(
                    font.deriveFont(
                        (float) (
                            font.getSize2D()
                            * fontScale
                        )
                    )
                );
            }
        }

        // Fix table after scaling
        fixPatientsTable();

        // Fix Patient Details panel
        fixPatientDetailsPanel();

        // Resize search icon after scaling
        scaleSearchIcon();

        // Scale background last
        scaleBackground();

        // Match Dashboard sidebar positioning and sizes
        fixPatientsSidebar();
    }
        // =========================================================
    // RESPONSIVE PATIENTS TABLE
    // Makes JTable fill the whole table panel
    // =========================================================

    private void fixPatientsTable() {

        jPanel2.setLayout(null);

        jScrollPane1.setBounds(
            0,
            0,
            jPanel2.getWidth(),
            jPanel2.getHeight()
        );

        PatientsTable.setAutoResizeMode(
            javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS
        );

        jPanel2.revalidate();
        jPanel2.repaint();
    }
    private void scaleBackground() {

        int width = getContentPane().getWidth();
        int height = getContentPane().getHeight();

        javax.swing.ImageIcon icon =
            new javax.swing.ImageIcon(
                getClass().getResource("/images/Dashgh.png")
            );

        java.awt.Image image =
            icon.getImage().getScaledInstance(
                width,
                height,
                java.awt.Image.SCALE_SMOOTH
            );

        jLabel1.setIcon(
            new javax.swing.ImageIcon(image)
        );

        jLabel1.setBounds(
            0,
            0,
            width,
            height
        );

        // Keep background behind everything
        getContentPane().setComponentZOrder(
            jLabel1,
            getContentPane().getComponentCount() - 1
        );
    }
    
        // =========================================================
    // FIX PATIENT DETAILS PANEL
    // Prevents right-side fields from being cut
    // =========================================================



private void fixPatientDetailsPanel() {

    int screenHeight = getContentPane().getHeight();

    int panelX = jPanel2.getX();
    int panelWidth = jPanel2.getWidth();

    // Reserve enough space for Patient Details
    int panelHeight = Math.min(
            300,
            Math.max(270, screenHeight / 3)
    );

    int panelY = screenHeight - panelHeight - 12;

    // Resize the table to leave room for details
    int tableHeight = Math.max(
            200,
            panelY - jPanel2.getY() - 10
    );

    jPanel2.setSize(panelWidth, tableHeight);

    // Make the table fit its resized panel
    jScrollPane1.setBounds(
            0, 0, panelWidth, tableHeight
    );

    // Position Patient Details
    jPanel1.setBounds(
            panelX, panelY, panelWidth, panelHeight
    );

    jPanel1.setLayout(null);
    jPanel1.setVisible(true);
    jPanel1.setOpaque(true);

    jPanel1.setBackground(
            new java.awt.Color(245, 252, 248)
    );

    jPanel1.setBorder(
            javax.swing.BorderFactory.createLineBorder(
                    new java.awt.Color(0, 102, 51), 2
            )
    );

    // Patient Details title
    jLabel2.setText("Patient Details");
    jLabel2.setVisible(true);
    jLabel2.setFont(
            new java.awt.Font(
                    "Segoe UI", java.awt.Font.BOLD, 18
            )
    );
    jLabel2.setForeground(
            new java.awt.Color(0, 102, 51)
    );
    jLabel2.setBounds(25, 12, 250, 35);

    // Two-column layout
    int fieldWidth = Math.min(
            300,
            Math.max(140, (panelWidth - 320) / 2)
    );

    int leftLabelX = 35;
    int leftFieldX = 170;

    int rightLabelX = panelWidth / 2 + 10;
    int rightFieldX = rightLabelX + 160;

 int fieldHeight = 35;
int rowGap = 46;

int row1 = 55;
int row2 = row1 + rowGap;
int row3 = row2 + rowGap;
int row4 = row3 + rowGap;

    // LEFT SIDE
    jLabel3.setBounds(leftLabelX, row1, 125, fieldHeight);
    jTextField2.setBounds(leftFieldX, row1, fieldWidth, fieldHeight);

    jLabel4.setBounds(leftLabelX, row2, 125, fieldHeight);
    jTextField3.setBounds(leftFieldX, row2, fieldWidth, fieldHeight);

    jLabel5.setBounds(leftLabelX, row3, 125, fieldHeight);
    jTextField4.setBounds(leftFieldX, row3, fieldWidth, fieldHeight);

    jLabel6.setBounds(leftLabelX, row4, 125, fieldHeight);
    jComboBox1.setBounds(leftFieldX, row4, fieldWidth, fieldHeight);

    // RIGHT SIDE
    jLabel7.setBounds(rightLabelX, row1, 150, fieldHeight);
    jTextField5.setBounds(rightFieldX, row1, fieldWidth, fieldHeight);

    jLabel8.setBounds(rightLabelX, row2, 150, fieldHeight);
    jTextField6.setBounds(rightFieldX, row2, fieldWidth, fieldHeight);

    jLabel9.setBounds(rightLabelX, row3, 150, fieldHeight);
    jComboBox2.setBounds(rightFieldX, row3, fieldWidth, fieldHeight);

    // BUTTONS
    int buttonWidth = 110;
    int buttonGap = 15;

    int saveX = rightFieldX + fieldWidth - buttonWidth;
    int clearX = saveX - buttonWidth - buttonGap;

    ClearButton.setBounds(
            clearX, row4, buttonWidth, fieldHeight
    );

    SaveButton.setBounds(
            saveX, row4, buttonWidth, fieldHeight
    );

    jPanel2.revalidate();
    jPanel2.repaint();

    jPanel1.revalidate();
    jPanel1.repaint();
}

// =========================================================
    // SEARCH BUTTON ICON
    // =========================================================

    private void scaleSearchIcon() {

        javax.swing.ImageIcon icon =
            new javax.swing.ImageIcon(
                getClass().getResource(
                    "/images/icons8-search-47.png"
                )
            );

        int size = Math.min(
            SearchButton.getWidth(),
            SearchButton.getHeight()
        );

        size = (int) (size * 0.60);

        java.awt.Image image =
            icon.getImage().getScaledInstance(
                size,
                size,
                java.awt.Image.SCALE_SMOOTH
            );

        SearchButton.setIcon(
            new javax.swing.ImageIcon(image)
        );

        SearchButton.setHorizontalAlignment(
            javax.swing.SwingConstants.CENTER
        );

        SearchButton.setVerticalAlignment(
            javax.swing.SwingConstants.CENTER
        );
    }
    
    // =========================================================
    // EDIT / REMOVE COLUMN
    // =========================================================

    private void addActionsColumn() {

        DefaultTableModel model =
            (DefaultTableModel) PatientsTable.getModel();

        // Blank header beside Status
        model.addColumn("");
    }


    private void configureActionsColumn() {

        // Patient information cannot be edited directly
        PatientsTable.setDefaultEditor(
            Object.class,
            null
        );

        PatientsTable.setRowHeight(38);

        int buttonColumn =
            PatientsTable.getColumnCount() - 1;

        PatientsTable.getColumnModel()
            .getColumn(buttonColumn)
            .setMinWidth(150);

        PatientsTable.getColumnModel()
            .getColumn(buttonColumn)
            .setPreferredWidth(150);

        PatientsTable.getColumnModel()
            .getColumn(buttonColumn)
            .setMaxWidth(170);

        PatientsTable.getColumnModel()
            .getColumn(buttonColumn)
            .setCellRenderer(
                new ActionRenderer()
            );

        PatientsTable.getColumnModel()
            .getColumn(buttonColumn)
            .setCellEditor(
                new ActionEditor()
            );
    }
    
    private void updatePatient() {

        String firstName =
            jTextField2.getText().trim();

        String lastName =
            jTextField3.getText().trim();

        String birthDate = getBirthDateValue();

        String gender =
            jComboBox1.getSelectedItem().toString();

        String contact =
            jTextField5.getText().trim();


        String address =
            jTextField6.getText().trim();

String status =
        jComboBox2.getSelectedItem().toString();

        if (firstName.isEmpty()
                || lastName.isEmpty()) {

            JOptionPane.showMessageDialog(
                this,
                "Please enter the patient's first and last name."
            );

            return;
        }

        if (status.isEmpty()) {
            status = "Active";
        }

        String sql =
            "UPDATE Patients SET " +
            "first_name = ?, " +
            "last_name = ?, " +
            "birth_date = ?, " +
            "contact_number = ?, " +
            "gender = ?, " +
            "address = ?, " +
            "status = ? " +
            "WHERE patient_id = ?";

        try {

            pst = conn.prepareStatement(sql);

            pst.setString(1, firstName);
            pst.setString(2, lastName);

            if (birthDate.isEmpty()) {

                pst.setNull(
                    3,
                    java.sql.Types.DATE
                );

            } else {

                pst.setDate(
                    3,
                    java.sql.Date.valueOf(
                        birthDate
                    )
                );
            }

            pst.setString(4, contact);
            pst.setString(5, gender);
            pst.setString(6, address);
            pst.setString(7, status);
            

            pst.setInt(
                8,
                editingPatientId
            );

            pst.executeUpdate();

            JOptionPane.showMessageDialog(
                this,
                "Patient updated successfully!"
            );

            loadPatients();
            cancelPatientEdit();

        } catch (IllegalArgumentException e) {

            JOptionPane.showMessageDialog(
                this,
                "Birth Date must use YYYY-MM-DD."
            );

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                this,
                "Failed to update patient!\n"
                    + e.getMessage()
            );
        }
    } 
    private void editPatient(int row) {

        if (row < 0) {
            return;
        }

        DefaultTableModel model =
            (DefaultTableModel) PatientsTable.getModel();

        editingPatientId =
            Integer.parseInt(
                model.getValueAt(row, 0).toString()
            );

        jTextField2.setText(
            valueToText(
                model.getValueAt(row, 1)
            )
        );

        jTextField3.setText(
            valueToText(
                model.getValueAt(row, 2)
            )
        );

     
String selectedBirthDate = valueToText(
        model.getValueAt(row, 3)
);

if (selectedBirthDate.isEmpty()) {
    showBirthDatePlaceholder();
} else {
    jTextField4.setText(selectedBirthDate);
    jTextField4.setForeground(
            new java.awt.Color(30, 30, 30)
    );
}

        jComboBox1.setSelectedItem(
            valueToText(
                model.getValueAt(row, 4)
            )
        );

        jTextField5.setText(
            valueToText(
                model.getValueAt(row, 5)
            )
        );

        jTextField6.setText(
            valueToText(
                model.getValueAt(row, 6)
            )
        );
        
jComboBox2.setSelectedItem(
        valueToText(
                model.getValueAt(row, 8)
        )
);  

        SaveButton.setText("Update");
    }


    private String valueToText(Object value) {

        if (value == null) {
            return "";
        }

        return value.toString();
    }
    // =========================================================
    // EDIT / REMOVE BUTTON RENDERER
    // =========================================================

    private class ActionRenderer
            extends javax.swing.JPanel
            implements javax.swing.table.TableCellRenderer {

        private final javax.swing.JButton editButton;
        private final javax.swing.JButton removeButton;

        public ActionRenderer() {

        setLayout(
            new java.awt.FlowLayout(
                java.awt.FlowLayout.CENTER,
                5,
                2
            )
        );

        editButton =
            new javax.swing.JButton("Edit");

        removeButton =
            new javax.swing.JButton("Remove");

        editButton.setBackground(
            new java.awt.Color(0, 102, 51)
        );

        editButton.setForeground(
            java.awt.Color.WHITE
        );

        removeButton.setBackground(
            new java.awt.Color(204, 0, 0)
        );

        removeButton.setForeground(
            java.awt.Color.WHITE
        );

        editButton.setFocusable(false);
        removeButton.setFocusable(false);

        add(editButton);
        add(removeButton);
    }

        @Override
        public java.awt.Component
                getTableCellRendererComponent(
                    javax.swing.JTable table,
                    Object value,
                    boolean isSelected,
                    boolean hasFocus,
                    int row,
                    int column) {

        if (isSelected) {

            setBackground(
                table.getSelectionBackground()
            );

        } else {

            setBackground(
                java.awt.Color.WHITE
            );
        }

        return this;
    }
    }
        // =========================================================
    // EDIT / REMOVE BUTTON EDITOR
    // =========================================================

    private class ActionEditor
            extends javax.swing.AbstractCellEditor
            implements javax.swing.table.TableCellEditor {

        private final javax.swing.JPanel panel;
        private final javax.swing.JButton editButton;
        private final javax.swing.JButton removeButton;

        private int selectedRow = -1;

        public ActionEditor() {

        panel =
            new javax.swing.JPanel(
                new java.awt.FlowLayout(
                    java.awt.FlowLayout.CENTER,
                    5,
                    2
                )
            );

        editButton =
            new javax.swing.JButton("Edit");

        removeButton =
            new javax.swing.JButton("Remove");

        editButton.setBackground(
            new java.awt.Color(0, 102, 51)
        );

        editButton.setForeground(
            java.awt.Color.WHITE
        );

        removeButton.setBackground(
            new java.awt.Color(204, 0, 0)
        );

        removeButton.setForeground(
            java.awt.Color.WHITE
        );

        editButton.setFocusable(false);
        removeButton.setFocusable(false);

        editButton.addActionListener(e -> {

            int row = selectedRow;

            fireEditingStopped();

            editPatient(row);
        });

removeButton.addActionListener(e -> {

    int row = selectedRow;

    fireEditingStopped();

    removePatient(row);
});

        panel.add(editButton);
        panel.add(removeButton);
    }

        @Override
        public java.awt.Component
                getTableCellEditorComponent(
                    javax.swing.JTable table,
                    Object value,
                    boolean isSelected,
                    int row,
                    int column) {

        selectedRow =
            table.convertRowIndexToModel(
                row
            );

        return panel;
    }

        @Override
        public Object getCellEditorValue() {

        return "";
    }
    }
private void removePatient(int row) {

    if (row < 0) {
        return;
    }

    DefaultTableModel model =
        (DefaultTableModel) PatientsTable.getModel();

    int patientId =
        Integer.parseInt(
            model.getValueAt(row, 0).toString()
        );

    String patientName =
        valueToText(model.getValueAt(row, 1))
        + " "
        + valueToText(model.getValueAt(row, 2));

    int answer =
        JOptionPane.showConfirmDialog(
            this,
            "Remove " + patientName + " and move to Archive?",
            "Confirm Remove",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );

    if (answer != JOptionPane.YES_OPTION) {
        return;
    }

    String sql =
        "UPDATE Patients " +
        "SET status = 'Archived' " +
        "WHERE patient_id = ?";

    try {

        pst = conn.prepareStatement(sql);
        pst.setInt(1, patientId);

        pst.executeUpdate();

        JOptionPane.showMessageDialog(
            this,
            "Patient moved to Archive successfully!"
        );

        loadPatients();
        cancelPatientEdit();

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
            this,
            "Failed to remove patient!\n"
            + e.getMessage()
        );
    }
}
    private void cancelPatientEdit() {

        editingPatientId = -1;

        clearPatientFields();

        SaveButton.setText("Save");
    }
    // =========================================================
    // PATIENTS TABLE DESIGN
    // Matches Dashboard table design
    // =========================================================

    private void designPatientsTable() {

        PatientsTable.setFont(
            new java.awt.Font(
                "Segoe UI",
                java.awt.Font.PLAIN,
                14
            )
        );

        PatientsTable.setRowHeight(32);

        PatientsTable.setBackground(
            java.awt.Color.WHITE
        );

        PatientsTable.setForeground(
            new java.awt.Color(40, 40, 40)
        );

        PatientsTable.setSelectionBackground(
            new java.awt.Color(222, 246, 236)
        );

        PatientsTable.setSelectionForeground(
            new java.awt.Color(0, 102, 51)
        );

        PatientsTable.setGridColor(
            new java.awt.Color(220, 235, 228)
        );

        PatientsTable.setShowHorizontalLines(true);
        PatientsTable.setShowVerticalLines(false);

        PatientsTable.setIntercellSpacing(
            new java.awt.Dimension(0, 1)
        );


        // =====================================================
        // TABLE HEADER
        // =====================================================

        javax.swing.table.JTableHeader header =
            PatientsTable.getTableHeader();

        header.setPreferredSize(
            new java.awt.Dimension(
                header.getPreferredSize().width,
                38
            )
        );

        header.setReorderingAllowed(false);


        // =====================================================
        // GREEN HEADER RENDERER
        // =====================================================

        javax.swing.table.DefaultTableCellRenderer headerRenderer =
            new javax.swing.table.DefaultTableCellRenderer();

        headerRenderer.setBackground(
            new java.awt.Color(0, 102, 51)
        );

        headerRenderer.setForeground(
            java.awt.Color.WHITE
        );

        headerRenderer.setFont(
            new java.awt.Font(
                "Segoe UI",
                java.awt.Font.BOLD,
                14
            )
        );

        headerRenderer.setHorizontalAlignment(
            javax.swing.SwingConstants.CENTER
        );

        headerRenderer.setOpaque(true);

        for (int i = 0;
                i < PatientsTable.getColumnCount();
                i++) {

            PatientsTable.getColumnModel()
                .getColumn(i)
                .setHeaderRenderer(headerRenderer);
        }


        // =====================================================
        // CENTER TABLE DATA
        // =====================================================

        javax.swing.table.DefaultTableCellRenderer center =
            new javax.swing.table.DefaultTableCellRenderer();

        center.setHorizontalAlignment(
            javax.swing.SwingConstants.CENTER
        );

        for (int i = 0;
                i < PatientsTable.getColumnCount();
                i++) {

            PatientsTable.getColumnModel()
                .getColumn(i)
                .setCellRenderer(center);
        }

        jScrollPane1.getViewport().setBackground(
            java.awt.Color.WHITE
        );
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        Doctors = new javax.swing.JButton();
        MedicalRecords = new javax.swing.JButton();
        Services = new javax.swing.JButton();
        Payments = new javax.swing.JButton();
        Staff = new javax.swing.JButton();
        Dashboard = new javax.swing.JButton();
        PatientsTitle = new javax.swing.JButton();
        UserAccounts = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        PatientsTable = new javax.swing.JTable();
        Appointments = new javax.swing.JButton();
        SearchField = new javax.swing.JTextField();
        Patients = new javax.swing.JButton();
        SearchButton = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        ClearButton = new javax.swing.JButton();
        SaveButton = new javax.swing.JButton();
        jTextField6 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox<>();
        Order = new javax.swing.JComboBox<>();
        Filter = new javax.swing.JComboBox<>();
        Sort = new javax.swing.JComboBox<>();
        Archive = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton1.setForeground(new java.awt.Color(204, 0, 0));
        jButton1.setText("Log Out");
        jButton1.setBorderPainted(false);
        jButton1.setContentAreaFilled(false);
        jButton1.setDefaultCapable(false);
        jButton1.setFocusPainted(false);
        jButton1.setFocusable(false);
        jButton1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton1.addActionListener(this::jButton1ActionPerformed);
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 990, 260, 60));

        Doctors.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Doctors.setForeground(new java.awt.Color(255, 255, 255));
        Doctors.setText("Doctors");
        Doctors.setBorderPainted(false);
        Doctors.setContentAreaFilled(false);
        Doctors.setDefaultCapable(false);
        Doctors.setFocusPainted(false);
        Doctors.setFocusable(false);
        Doctors.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Doctors.addActionListener(this::DoctorsActionPerformed);
        getContentPane().add(Doctors, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 490, 260, 90));

        MedicalRecords.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        MedicalRecords.setForeground(new java.awt.Color(255, 255, 255));
        MedicalRecords.setText("Medical Records");
        MedicalRecords.setBorderPainted(false);
        MedicalRecords.setContentAreaFilled(false);
        MedicalRecords.setDefaultCapable(false);
        MedicalRecords.setFocusPainted(false);
        MedicalRecords.setFocusable(false);
        MedicalRecords.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        MedicalRecords.addActionListener(this::MedicalRecordsActionPerformed);
        getContentPane().add(MedicalRecords, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 610, 260, 90));

        Services.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Services.setForeground(new java.awt.Color(255, 255, 255));
        Services.setText("Services");
        Services.setBorderPainted(false);
        Services.setContentAreaFilled(false);
        Services.setDefaultCapable(false);
        Services.setFocusPainted(false);
        Services.setFocusable(false);
        Services.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Services.addActionListener(this::ServicesActionPerformed);
        getContentPane().add(Services, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 670, 260, 90));

        Payments.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Payments.setForeground(new java.awt.Color(255, 255, 255));
        Payments.setText("Payments");
        Payments.setBorderPainted(false);
        Payments.setContentAreaFilled(false);
        Payments.setDefaultCapable(false);
        Payments.setFocusPainted(false);
        Payments.setFocusable(false);
        Payments.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Payments.addActionListener(this::PaymentsActionPerformed);
        getContentPane().add(Payments, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 730, 260, 80));

        Staff.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Staff.setForeground(new java.awt.Color(255, 255, 255));
        Staff.setText("Staff");
        Staff.setBorderPainted(false);
        Staff.setContentAreaFilled(false);
        Staff.setDefaultCapable(false);
        Staff.setFocusPainted(false);
        Staff.setFocusable(false);
        Staff.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Staff.addActionListener(this::StaffActionPerformed);
        getContentPane().add(Staff, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 780, 260, 80));

        Dashboard.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Dashboard.setForeground(new java.awt.Color(255, 255, 255));
        Dashboard.setText("Dashboard");
        Dashboard.setBorderPainted(false);
        Dashboard.setContentAreaFilled(false);
        Dashboard.setDefaultCapable(false);
        Dashboard.setFocusPainted(false);
        Dashboard.setFocusable(false);
        Dashboard.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Dashboard.addActionListener(this::DashboardActionPerformed);
        getContentPane().add(Dashboard, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 370, 260, 100));

        PatientsTitle.setFont(new java.awt.Font("Segoe UI", 1, 40)); // NOI18N
        PatientsTitle.setText("Patients");
        PatientsTitle.setBorderPainted(false);
        PatientsTitle.setContentAreaFilled(false);
        PatientsTitle.setDefaultCapable(false);
        PatientsTitle.setFocusPainted(false);
        PatientsTitle.setFocusable(false);
        PatientsTitle.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        PatientsTitle.addActionListener(this::PatientsTitleActionPerformed);
        getContentPane().add(PatientsTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 40, 260, -1));

        UserAccounts.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        UserAccounts.setForeground(new java.awt.Color(255, 255, 255));
        UserAccounts.setText("User Accounts");
        UserAccounts.setBorderPainted(false);
        UserAccounts.setContentAreaFilled(false);
        UserAccounts.setDefaultCapable(false);
        UserAccounts.setFocusPainted(false);
        UserAccounts.setFocusable(false);
        UserAccounts.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        UserAccounts.addActionListener(this::UserAccountsActionPerformed);
        getContentPane().add(UserAccounts, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 830, 260, 80));

        jPanel2.setBackground(new java.awt.Color(222, 246, 236));

        PatientsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Patient ID", "First Name", "Last Name", "Birth Date", "Gender", "Contact Number", "Address", "Date Added", "Status"
            }
        ));
        PatientsTable.setFocusCycleRoot(true);
        PatientsTable.setGridColor(new java.awt.Color(231, 250, 250));
        PatientsTable.setShowGrid(true);
        PatientsTable.setSurrendersFocusOnKeystroke(true);
        jScrollPane1.setViewportView(PatientsTable);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1416, Short.MAX_VALUE)
                .addGap(52, 52, 52))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 525, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 230, 1480, 540));

        Appointments.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Appointments.setForeground(new java.awt.Color(255, 255, 255));
        Appointments.setText("Appointments");
        Appointments.setBorderPainted(false);
        Appointments.setContentAreaFilled(false);
        Appointments.setDefaultCapable(false);
        Appointments.setFocusPainted(false);
        Appointments.setFocusable(false);
        Appointments.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Appointments.addActionListener(this::AppointmentsActionPerformed);
        getContentPane().add(Appointments, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 550, 260, 90));

        SearchField.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        SearchField.setForeground(new java.awt.Color(153, 153, 153));
        SearchField.setText("Search patient by name, contact, or ID..");
        getContentPane().add(SearchField, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 160, 720, 50));

        Patients.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Patients.setForeground(new java.awt.Color(0, 102, 51));
        Patients.setText("Patients");
        Patients.setDefaultCapable(false);
        Patients.setFocusPainted(false);
        Patients.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Patients.addActionListener(this::PatientsActionPerformed);
        getContentPane().add(Patients, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 450, 260, 60));

        SearchButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-search-47.png"))); // NOI18N
        SearchButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 51)));
        SearchButton.setBorderPainted(false);
        SearchButton.addActionListener(this::SearchButtonActionPerformed);
        getContentPane().add(SearchButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 160, -1, -1));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 102, 51));
        jLabel2.setText("Patient Details");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("First Name");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Last Name");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setText("  Birth Date");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel6.setText("Gender");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female", " " }));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setText("Contact Number");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel8.setText("Address");

        ClearButton.setBackground(new java.awt.Color(240, 250, 244));
        ClearButton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ClearButton.setForeground(new java.awt.Color(0, 102, 51));
        ClearButton.setText("Clear");

        SaveButton.setBackground(new java.awt.Color(0, 102, 51));
        SaveButton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        SaveButton.setForeground(new java.awt.Color(255, 255, 255));
        SaveButton.setText("Save");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel9.setText("Status");

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Active", "Inactive" }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel6)
                                .addGap(35, 35, 35))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel4)
                                        .addGap(12, 12, 12))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel5)
                                        .addGap(18, 18, 18)))))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jTextField4, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
                                .addComponent(jTextField3))
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap(28, Short.MAX_VALUE)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(139, 139, 139)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addComponent(jLabel8)
                            .addComponent(jLabel9))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jTextField6, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 241, Short.MAX_VALUE)
                            .addComponent(jComboBox2, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(ClearButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(SaveButton)))
                .addContainerGap(626, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel5))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel9)
                                .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ClearButton, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SaveButton, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 860, 1470, 200));

        Order.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Order.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ORDER", "ASCENDING", "DESCENDING" }));
        Order.addActionListener(this::OrderActionPerformed);
        getContentPane().add(Order, new org.netbeans.lib.awtextra.AbsoluteConstraints(1450, 160, 130, 50));

        Filter.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Filter.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "FILTER BY: ALL", "Active", "Inactive", " ", " " }));
        Filter.addActionListener(this::FilterActionPerformed);
        getContentPane().add(Filter, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 160, -1, 50));

        Sort.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Sort.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SORT BY: DEFAULT", "First Name", "Last Name", "Patient ID", "Birth Date", "Gender" }));
        Sort.addActionListener(this::SortActionPerformed);
        getContentPane().add(Sort, new org.netbeans.lib.awtextra.AbsoluteConstraints(1300, 160, 140, 50));

        Archive.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Archive.setForeground(new java.awt.Color(255, 255, 255));
        Archive.setText("Archive");
        Archive.setBorderPainted(false);
        Archive.setContentAreaFilled(false);
        Archive.setDefaultCapable(false);
        Archive.setFocusPainted(false);
        Archive.setFocusable(false);
        Archive.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Archive.addActionListener(this::ArchiveActionPerformed);
        getContentPane().add(Archive, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 890, 260, 80));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Dashgh.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1930, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void MedicalRecordsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MedicalRecordsActionPerformed
    MedicalRecords records = new MedicalRecords();
    records.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_MedicalRecordsActionPerformed

    private void AppointmentsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AppointmentsActionPerformed
    Appointments appointments = new Appointments();
    appointments.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_AppointmentsActionPerformed

    private void PatientsTitleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PatientsTitleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PatientsTitleActionPerformed

    private void DoctorsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DoctorsActionPerformed
        Doctors doctors = new Doctors();
        doctors.setVisible(true);
        this.dispose();

    }//GEN-LAST:event_DoctorsActionPerformed

    private void SearchButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchButtonActionPerformed
        searchPatients();    
        // TODO add your handling code here:
    }//GEN-LAST:event_SearchButtonActionPerformed

    private void DashboardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DashboardActionPerformed
     
        Dashboard dashboard = new Dashboard();
        dashboard.setVisible(true);
         this.dispose();
    }//GEN-LAST:event_DashboardActionPerformed

    private void PaymentsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PaymentsActionPerformed
    Payments payments = new Payments();
    payments.setVisible(true);
    this.dispose();
       // TODO add your handling code here:
    }//GEN-LAST:event_PaymentsActionPerformed

    private void ServicesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ServicesActionPerformed
    Services services = new Services();
    services.setVisible(true);
    this.dispose();
       // TODO add your handling code here:
    }//GEN-LAST:event_ServicesActionPerformed

    private void StaffActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StaffActionPerformed
    Staff staff = new Staff();
    staff.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_StaffActionPerformed

    private void UserAccountsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UserAccountsActionPerformed
    UserAccounts accounts = new UserAccounts();
    accounts.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_UserAccountsActionPerformed

    private void PatientsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PatientsActionPerformed
        Patients Patients = new Patients();
        Patients.setVisible(true);
        this.dispose();           // TODO add your handling code here:
    }//GEN-LAST:event_PatientsActionPerformed

    private void FilterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FilterActionPerformed
        searchPatients();

        // TODO add your handling code here:
    }//GEN-LAST:event_FilterActionPerformed

    private void OrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OrderActionPerformed
            sortPatients();
    // TODO add your handling code here:
    }//GEN-LAST:event_OrderActionPerformed

    private void SortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SortActionPerformed
            sortPatients();
 
    // TODO add your handling code here:
    }//GEN-LAST:event_SortActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    UserSession.logout();
    SignIn logout = new SignIn();
    logout.setVisible(true);
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void ArchiveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ArchiveActionPerformed
        Archive archive = new Archive();
        archive.setVisible(true);
        this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_ArchiveActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Patients().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Appointments;
    private javax.swing.JButton Archive;
    private javax.swing.JButton ClearButton;
    private javax.swing.JButton Dashboard;
    private javax.swing.JButton Doctors;
    private javax.swing.JComboBox<String> Filter;
    private javax.swing.JButton MedicalRecords;
    private javax.swing.JComboBox<String> Order;
    private javax.swing.JButton Patients;
    private javax.swing.JTable PatientsTable;
    private javax.swing.JButton PatientsTitle;
    private javax.swing.JButton Payments;
    private javax.swing.JButton SaveButton;
    private javax.swing.JButton SearchButton;
    private javax.swing.JTextField SearchField;
    private javax.swing.JButton Services;
    private javax.swing.JComboBox<String> Sort;
    private javax.swing.JButton Staff;
    private javax.swing.JButton UserAccounts;
    private javax.swing.JButton jButton1;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    // End of variables declaration//GEN-END:variables
}
