
public final class UserSession {

        private static int userId = -1;
        private static String username = "";
        private static String role = "";

        private UserSession() {
        }

        public static void login(
                int id, String name, String userRole) {

                userId = id;
                username = name;
                role = userRole == null
                        ? "" : userRole.trim();
        }

        public static boolean isLoggedIn() {
                return userId != -1;
        }

        public static boolean isAdmin() {
                return isLoggedIn()
                        && role.equalsIgnoreCase("Admin");
        }

        public static boolean isStaff() {
                return isLoggedIn()
                        && role.equalsIgnoreCase("Staff");
        }

        public static String getUsername() {
                return username;
        }

        public static String getRole() {
                return role;
        }

        public static void logout() {
                userId = -1;
                username = "";
                role = "";
        }
}
